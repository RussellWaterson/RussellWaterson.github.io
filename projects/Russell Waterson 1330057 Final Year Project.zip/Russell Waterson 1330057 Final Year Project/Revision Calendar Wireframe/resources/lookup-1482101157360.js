(function(window, undefined) {
  var dictionary = {
    "c2f62abe-0878-4139-935e-cb12a73d8462": "Exams",
    "a58267fa-5cdf-458b-aa67-089ffe61acc9": "Slot Info",
    "6ff78ad4-96f6-4916-ab42-ce795cbbcef3": "Smart Data",
    "7e7b3744-1b26-4711-bcbf-91b30b307105": "Class",
    "cfd2ea16-b44a-4463-8272-dad4bd45a6c7": "Activities",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Timetable",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);