(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-c2f62abe-0878-4139-935e-cb12a73d8462 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-c2f62abe-0878-4139-935e-cb12a73d8462 #s-Panel_1").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-a58267fa-5cdf-458b-aa67-089ffe61acc9 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-6ff78ad4-96f6-4916-ab42-ce795cbbcef3 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-6ff78ad4-96f6-4916-ab42-ce795cbbcef3 #s-Panel_1").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-7e7b3744-1b26-4711-bcbf-91b30b307105 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-7e7b3744-1b26-4711-bcbf-91b30b307105 #s-Panel_1").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-cfd2ea16-b44a-4463-8272-dad4bd45a6c7 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Panel_2").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Panel_3").overscroll({ showThumbs:false, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);