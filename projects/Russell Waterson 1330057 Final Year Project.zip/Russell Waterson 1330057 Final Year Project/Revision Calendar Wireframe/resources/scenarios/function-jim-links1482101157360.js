(function(window, undefined) {

  var jimLinks = {
    "c2f62abe-0878-4139-935e-cb12a73d8462" : {
      "Label_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_2" : [
        "cfd2ea16-b44a-4463-8272-dad4bd45a6c7"
      ],
      "Label_1" : [
        "7e7b3744-1b26-4711-bcbf-91b30b307105"
      ],
      "Two-line-item_20" : [
        "6ff78ad4-96f6-4916-ab42-ce795cbbcef3"
      ]
    },
    "a58267fa-5cdf-458b-aa67-089ffe61acc9" : {
      "arrow-back_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "6ff78ad4-96f6-4916-ab42-ce795cbbcef3" : {
      "arrow-back_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "7e7b3744-1b26-4711-bcbf-91b30b307105" : {
      "Label_4" : [
        "c2f62abe-0878-4139-935e-cb12a73d8462"
      ],
      "Label_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_2" : [
        "cfd2ea16-b44a-4463-8272-dad4bd45a6c7"
      ],
      "Two-line-item_20" : [
        "6ff78ad4-96f6-4916-ab42-ce795cbbcef3"
      ]
    },
    "cfd2ea16-b44a-4463-8272-dad4bd45a6c7" : {
      "Label_4" : [
        "c2f62abe-0878-4139-935e-cb12a73d8462"
      ],
      "Label_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_1" : [
        "7e7b3744-1b26-4711-bcbf-91b30b307105"
      ],
      "Two-line-item_20" : [
        "6ff78ad4-96f6-4916-ab42-ce795cbbcef3"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Label_4" : [
        "c2f62abe-0878-4139-935e-cb12a73d8462"
      ],
      "Label_2" : [
        "cfd2ea16-b44a-4463-8272-dad4bd45a6c7"
      ],
      "Label_1" : [
        "7e7b3744-1b26-4711-bcbf-91b30b307105"
      ],
      "Text_cell_174" : [
        "a58267fa-5cdf-458b-aa67-089ffe61acc9"
      ],
      "Two-line-item_20" : [
        "6ff78ad4-96f6-4916-ab42-ce795cbbcef3"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);