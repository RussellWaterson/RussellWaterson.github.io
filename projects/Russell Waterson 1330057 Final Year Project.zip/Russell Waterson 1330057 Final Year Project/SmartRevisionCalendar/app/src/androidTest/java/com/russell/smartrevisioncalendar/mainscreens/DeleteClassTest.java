package com.russell.smartrevisioncalendar.mainscreens;

import android.content.Intent;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.russell.smartrevisioncalendar.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.doesNotExist;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withContentDescription;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * <h1>Delete Class Test</h1>
 * Instrument UI test to test the deletion of a class
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   21-03-2017
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class DeleteClassTest {

    @Rule
    public ActivityTestRule<IndividualItemScreen> mActivityTestRule = new ActivityTestRule<>(IndividualItemScreen.class);

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule2 = new ActivityTestRule<>(MainActivity.class, true, false);

    @Test
    public void deleteClassTest() {

        ViewInteraction actionMenuItemView = onView(
                allOf(withId(R.id.action_delete), withContentDescription("Delete"), isDisplayed()));
        actionMenuItemView.perform(click());

        ViewInteraction appCompatButton8 = onView(
                allOf(withId(android.R.id.button1), withText("OK")));
        appCompatButton8.perform(scrollTo(), click());

        Intent intent = new Intent();
        mActivityTestRule2.launchActivity(intent);

        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_classes), isDisplayed()));
        bottomNavigationItemView.perform(click());

        ViewInteraction relativeLayout = onView(
                allOf(withId(R.id.custom_component_class),
                        childAtPosition(
                                childAtPosition(
                                        withId(R.id.class_linear_layout),
                                        0),
                                0),
                        isDisplayed()));
        relativeLayout.check(doesNotExist());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}