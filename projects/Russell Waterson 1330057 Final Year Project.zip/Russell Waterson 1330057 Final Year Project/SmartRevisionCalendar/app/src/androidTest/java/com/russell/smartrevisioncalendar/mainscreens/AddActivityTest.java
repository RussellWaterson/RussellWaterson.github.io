package com.russell.smartrevisioncalendar.mainscreens;


import android.content.Intent;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.newitemscreens.AddActivityActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;

/**
 * <h1>Add Activity Test</h1>
 * Instrument UI test to test the adding of a new activity
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   21-03-2017
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class AddActivityTest {

    @Rule
    public ActivityTestRule<AddActivityActivity> mActivityTestRule = new ActivityTestRule<>(AddActivityActivity.class);

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule2 = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void addActivityTest() {
        ViewInteraction textInputEditText = onView(
                withId(R.id.activity_name_input));
        textInputEditText.perform(scrollTo(), replaceText("Activity 1"), closeSoftKeyboard());

        ViewInteraction appCompatSpinner = onView(
                withId(R.id.activity_day_spinner));
        appCompatSpinner.perform(scrollTo(), click());

        ViewInteraction appCompatTextView = onView(
                allOf(withId(android.R.id.text1), withText("Tuesday"), isDisplayed()));
        appCompatTextView.perform(click());

        ViewInteraction appCompatTextView2 = onView(
                allOf(withId(R.id.activity_start_time_input), withText("00:00")));
        appCompatTextView2.perform(scrollTo(), click());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(android.R.id.button2), withText("Cancel"),
                        withParent(allOf(withClassName(is("com.android.internal.widget.ButtonBarLayout")),
                                withParent(withClassName(is("android.widget.LinearLayout"))))),
                        isDisplayed()));
        appCompatButton4.perform(click());

        ViewInteraction appCompatTextView3 = onView(
                allOf(withId(R.id.activity_end_time_input), withText("00:00")));
        appCompatTextView3.perform(scrollTo(), click());

        ViewInteraction appCompatButton5 = onView(
                allOf(withId(android.R.id.button1), withText("OK"),
                        withParent(allOf(withClassName(is("com.android.internal.widget.ButtonBarLayout")),
                                withParent(withClassName(is("android.widget.LinearLayout"))))),
                        isDisplayed()));
        appCompatButton5.perform(click());

        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        String now = timeDF.format(new Date());

        ViewInteraction switch_ = onView(
                allOf(withId(R.id.activity_repeat_switch), withText("Repeat Weekly")));
        switch_.perform(scrollTo(), click());

        ViewInteraction view = onView(
                withId(R.id.activity_colour_input));
        view.perform(scrollTo(), click());

        ViewInteraction appCompatTextView4 = onView(
                allOf(withId(android.R.id.text1), withText("Blue"),
                        childAtPosition(
                                allOf(withClassName(is("com.android.internal.app.AlertController$RecycleListView")),
                                        withParent(withClassName(is("android.widget.FrameLayout")))),
                                5),
                        isDisplayed()));
        appCompatTextView4.perform(click());

        ViewInteraction appCompatButton6 = onView(
                allOf(withId(R.id.activity_save_button), withText("Save")));
        appCompatButton6.perform(scrollTo(), click());

        Intent intent = new Intent();
        mActivityTestRule2.launchActivity(intent);

        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_activities), isDisplayed()));
        bottomNavigationItemView.perform(click());

        ViewInteraction textView = onView(
                allOf(withId(R.id.a_component_activity), withText("Activity 1"),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_activity),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                1),
                        isDisplayed()));
        textView.check(matches(withText("Activity 1")));

        ViewInteraction textView3 = onView(
                allOf(withId(R.id.a_component_time_day), withText("00:00 - " + now + " / Tuesday"),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_activity),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                2),
                        isDisplayed()));
        textView3.check(matches(withText("00:00 - " + now + " / Tuesday")));

        ViewInteraction view2 = onView(
                allOf(withId(R.id.a_component_repeat),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_activity),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                3),
                        isDisplayed()));
        view2.check(matches(isDisplayed()));

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
