package com.russell.smartrevisioncalendar.mainscreens;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.startup.StepperActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.swipeLeft;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * <h1>First Startup Test</h1>
 * Instrument UI test to run through all the initial first start up screens
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   21-03-2017
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class FirstStartupTest {

    @Rule
    public ActivityTestRule<StepperActivity> mActivityTestRule = new ActivityTestRule<>(StepperActivity.class);

    @Test
    public void firstStartupTest() {
        ViewInteraction rightNavigationButton = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton.perform(click());

        ViewInteraction nonSwipeableViewPager = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager.perform(swipeLeft());

        ViewInteraction rightNavigationButton2 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton2.perform(click());

        ViewInteraction nonSwipeableViewPager2 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager2.perform(swipeLeft());

        ViewInteraction rightNavigationButton3 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton3.perform(click());

        ViewInteraction nonSwipeableViewPager3 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager3.perform(swipeLeft());

        ViewInteraction rightNavigationButton4 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton4.perform(click());

        ViewInteraction nonSwipeableViewPager4 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager4.perform(swipeLeft());

        ViewInteraction rightNavigationButton5 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton5.perform(click());

        ViewInteraction nonSwipeableViewPager5 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager5.perform(swipeLeft());

        ViewInteraction rightNavigationButton6 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton6.perform(click());

        ViewInteraction nonSwipeableViewPager6 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager6.perform(swipeLeft());

        ViewInteraction rightNavigationButton7 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton7.perform(click());

        ViewInteraction nonSwipeableViewPager7 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager7.perform(swipeLeft());

        ViewInteraction rightNavigationButton8 = onView(
                allOf(withId(R.id.ms_stepNextButton), withText("NEXT"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton8.perform(click());

        ViewInteraction nonSwipeableViewPager8 = onView(
                allOf(withId(R.id.ms_stepPager),
                        withParent(allOf(withId(R.id.stepperLayout),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        nonSwipeableViewPager8.perform(swipeLeft());

        ViewInteraction rightNavigationButton9 = onView(
                allOf(withId(R.id.ms_stepCompleteButton), withText("COMPLETE"),
                        withParent(allOf(withId(R.id.ms_bottomNavigation),
                                withParent(withId(R.id.stepperLayout)))),
                        isDisplayed()));
        rightNavigationButton9.perform(click());
    }

}
