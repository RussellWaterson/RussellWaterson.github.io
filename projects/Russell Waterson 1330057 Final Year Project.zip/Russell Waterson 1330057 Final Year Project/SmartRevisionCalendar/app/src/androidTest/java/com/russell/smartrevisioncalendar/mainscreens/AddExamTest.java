package com.russell.smartrevisioncalendar.mainscreens;


import android.content.Intent;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.newitemscreens.AddExamActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;

/**
 * <h1>Add Exam Test</h1>
 * Instrument UI test to test the adding of a new exam
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   21-03-2017
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class AddExamTest {

    @Rule
    public ActivityTestRule<AddExamActivity> mActivityTestRule = new ActivityTestRule<>(AddExamActivity.class);

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule2 = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void addExamTest() {
        ViewInteraction appCompatAutoCompleteTextView = onView(
                withId(R.id.exam_module_name_input));
        appCompatAutoCompleteTextView.perform(scrollTo(), replaceText("Exam 1"), closeSoftKeyboard());

        ViewInteraction textInputEditText = onView(
                withId(R.id.exam_title_name_input));
        textInputEditText.perform(scrollTo(), replaceText("Title"), closeSoftKeyboard());

        ViewInteraction appCompatTextView = onView(
                allOf(withId(R.id.exam_date_input), withText("00-00-0000")));
        appCompatTextView.perform(scrollTo(), click());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(android.R.id.button1), withText("OK"),
                        withParent(allOf(withClassName(is("com.android.internal.widget.ButtonBarLayout")),
                                withParent(withClassName(is("android.widget.LinearLayout"))))),
                        isDisplayed()));
        appCompatButton2.perform(click());

        ViewInteraction appCompatTextView2 = onView(
                allOf(withId(R.id.exam_start_time_input), withText("00:00")));
        appCompatTextView2.perform(scrollTo(), click());

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(android.R.id.button1), withText("OK"),
                        withParent(allOf(withClassName(is("com.android.internal.widget.ButtonBarLayout")),
                                withParent(withClassName(is("android.widget.LinearLayout"))))),
                        isDisplayed()));
        appCompatButton3.perform(click());

        SimpleDateFormat timeDF = new SimpleDateFormat("dd-MM-yyyy / HH:mm", Locale.UK);
        String now = timeDF.format(new Date());

        ViewInteraction appCompatEditText = onView(
                withId(R.id.exam_duration_input));
        appCompatEditText.perform(scrollTo(), replaceText("60"), closeSoftKeyboard());

        ViewInteraction view = onView(
                withId(R.id.exam_colour_input));
        view.perform(scrollTo(), click());

        ViewInteraction appCompatTextView3 = onView(
                allOf(withId(android.R.id.text1), withText("Green"),
                        childAtPosition(
                                allOf(withClassName(is("com.android.internal.app.AlertController$RecycleListView")),
                                        withParent(withClassName(is("android.widget.FrameLayout")))),
                                9),
                        isDisplayed()));
        appCompatTextView3.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.exam_content_size_input));
        appCompatEditText2.perform(scrollTo(), replaceText("8"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.exam_priority_input));
        appCompatEditText3.perform(scrollTo(), replaceText("3"), closeSoftKeyboard());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.exam_save_button), withText("Save")));
        appCompatButton4.perform(scrollTo(), click());

        Intent intent = new Intent();
        mActivityTestRule2.launchActivity(intent);

        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_exams), isDisplayed()));
        bottomNavigationItemView.perform(click());

        ViewInteraction textView = onView(
                allOf(withId(R.id.e_component_module_title), withText("Exam 1 - Title"),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                1),
                        isDisplayed()));
        textView.check(matches(withText("Exam 1 - Title")));

        ViewInteraction textView2 = onView(
                allOf(withId(R.id.e_component_date_time), withText(now + " (60 minutes)"),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                2),
                        isDisplayed()));
        textView2.check(matches(withText(now + " (60 minutes)")));

        ViewInteraction textView3 = onView(
                allOf(withId(R.id.e_component_days_to_go), withText("1 days to go"),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                3),
                        isDisplayed()));
        textView3.check(matches(withText("1 days to go")));

        ViewInteraction view2 = onView(
                allOf(withId(R.id.e_component_priority_square_1),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                5),
                        isDisplayed()));
        view2.check(matches(isDisplayed()));

        ViewInteraction view3 = onView(
                allOf(withId(R.id.e_component_priority_square_2),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                6),
                        isDisplayed()));
        view3.check(matches(isDisplayed()));

        ViewInteraction view4 = onView(
                allOf(withId(R.id.e_component_priority_square_3),
                        childAtPosition(
                                allOf(withId(R.id.custom_component_exam),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                0)),
                                7),
                        isDisplayed()));
        view4.check(matches(isDisplayed()));

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
