package com.russell.smartrevisioncalendar.mainscreens;

import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.customcomponents.ActivityComponent;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.newitemscreens.AddActivityActivity;

/**
 * <h1>Activities Fragment</h1>
 * Displays the activities fragment showing all the activities in the system, as well as a floating
 * action button allowing for the user to add a new activity to the system. This fragment is
 * displayed within the main activity.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-12-2016
 */
public class ActivitiesFragment extends Fragment{

    DatabaseHelper myDb;
    TextView textView;
    LinearLayout activityLinearLayout;

    SharedPreferences sharedPref;

    boolean resume = false;
    int previousCount;

    View myView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.activities_layout, container, false);

        textView = (TextView) myView.findViewById(R.id.textView2);
        activityLinearLayout = (LinearLayout) myView.findViewById(R.id.activity_linear_layout);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        FloatingActionButton fab = (FloatingActionButton) myView.findViewById(R.id.fabActivities);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                editor.commit();
                startActivity(new Intent(getActivity().getApplicationContext(), AddActivityActivity.class));
            }
        });

        viewAll();

        return myView;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (resume) {
            myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
            Cursor res = myDb.getAllActivityData();
            if (previousCount != res.getCount()) {
                if(activityLinearLayout.getChildCount() > 0)
                    activityLinearLayout.removeAllViews();
                viewAll();
            }
        }
        resume = true;
    }

    /**
     * Creates a custom activity component per activity in the activities table and adds it to the
     * layout in the fragment.
     */
    public void viewAll() {
        myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());

        Cursor res = myDb.getAllActivityData();
        previousCount = res.getCount();
        if(res.getCount() == 0) {
            // show message for when there is no entries in the DB
            textView.setText("The Activities database is currently empty\nPlease add a new activity");
            return;
        }

        //Otherwise remove text view
        textView.setVisibility(View.GONE);

        //And proceed to display all the records
        while (res.moveToNext()) {
            //Create temp activity component and add it to the parent
            ActivityComponent tempComponent = new ActivityComponent(getActivity());

            //LayoutParams to replicate xml attributes
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            //Edit the component values from the records in the database
            tempComponent.setID(res.getString(0));
            tempComponent.setActivity(res.getString(1));
            tempComponent.setTimeDayText(res.getString(3) + " - " + res.getString(4) + " / " + res.getString(2));
            tempComponent.setRepeat(Integer.valueOf(res.getString(5)) == 1);
            tempComponent.setColouredLine(res.getString(6));

            //Add the activity component to the linear layout
            activityLinearLayout.addView(tempComponent);
        }

        //Add blank space after the final activity record to all for better scrolling
        View blankView = new View(getActivity());
        blankView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 200));
        activityLinearLayout.addView(blankView);
    }
}
