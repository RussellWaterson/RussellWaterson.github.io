package com.russell.smartrevisioncalendar.smartdata;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.preference.PreferenceManager;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * <h1>Create Revision Blocks</h1>
 * This class creates the revision blocks based on a number of factors. This includes the user's
 * preferred start and finish time, revision and break block size, and other items in the databases.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   03-02-2017
 */
public class CreateRevisionBlocks extends IntentService {

    SharedPreferences sharedPref;
    DatabaseHelper myDb;
    Cursor resExam;
    Cursor resRevision;

    Date latestExamDate;

    /**
     * Creates an IntentService.  Invoked by subclass's constructor.
     */
    public CreateRevisionBlocks() {
        super("CreateRevisionBlocks");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        System.out.println("The service has now started!!");

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        myDb = DatabaseHelper.getInstance(getApplicationContext());

        resRevision = myDb.getAllRevisionData();

        resExam = myDb.getAllExamData();
        if(resExam.getCount() == 0) {
            System.out.println("You have not entered any exams so revision cannot be made");
            return;
        }

        //clearCurrentBlocks();

        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.sharedpref_number_of_old_revision_slots), resRevision.getCount());
        editor.apply();

        createBlocks();

        allocateRevision();
    }

    /**
     * Removes all revision blocks currently present in the exam database in order to create room
     * for the new additions
     */
    private void clearCurrentBlocks() {
        System.out.println("Clearing revision database of existing revision slots");
        List<String> revisionIDs = new ArrayList<String>();
        while (resRevision.moveToNext()) {
            revisionIDs.add(resRevision.getString(0));
        }
        for (int i = 0; i < revisionIDs.size(); i++) {
            Integer deletedRows = myDb.deleteRevisionData(revisionIDs.get(i));
            if (deletedRows > 0 ) {
                System.out.println(revisionIDs.get(i) + " deleted");
            } else {
                System.out.println(revisionIDs.get(i) + " NOT deleted!");
            }
        }
    }

    /**
     * Creates time slots for revision sessions based on the user's preferences, up to the last
     * exam in the database
     */
    private void createBlocks() {
        //Initialise key variables
        String preferredStartTime = sharedPref.getString(getString(R.string.sharedpref_preferred_start_time), "00:00");
        String preferredEndTime = sharedPref.getString(getString(R.string.sharedpref_preferred_end_time), "23:59");
        int revisionBlockSize = Integer.valueOf(sharedPref.getString(getString(R.string.sharedpref_revision_block_size), "0"));
        int breakBlockSize = Integer.valueOf(sharedPref.getString(getString(R.string.sharedpref_break_block_size), "0"));

        //Helper variables to convert strings to time and date values
        SimpleDateFormat dayDF = new SimpleDateFormat("EEEE", Locale.UK);
        final SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
        SimpleDateFormat eventDateDF = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
        Calendar calendar;

        //Get the last exam in the exam database and store all in array list for later processing
        List<String> examDates = new ArrayList<String>();
        latestExamDate = new Date();
        Date newDate;
        while (resExam.moveToNext()) {
            examDates.add(resExam.getString(3));
            try {
                newDate = dateDF.parse(resExam.getString(3));
            } catch (ParseException e) {
                e.printStackTrace();
                newDate = new Date();
            }
            if (newDate.after(latestExamDate)) {
                latestExamDate = newDate;
            }
        }

        //Get all the events dates and times and store them in an array list for later processing
        List<String> eventsDates = new ArrayList<String>();
        List<String> eventsStart = new ArrayList<String>();
        List<String> eventsEnd = new ArrayList<String>();
        Cursor resEvent = myDb.getAllEventData();
        while (resEvent.moveToNext()) {
            try {
                eventsDates.add(dateDF.format(eventDateDF.parse(resEvent.getString(2))));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            eventsStart.add(resEvent.getString(3));
            eventsEnd.add(resEvent.getString(4));
        }

        //Get the days and times of all the activities and add them to a 2D array list
        Cursor resActivity = myDb.getAllActivityData();

        List<List<String>> activityTimesList = new ArrayList<List<String>>();
        while (resActivity.moveToNext()) {
            List<String> dayStartEnd = new ArrayList<String>();
            dayStartEnd.add(resActivity.getString(2));
            dayStartEnd.add(resActivity.getString(3));
            dayStartEnd.add(resActivity.getString(4));

            activityTimesList.add(dayStartEnd);
        }

        //Get the days and times of all the classes and add them to the 2D array list
        Cursor resClass = myDb.getAllClassData();

        while (resClass.moveToNext()) {
            List<String> dayStartEnd = new ArrayList<String>();
            dayStartEnd.add(resClass.getString(3));
            dayStartEnd.add(resClass.getString(4));
            dayStartEnd.add(resClass.getString(5));

            activityTimesList.add(dayStartEnd);
        }

        for (int i=0; i<activityTimesList.size();i++)
            System.out.println(activityTimesList.get(i));

        //Sort the array list into order of start time (irrespective of the day)
        Collections.sort(activityTimesList, new Comparator<List<String>>() {
            @Override
            public int compare(List<String> o1, List<String> o2) {
                try {
                    return timeDF.parse(o1.get(1)).compareTo(timeDF.parse(o2.get(1)));
                } catch (ParseException e) {
                    return 0;
                }
            }
        });

        //Starting from the current date, start populating the day with revision up until the last exam
        String dayToEnter = dayDF.format(Calendar.getInstance().getTime().getTime());
        String dateToEnter = dateDF.format(Calendar.getInstance().getTime());

        //Start at the user's preferred start time and determine whether a revision block can fit
        String startTimeToEnter = preferredStartTime;
        String endTimeToEnter;

        try {
            while (dateDF.parse(dateToEnter).before(latestExamDate)) {

                if (examDates.contains(dateToEnter)) {
                    System.out.println("You have an exam today, devote all free time to preparing for that");

                } else {

                    endOfDayLoop:
                    for (int i = 0; i < activityTimesList.size(); i++) {

                        if (dayToEnter.equals(activityTimesList.get(i).get(0))) {

                            if (timeDF.parse(activityTimesList.get(i).get(2)).after(timeDF.parse(preferredStartTime))) {
                                //When the activity ends before the start of the day, skip it

                                while (true) {

                                    if ((timeDF.parse(startTimeToEnter).after(timeDF.parse(activityTimesList.get(i).get(1)))
                                            && timeDF.parse(startTimeToEnter).before(timeDF.parse(activityTimesList.get(i).get(2))))
                                            || timeDF.parse(startTimeToEnter).equals(timeDF.parse(activityTimesList.get(i).get(1)))) {

                                        //When the proposed revision block starts within an activity
                                        //Set the new proposed revision block start time to the end of the activity
                                        startTimeToEnter = activityTimesList.get(i).get(2);
                                        if (timeDF.parse(startTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                || timeDF.parse(startTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                            //Reached end of day
                                            break endOfDayLoop;
                                        }
                                        break;

                                    } else {
                                        //Otherwise, check the end of the revision block doesn't clash
                                        calendar = Calendar.getInstance();
                                        calendar.setTime(timeDF.parse(startTimeToEnter));
                                        calendar.add(Calendar.MINUTE, revisionBlockSize);
                                        endTimeToEnter = timeDF.format(calendar.getTime());
                                        if (timeDF.parse(endTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                || timeDF.parse(endTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                            //Reached end of day
                                            break endOfDayLoop;
                                        }

                                        if (timeDF.parse(endTimeToEnter).after(timeDF.parse(activityTimesList.get(i).get(1)))) {

                                            //When the proposed revision block ends within an activity
                                            //Set the new proposed revision block start time to the end of the activity
                                            startTimeToEnter = activityTimesList.get(i).get(2);
                                            if (timeDF.parse(startTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                    || timeDF.parse(startTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                                //Reached end of day
                                                break endOfDayLoop;
                                            }
                                            break;

                                        } else {

                                            if (eventsDates.contains(dateToEnter)) {
                                                if ((timeDF.parse(startTimeToEnter).after(timeDF.parse(eventsStart.get(eventsDates.indexOf(dateToEnter))))
                                                        && timeDF.parse(startTimeToEnter).before(timeDF.parse(eventsEnd.get(eventsDates.indexOf(dateToEnter)))))
                                                        || timeDF.parse(startTimeToEnter).equals(timeDF.parse(eventsStart.get(eventsDates.indexOf(dateToEnter))))) {
                                                    //When there is an event in the database on the same day as the date and time about to enter

                                                    startTimeToEnter = eventsEnd.get(eventsDates.indexOf(dateToEnter));
                                                    if (timeDF.parse(startTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                            || timeDF.parse(startTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                                        //Reached end of day
                                                        break endOfDayLoop;
                                                    }
                                                    i--;
                                                    break;

                                                } else {

                                                    //Otherwise, check the end of the event block doesn't clash
                                                    calendar = Calendar.getInstance();
                                                    calendar.setTime(timeDF.parse(startTimeToEnter));
                                                    calendar.add(Calendar.MINUTE, revisionBlockSize);
                                                    endTimeToEnter = timeDF.format(calendar.getTime());
                                                    if (timeDF.parse(endTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                            || timeDF.parse(endTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                                        //Reached end of day
                                                        break endOfDayLoop;
                                                    }

                                                    if (timeDF.parse(endTimeToEnter).after(timeDF.parse(eventsStart.get(eventsDates.indexOf(dateToEnter))))
                                                            && timeDF.parse(startTimeToEnter).before(timeDF.parse(eventsStart.get(eventsDates.indexOf(dateToEnter))))) {

                                                        //When the proposed revision block ends within an activity
                                                        //Set the new proposed revision block start time to the end of the activity
                                                        startTimeToEnter = eventsEnd.get(eventsDates.indexOf(dateToEnter));
                                                        if (timeDF.parse(startTimeToEnter).after(timeDF.parse(preferredEndTime))
                                                                || timeDF.parse(startTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                                                            //Reached end of day
                                                            break endOfDayLoop;
                                                        }
                                                        i--;
                                                        break;

                                                    }

                                                }

                                            }

                                            //Create revision block and add it to the revision database
                                            boolean isInserted = myDb.insertRevisionData(null,
                                                    null,
                                                    dateToEnter,
                                                    startTimeToEnter,
                                                    endTimeToEnter,
                                                    null,
                                                    null);

                                            if (isInserted) {
                                                System.out.println("DATA INSERTED!! Between Class - Day/Date: " + dayToEnter + dateToEnter + "Start time: " + startTimeToEnter + ", End Time: " + endTimeToEnter);
                                            } else {
                                                System.out.println("DATA NOT INSERTED!! Between Class - Day/Date: " + dayToEnter + dateToEnter + "Start time: " + startTimeToEnter + ", End Time: " + endTimeToEnter);
                                            }

                                            calendar = Calendar.getInstance();
                                            calendar.setTime(timeDF.parse(startTimeToEnter));
                                            calendar.add(Calendar.MINUTE, revisionBlockSize + breakBlockSize);
                                            startTimeToEnter = timeDF.format(calendar.getTime());
                                        }
                                    }
                                }
                            }
                        }
                    }

                    while (timeDF.parse(startTimeToEnter).before(timeDF.parse(preferredEndTime))) {
                        //The day is not finished yet and there is no more classes or activities
                        //Create revision blocks until the end of the day
                        calendar = Calendar.getInstance();
                        calendar.setTime(timeDF.parse(startTimeToEnter));
                        calendar.add(Calendar.MINUTE, revisionBlockSize);
                        endTimeToEnter = timeDF.format(calendar.getTime());
                        if (timeDF.parse(endTimeToEnter).after(timeDF.parse(preferredEndTime))
                                || timeDF.parse(endTimeToEnter).before(timeDF.parse(preferredStartTime))) {
                            //Reached end of day
                            break;
                        }

                        boolean isInserted = myDb.insertRevisionData(null,
                                null,
                                dateToEnter,
                                startTimeToEnter,
                                endTimeToEnter,
                                null,
                                null);

                        if (isInserted) {
                            System.out.println("DATA INSERTED!! End of Day - Day/Date: " + dayToEnter + dateToEnter + "Start time: " + startTimeToEnter + ", End Time: " + endTimeToEnter);
                        } else {
                            System.out.println("DATA NOT INSERTED!! End of Day - Day/Date: " + dayToEnter + dateToEnter + "Start time: " + startTimeToEnter + ", End Time: " + endTimeToEnter);
                        }

                        calendar = Calendar.getInstance();
                        calendar.setTime(timeDF.parse(startTimeToEnter));
                        calendar.add(Calendar.MINUTE, revisionBlockSize + breakBlockSize);
                        startTimeToEnter = timeDF.format(calendar.getTime());
                    }
                }

                //Add one day to the current date and reset start time
                calendar = Calendar.getInstance();
                calendar.setTime(dateDF.parse(dateToEnter));
                calendar.add(Calendar.DATE, 1);
                dateToEnter = dateDF.format(calendar.getTime());
                dayToEnter = dayDF.format(calendar.getTime());
                startTimeToEnter = preferredStartTime;

            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * Allocates revision sessions to the previously created revision slots based on the user's
     * exams and preferences
     */
    private void allocateRevision() {
        int variety = sharedPref.getInt(getString(R.string.sharedpref_variety), 0);

        System.out.println("Exams: " + resExam.getCount());
        System.out.println("Revision: " + resRevision.getCount());
        
        //Divide between, priority, content size, and days to go
        List<List<String>> allocation = new ArrayList<List<String>>();
        resExam = myDb.getAllExamData();
        double totalImportance = 0;
        while (resExam.moveToNext()) {
            List<String> examIdImportanceDtg = new ArrayList<String>();
            
            double priority = (Double.parseDouble(resExam.getString(9)) / 5) * 100;
            double contentSize = (Double.parseDouble(resExam.getString(8)) / 10) * 100;

            Date currentDate = new Date();
            Date enteredDate = null;
            SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
            try {
                enteredDate = dateDF.parse(resExam.getString(3));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long diffInMillies = enteredDate.getTime() - currentDate.getTime();
            long dtg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;
            double daysToGo = ((double) dtg);

            System.out.println("Priority: " + priority + ",    Content Size: " + contentSize + ",    Days to Go: " + daysToGo);

            if (daysToGo > 1) {

                double average = (priority + contentSize) / 2;

                examIdImportanceDtg.add(resExam.getString(0));
                examIdImportanceDtg.add((String.valueOf(average)));
                examIdImportanceDtg.add(String.valueOf(dtg));
                examIdImportanceDtg.add(resExam.getString(3));

                allocation.add(examIdImportanceDtg);

                totalImportance += average;

            } else {

                examIdImportanceDtg.add(resExam.getString(0));
                examIdImportanceDtg.add("0");
                examIdImportanceDtg.add(String.valueOf(dtg));
                examIdImportanceDtg.add(resExam.getString(3));

                allocation.add(examIdImportanceDtg);

            }
        }

        for (int i=0; i<allocation.size();i++)
            System.out.println(allocation.get(i));

        System.out.println("Total Importance: " + totalImportance);

        //Sets all the percentages to probabilities
        for (int i = 0; i < allocation.size(); i++) {
            double oldPercentage = Double.parseDouble(allocation.get(i).get(1));
            allocation.get(i).set(1, String.valueOf((oldPercentage / totalImportance)));
        }

        for (int i=0; i<allocation.size();i++)
            System.out.println(allocation.get(i));


        //Factoring in days to go into the probabilities
        Date currentDate = new Date();
        long diffInMillies = latestExamDate.getTime() - currentDate.getTime();
        long dtg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;
        double daysToGo = ((double) dtg);
        double newTotalProb = 0;

        //The sooner the date of the exam is relative to the last exam, the more the increase of likelihood
        for (int i = 0; i < allocation.size(); i++) {
            if (!(allocation.get(i).get(1).equals("0.0") || allocation.get(i).get(2).equals("0"))) {
                double newProb = Double.parseDouble(allocation.get(i).get(1)) * (1 /
                        (Double.parseDouble(allocation.get(i).get(2)) / daysToGo));
                allocation.get(i).set(1, String.valueOf(newProb));
                newTotalProb += newProb;
            }
        }

        System.out.println("New total prob: " + newTotalProb);

        //Sets all the values to new probabilities after days to go added
        for (int i = 0; i < allocation.size(); i++) {
            double oldPercentage = Double.parseDouble(allocation.get(i).get(1));
            allocation.get(i).set(1, String.valueOf((oldPercentage / newTotalProb)));
        }

        for (int i=0; i<allocation.size();i++)
            System.out.println(allocation.get(i));


        //Adding to revision blocks:
        Random rand = new Random();
        double lowerProb = 0;
        double upperProb = 0;

        SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
        String previsionRevision = "";
        String previsionProbability = "";
        String dateChange = "";
        resRevision = myDb.getAllRevisionData();
        //Loop through all of the revision slots
        while (resRevision.moveToNext()) {
            if (resRevision.getPosition() >= sharedPref.getInt(getString(R.string.sharedpref_number_of_old_revision_slots), 0)) {
                if (dateChange.equals(resRevision.getString(3))) {
                    //Generate random number between 0 and 9 to compare with the user's variability
                    int randomChange = rand.nextInt(10);

                    //The higher the variety, the higher chance of being something different
                    if (variety <= randomChange || previsionProbability.contains("1.0")
                            || previsionProbability.contains("0.99999")) {
                        //100% chance of being the same if variety is 0
                        //If only one exam remains, then will always be the same
                        resExam = myDb.getAllExamData();
                        while (resExam.moveToNext()) {
                            if (previsionRevision.equals(resExam.getString(0))) {
                                boolean isUpdated = myDb.updateRevisionData(resRevision.getString(0),
                                        resExam.getString(1),
                                        resExam.getString(2),
                                        resRevision.getString(3),
                                        resRevision.getString(4),
                                        resRevision.getString(5),
                                        null,
                                        resExam.getString(7));

                                if (isUpdated) {
                                    System.out.println("DATA UPDATED!! " + previsionRevision);
                                } else {
                                    System.out.println("DATA NOT UPDATED!! " + previsionRevision);
                                }
                                break;
                            }
                        }

                    } else {
                        //100% chance of being different if variety is 10
                        //Changes the next revision by selecting another one with high probability and
                        //disregards the prevision exam from the selection
                        int randomNext = rand.nextInt(100);
                        while (randomNext > lowerProb && randomNext <= upperProb) {
                            randomNext = rand.nextInt(100);
                        }

                        upperProb = 0;
                        for (int i = 0; i < allocation.size(); i++) {
                            lowerProb = upperProb;
                            upperProb += Double.parseDouble(allocation.get(i).get(1)) * 100;
                            if (randomNext > lowerProb && randomNext <= upperProb) {
                                //Assign next revision slot after change to this revision
                                resExam = myDb.getAllExamData();
                                while (resExam.moveToNext()) {
                                    if (allocation.get(i).get(0).equals(resExam.getString(0))) {
                                        boolean isUpdated = myDb.updateRevisionData(resRevision.getString(0),
                                                resExam.getString(1),
                                                resExam.getString(2),
                                                resRevision.getString(3),
                                                resRevision.getString(4),
                                                resRevision.getString(5),
                                                null,
                                                resExam.getString(7));

                                        if (isUpdated) {
                                            System.out.println("DATA UPDATED!! " + allocation.get(i));
                                        } else {
                                            System.out.println("DATA NOT UPDATED!! " + allocation.get(i));
                                        }
                                        break;
                                    }
                                }
                                previsionRevision = allocation.get(i).get(0);
                                previsionProbability = allocation.get(i).get(1);
                                break;
                            }
                        }
                    }


                } else {
                    //When the date has changed
                    dateChange = resRevision.getString(3);
                    //Check all the exams are after the current day, otherwise update probabilities
                    for (int i = 0; i < allocation.size(); i++) {
                        try {
                            if (dateDF.parse(allocation.get(i).get(3)).before(dateDF.parse(dateChange))
                                    && !(allocation.get(i).get(1).equals("0"))) {
                                System.out.println("Removing revision from probability: " + allocation.get(i));
                                double probToRemove = Double.parseDouble(allocation.get(i).get(1));
                                allocation.get(i).set(1, "0");
                                for (int j = 0; j < allocation.size(); j++) {
                                    allocation.get(j).set(1, String.valueOf(Double.parseDouble(
                                            allocation.get(j).get(1)) / (1 - probToRemove)));
                                }
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }

                    //A new day of revision has begun so variety doesn't take effect
                    int randomFirst = rand.nextInt(100);
                    upperProb = 0;
                    for (int i = 0; i < allocation.size(); i++) {
                        lowerProb = upperProb;
                        upperProb += Double.parseDouble(allocation.get(i).get(1)) * 100;
                        if (randomFirst > lowerProb && randomFirst <= upperProb) {
                            //Assign first revision slot of the day to this revision
                            resExam = myDb.getAllExamData();
                            while (resExam.moveToNext()) {
                                if (allocation.get(i).get(0).equals(resExam.getString(0))) {
                                    boolean isUpdated = myDb.updateRevisionData(resRevision.getString(0),
                                            resExam.getString(1),
                                            resExam.getString(2),
                                            resRevision.getString(3),
                                            resRevision.getString(4),
                                            resRevision.getString(5),
                                            null,
                                            resExam.getString(7));

                                    if (isUpdated) {
                                        System.out.println("DATA UPDATED!! " + allocation.get(i));
                                    } else {
                                        System.out.println("DATA NOT UPDATED!! " + allocation.get(i));
                                    }
                                    break;
                                }
                            }
                            previsionRevision = allocation.get(i).get(0);
                            previsionProbability = allocation.get(i).get(1);
                            break;
                        }
                    }
                }
            }
        }
    }
}
