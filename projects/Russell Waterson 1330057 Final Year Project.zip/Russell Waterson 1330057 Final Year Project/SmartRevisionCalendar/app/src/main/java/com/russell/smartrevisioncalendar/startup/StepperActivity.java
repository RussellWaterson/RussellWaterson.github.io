package com.russell.smartrevisioncalendar.startup;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.stepstone.stepper.StepperLayout;
import com.stepstone.stepper.VerificationError;

/**
 * <h1>Stepper Activity</h1>
 * Set adapter in Activity
 * <p>
 * Guided from android-material-stepper sample:
 * <a href="https://github.com/stepstone-tech/android-material-stepper">
 *     https://github.com/stepstone-tech/android-material-stepper</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   13-02-2017
 */
public class StepperActivity extends AppCompatActivity implements StepperLayout.StepperListener {

    private StepperLayout mStepperLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startup_layout);
        mStepperLayout = (StepperLayout) findViewById(R.id.stepperLayout);
        mStepperLayout.setAdapter(new FragmentStepAdapter(getSupportFragmentManager(), this));
        mStepperLayout.setListener(this);
    }

    @Override
    public void onBackPressed() {
        final int currentStepPosition = mStepperLayout.getCurrentStepPosition();
        if (currentStepPosition > 0) {
            mStepperLayout.setCurrentStepPosition(currentStepPosition - 1);
        }
    }

    //Overwritten listener methods to complete custom tasks

    @Override
    public void onCompleted(View completeButton) {
        Toast.makeText(this, "Congrats, Setup Complete!", Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void onError(VerificationError verificationError) {

    }

    @Override
    public void onStepSelected(int newStepPosition) {

    }

    @Override
    public void onReturn() {

    }
}
