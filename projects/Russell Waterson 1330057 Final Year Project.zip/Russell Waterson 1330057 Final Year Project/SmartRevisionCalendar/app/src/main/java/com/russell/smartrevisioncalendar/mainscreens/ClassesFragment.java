package com.russell.smartrevisioncalendar.mainscreens;

import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.customcomponents.ClassComponent;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.newitemscreens.AddClassActivity;

/**
 * <h1>Classes Fragment</h1>
 * Displays the classes fragment showing all the classes in the system, as well as a floating
 * action button allowing for the user to add a new class to the system. This fragment is
 * displayed within the main activity.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-12-2016
 */
public class ClassesFragment extends Fragment{

    DatabaseHelper myDb;
    TextView textView;
    LinearLayout classLinearLayout;

    SharedPreferences sharedPref;

    boolean resume = false;
    int previousCount;

    View myView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.classes_layout, container, false);

        textView = (TextView) myView.findViewById(R.id.textView2);
        classLinearLayout = (LinearLayout) myView.findViewById(R.id.class_linear_layout);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        FloatingActionButton fab = (FloatingActionButton) myView.findViewById(R.id.fabClasses);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                editor.commit();
                startActivity(new Intent(getActivity().getApplicationContext(), AddClassActivity.class));
            }
        });

        viewAll();

        return myView;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (resume) {
            myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
            Cursor res = myDb.getAllClassData();
            if (previousCount != res.getCount()) {
                if(classLinearLayout.getChildCount() > 0)
                    classLinearLayout.removeAllViews();
                viewAll();
            }
        }
        resume = true;
    }

    /**
     * Creates a custom class component per class in the classes table and adds it to the
     * layout in the fragment.
     */
    public void viewAll() {
        myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());

        Cursor res = myDb.getAllClassData();
        previousCount = res.getCount();
        if(res.getCount() == 0) {
            // show message for when there is no entries in the DB
            textView.setText("The Class database is currently empty\nPlease add a new class");
            return;
        }

        //Otherwise remove text view
        textView.setVisibility(View.GONE);

        //And proceed to display all the records
        while (res.moveToNext()) {
            //Create temp class component and add it to the parent
            ClassComponent tempComponent = new ClassComponent(getActivity());

            //LayoutParams to replicate xml attributes
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            //Edit the component values from the records in the database
            tempComponent.setID(res.getString(0));
            tempComponent.setModuleTitleText(res.getString(1) + " - " + res.getString(2));
            tempComponent.setTimeDayText(res.getString(4) + " - " + res.getString(5) + " / " + res.getString(3));
            tempComponent.setRepeat(Integer.valueOf(res.getString(6)) == 1);
            tempComponent.setTeacherRoomText(res.getString(7) + " / " + res.getString(8));
            tempComponent.setColouredLine(res.getString(9));

            //Add the class component to the linear layout
            classLinearLayout.addView(tempComponent);
        }

        //Add blank space after the final class record to all for better scrolling
        View blankView = new View(getActivity());
        blankView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 200));
        classLinearLayout.addView(blankView);
    }


}
