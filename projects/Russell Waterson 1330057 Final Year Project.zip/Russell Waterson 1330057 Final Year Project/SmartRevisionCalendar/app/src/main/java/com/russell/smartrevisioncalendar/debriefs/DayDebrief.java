package com.russell.smartrevisioncalendar.debriefs;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

/**
 * <h1>Day Debrief Activity</h1>
 * Manages the debrief screen shown at the end of each day containing revision
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   26-02-2017
 */
public class DayDebrief extends AppCompatActivity {

    TextView message;
    RatingBar productivity;
    SeekBar revisionLength, breakLength, startTime, endTime, variety;
    Button done;

    SharedPreferences sharedPref;

    /**
     * Creates the day debrief activity.
     * @param savedInstanceState previously saved instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_debrief);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        message = (TextView) findViewById(R.id.day_debrief_message);
        productivity = (RatingBar) findViewById(R.id.day_debrief_productivity_ratingBar);
        revisionLength = (SeekBar) findViewById(R.id.day_debrief_revision_length_seekBar);
        breakLength = (SeekBar) findViewById(R.id.day_debrief_break_length_seekBar);
        startTime = (SeekBar) findViewById(R.id.day_debrief_start_time_seekBar);
        endTime = (SeekBar) findViewById(R.id.day_debrief_end_time_seekBar);
        variety = (SeekBar) findViewById(R.id.day_debrief_variety_seekBar);
        done = (Button) findViewById(R.id.day_debrief_done_button);

        message.setText("Hey " + sharedPref.getString(getString(R.string.sharedpref_user_name), "")
                + getString(R.string.day_debrief_message));

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper myDB = DatabaseHelper.getInstance(getApplicationContext());

                //When new data is to be added
                boolean isInserted = myDB.insertDebriefData((int) productivity.getRating(),
                        Integer.parseInt(sharedPref.getString(getString(R.string.sharedpref_revision_block_size), "")),
                        revisionLength.getProgress(),
                        Integer.parseInt(sharedPref.getString(getString(R.string.sharedpref_break_block_size), "")),
                        breakLength.getProgress(),
                        sharedPref.getString(getString(R.string.sharedpref_preferred_start_time), ""),
                        startTime.getProgress(),
                        sharedPref.getString(getString(R.string.sharedpref_preferred_end_time), ""),
                        endTime.getProgress(),
                        sharedPref.getInt(getString(R.string.sharedpref_variety), 0),
                        variety.getProgress());

                if (isInserted) {
                    Toast.makeText(getApplicationContext(), "Debrief data stored and noted!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Debrief Data Insertion Failed", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
    }

}