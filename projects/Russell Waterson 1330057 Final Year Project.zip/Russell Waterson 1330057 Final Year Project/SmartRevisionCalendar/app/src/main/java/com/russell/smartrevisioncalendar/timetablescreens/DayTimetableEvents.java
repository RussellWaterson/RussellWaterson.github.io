package com.russell.smartrevisioncalendar.timetablescreens;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.preference.PreferenceManager;

import com.alamkanak.weekview.WeekViewEvent;
import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * <h1>Day Timetable Event</h1>
 * Events are taken from each database and add to the day view of the timetable
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   30-01-2017
 */
public class DayTimetableEvents extends DayTimetableFragment {

    SharedPreferences sharedPref;
    DatabaseHelper myDb;
    Calendar startTime;
    Calendar endTime;
    WeekViewEvent event;

    @Override
    public List<? extends WeekViewEvent> onMonthChange(int newYear, int newMonth) {
        // Populate the day view with some events.
        List<WeekViewEvent> events = new ArrayList<WeekViewEvent>();

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());

        Cursor resActivity = myDb.getAllActivityData();
        while (resActivity.moveToNext()) {
            if (Integer.valueOf(resActivity.getString(5)) == 1) {
                //If the activity repeats, render the event for every week per month
                for (int i = 0; i < 4; i++) {
                    startTime = Calendar.getInstance();
                    startTime.set(Calendar.DAY_OF_WEEK, dayOfWeek(resActivity.getString(2)));
                    startTime.set(Calendar.DAY_OF_WEEK_IN_MONTH, i);
                    startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resActivity.getString(3).substring(0, 2)));
                    startTime.set(Calendar.MINUTE, Integer.parseInt(resActivity.getString(3).substring(3, 5)));
                    startTime.set(Calendar.MONTH, newMonth);
                    startTime.set(Calendar.YEAR, newYear);
                    endTime = (Calendar) startTime.clone();
                    endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resActivity.getString(4).substring(0, 2)));
                    endTime.set(Calendar.MINUTE, Integer.parseInt(resActivity.getString(4).substring(3, 5)) - 1);
                    event = new WeekViewEvent(100 + Integer.parseInt(resActivity.getString(0)),
                            resActivity.getString(1), startTime, endTime);
                    event.setColor(Color.parseColor(resActivity.getString(6)));
                    events.add(event);
                }
            } else {
                startTime = Calendar.getInstance();
                startTime.set(Calendar.DAY_OF_WEEK, dayOfWeek(resActivity.getString(2)));
                startTime.set(Calendar.DAY_OF_WEEK_IN_MONTH, 1);
                startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resActivity.getString(3).substring(0, 2)));
                startTime.set(Calendar.MINUTE, Integer.parseInt(resActivity.getString(3).substring(3, 5)));
                startTime.set(Calendar.MONTH, newMonth);
                startTime.set(Calendar.YEAR, newYear);
                endTime = (Calendar) startTime.clone();
                endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resActivity.getString(4).substring(0, 2)));
                endTime.set(Calendar.MINUTE, Integer.parseInt(resActivity.getString(4).substring(3, 5)) - 1);
                event = new WeekViewEvent(100 + Integer.parseInt(resActivity.getString(0)),
                        resActivity.getString(1), startTime, endTime);
                event.setColor(Color.parseColor(resActivity.getString(6)));
                events.add(event);
            }
        }

        Cursor resClass = myDb.getAllClassData();
        while (resClass.moveToNext()) {
            if (Integer.valueOf(resClass.getString(6)) == 1) {
                for (int i = 0; i < 4; i++) {
                    //If the class repeats, render the event for every week per month
                    startTime = Calendar.getInstance();
                    startTime.set(Calendar.DAY_OF_WEEK, dayOfWeek(resClass.getString(3)));
                    startTime.set(Calendar.DAY_OF_WEEK_IN_MONTH, i);
                    startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resClass.getString(4).substring(0, 2)));
                    startTime.set(Calendar.MINUTE, Integer.parseInt(resClass.getString(4).substring(3, 5)));
                    startTime.set(Calendar.MONTH, newMonth);
                    startTime.set(Calendar.YEAR, newYear);
                    endTime = (Calendar) startTime.clone();
                    endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resClass.getString(5).substring(0, 2)));
                    endTime.set(Calendar.MINUTE, Integer.parseInt(resClass.getString(5).substring(3, 5)) - 1);
                    event = new WeekViewEvent(200 + Integer.parseInt(resClass.getString(0)),
                            resClass.getString(1), startTime, endTime);
                    event.setColor(Color.parseColor(resClass.getString(9)));
                    events.add(event);
                }
            } else {
                startTime = Calendar.getInstance();
                startTime.set(Calendar.DAY_OF_WEEK, dayOfWeek(resClass.getString(3)));
                startTime.set(Calendar.DAY_OF_WEEK_IN_MONTH, 1);
                startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resClass.getString(4).substring(0, 2)));
                startTime.set(Calendar.MINUTE, Integer.parseInt(resClass.getString(4).substring(3, 5)));
                startTime.set(Calendar.MONTH, newMonth);
                startTime.set(Calendar.YEAR, newYear);
                endTime = (Calendar) startTime.clone();
                endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resClass.getString(5).substring(0, 2)));
                endTime.set(Calendar.MINUTE, Integer.parseInt(resClass.getString(5).substring(3, 5)) - 1);
                event = new WeekViewEvent(200 + Integer.parseInt(resClass.getString(0)),
                        resClass.getString(1), startTime, endTime);
                event.setColor(Color.parseColor(resClass.getString(9)));
                events.add(event);
            }
        }

        //Timetable is rendered 3 times (week, week prior, and week after), this stops duplicates
        boolean examTimetableDisplayed = sharedPref.getBoolean(getString(R.string.sharedpref_exam_timetable_displayed), false);
        if (!examTimetableDisplayed) {
            Cursor resExam = myDb.getAllExamData();
            while (resExam.moveToNext()) {
                startTime = Calendar.getInstance();
                startTime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(resExam.getString(3).substring(0, 2)));
                startTime.set(Calendar.MONTH, Integer.parseInt(resExam.getString(3).substring(3, 5)) - 1);
                startTime.set(Calendar.YEAR, Integer.parseInt(resExam.getString(3).substring(6, 10)));
                startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resExam.getString(4).substring(0, 2)));
                startTime.set(Calendar.MINUTE, Integer.parseInt(resExam.getString(4).substring(3, 5)));
                endTime = (Calendar) startTime.clone();
                endTime.add(Calendar.MINUTE, Integer.parseInt(resExam.getString(5)) - 1);
                event = new WeekViewEvent(300 + Integer.parseInt(resExam.getString(0)),
                        resExam.getString(1).toUpperCase() + " - " + resExam.getString(2).toUpperCase(),
                        startTime, endTime);
                event.setColor(Color.parseColor(resExam.getString(7)));
                events.add(event);

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_exam_timetable_displayed), true);
                editor.commit();
            }
        }

        //Timetable is rendered 3 times (week, week prior, and week after), this stops duplicates
        boolean revisionTimetableDisplayed = sharedPref.getBoolean(getString(R.string.sharedpref_revision_timetable_displayed), false);
        if (!revisionTimetableDisplayed) {
            Cursor resRevision = myDb.getAllRevisionData();
            while (resRevision.moveToNext()) {
                startTime = Calendar.getInstance();
                startTime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(resRevision.getString(3).substring(0, 2)));
                startTime.set(Calendar.MONTH, Integer.parseInt(resRevision.getString(3).substring(3, 5)) - 1);
                startTime.set(Calendar.YEAR, Integer.parseInt(resRevision.getString(3).substring(6, 10)));
                int startColon = resRevision.getString(4).indexOf(":");
                int endColon = resRevision.getString(5).indexOf(":");
                startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resRevision.getString(4).substring(0, startColon)));
                startTime.set(Calendar.MINUTE, Integer.parseInt(resRevision.getString(4).substring(startColon + 1, startColon + 3)));
                endTime = (Calendar) startTime.clone();
                endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resRevision.getString(5).substring(0, endColon)));
                endTime.set(Calendar.MINUTE, Integer.parseInt(resRevision.getString(5).substring(endColon + 1, endColon + 3)) - 1);
                event = new WeekViewEvent(400 + Integer.parseInt(resRevision.getString(0)),
                        "Revision: " + resRevision.getString(1) + " - " + resRevision.getString(2),
                        startTime, endTime);
                if (resRevision.getString(7) == null) {
                    event.setColor(Color.parseColor("#000000"));
                    event.setName("Custom Revision Slot!");
                } else {
                    event.setColor(Color.parseColor(resRevision.getString(7)));
                }
                events.add(event);

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_revision_timetable_displayed), true);
                editor.commit();
            }
        }

        //Timetable is rendered 3 times (week, week prior, and week after), this stops duplicates
        boolean eventTimetableDisplayed = sharedPref.getBoolean(getString(R.string.sharedpref_event_timetable_displayed), false);
        if (!eventTimetableDisplayed) {
            Cursor resEvent = myDb.getAllEventData();
            while (resEvent.moveToNext()) {
                startTime = Calendar.getInstance();
                startTime.set(Calendar.YEAR, Integer.parseInt(resEvent.getString(2).substring(0, 4)));
                startTime.set(Calendar.MONTH, Integer.parseInt(resEvent.getString(2).substring(5, 7)) - 1);
                startTime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(resEvent.getString(2).substring(8, 10)));
                int startColon = resEvent.getString(3).indexOf(":");
                int endColon = resEvent.getString(4).indexOf(":");
                startTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resEvent.getString(3).substring(0, startColon)));
                startTime.set(Calendar.MINUTE, Integer.parseInt(resEvent.getString(3).substring(startColon + 1, startColon + 3)));
                endTime = (Calendar) startTime.clone();
                endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(resEvent.getString(4).substring(0, endColon)));
                endTime.set(Calendar.MINUTE, Integer.parseInt(resEvent.getString(4).substring(endColon + 1, endColon + 3)) - 1);
                event = new WeekViewEvent(100000 + Integer.parseInt(resEvent.getString(0)),
                        resEvent.getString(1), startTime, endTime);
                if (resEvent.getString(5) == null) {
                    event.setColor(Color.parseColor("#607D8B"));
                } else {
                    event.setColor(Color.parseColor(resEvent.getString(5)));
                }
                events.add(event);

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_event_timetable_displayed), true);
                editor.commit();
            }
        }

        return events;
    }

    /**
     * Converts the day string containing the week day, into the weekday value
     * @param day String with name of the day of the week
     * @return The corresponding week day value
     */
    private int dayOfWeek(String day) {
        switch (day) {
            case "Monday":
                return Calendar.MONDAY;
            case "Tuesday":
                return Calendar.TUESDAY;
            case "Wednesday":
                return Calendar.WEDNESDAY;
            case "Thursday":
                return Calendar.THURSDAY;
            case "Friday":
                return Calendar.FRIDAY;
            case "Saturday":
                return Calendar.SATURDAY;
            case "Sunday":
                return Calendar.SUNDAY;
            default:
                return 0;
        }
    }
}
