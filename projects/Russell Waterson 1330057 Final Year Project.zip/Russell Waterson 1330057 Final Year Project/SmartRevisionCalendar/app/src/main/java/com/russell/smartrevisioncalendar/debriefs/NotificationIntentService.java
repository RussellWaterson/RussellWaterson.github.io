package com.russell.smartrevisioncalendar.debriefs;

import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.support.v7.app.NotificationCompat;
import android.util.Log;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * <h1>Notification Intent Service</h1>
 * Creates the notifications
 * <p>
 * When a start notification intent is passed, a new notification is created
 * and shown, in addition to setting pending intents for click and remove actions.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   27-02-2017
 */
public class NotificationIntentService extends IntentService {

    private static final int NOTIFICATION_ID = 1;
    private static final String ACTION_START = "ACTION_START";
    private static final String ACTION_DELETE = "ACTION_DELETE";

    public NotificationIntentService() {
        super(NotificationIntentService.class.getSimpleName());
    }

    /**
     * Creates the intent start notification service
     * @param context The previous context
     * @return The created intent start notification service
     */
    public static Intent createIntentStartNotificationService(Context context) {
        Intent intent = new Intent(context, NotificationIntentService.class);
        intent.setAction(ACTION_START);
        return intent;
    }

    /**
     * Creates the intent to delete the notification
     * @param context The previous context
     * @return The created intent to delete the notification
     */
    public static Intent createIntentDeleteNotification(Context context) {
        Intent intent = new Intent(context, NotificationIntentService.class);
        intent.setAction(ACTION_DELETE);
        return intent;
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(getClass().getSimpleName(), "onHandleIntent, started handling a notification event");
        try {
            String action = intent.getAction();
            if (ACTION_START.equals(action)) {
                DatabaseHelper myDb = DatabaseHelper.getInstance(getApplicationContext().getApplicationContext());
                Cursor res = myDb.getAllRevisionData();
                while (res.moveToNext()) {
                    SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
                    if (dateFormatter.format(Calendar.getInstance().getTime()).equals(res.getString(3))) {
                        processStartNotification();
                        break;
                    }
                }
            }
            if (ACTION_DELETE.equals(action)) {
                processDeleteNotification(intent);
            }
        } finally {
            WakefulBroadcastReceiver.completeWakefulIntent(intent);
        }
    }

    /**
     * When the notification is dismissed
     * @param intent The intent of the deleted notification
     */
    private void processDeleteNotification(Intent intent) {
        //Daily debrief opportunity dismissed
    }

    /**
     * Processes starting of the notification
     */
    private void processStartNotification() {
        final NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle("Daily Debrief")
                .setAutoCancel(true)
                .setColor(getResources().getColor(R.color.colorAccent))
                .setContentText("It's that time of the day again, time for your debrief")
                .setSmallIcon(R.drawable.ic_stat_notification);

        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                NOTIFICATION_ID,
                new Intent(this, DayDebrief.class),
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);
        builder.setDeleteIntent(NotificationEventReceiver.getDeleteIntent(this));

        final NotificationManager manager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, builder.build());
    }
}
