package com.russell.smartrevisioncalendar.newitemscreens;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

/**
 * <h1>Add New Class</h1>
 * The activity that handles the adding of a new class
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   18-01-2017
 */
public class AddClassActivity extends AppCompatActivity {

    DatabaseHelper myDB;

    AutoCompleteTextView moduleNameInput;
    TextInputEditText titleNameInput, teacherInput, roomInput;
    Spinner dayInput;
    TextView startTimeInput, endTimeInput;
    Switch repeatInput;
    View colourInput;
    Button saveButton;

    String tempColour = null;

    SharedPreferences sharedPref;

    boolean valid;
    boolean edit;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class);

        myDB = DatabaseHelper.getInstance(this);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        moduleNameInput = (AutoCompleteTextView) findViewById(R.id.class_module_name_input);
        titleNameInput = (TextInputEditText) findViewById(R.id.class_title_name_input);
        teacherInput = (TextInputEditText) findViewById(R.id.class_teacher_input);
        roomInput = (TextInputEditText) findViewById(R.id.class_room_input);
        startTimeInput = (TextView) findViewById(R.id.class_start_time_input);
        endTimeInput = (TextView) findViewById(R.id.class_end_time_input);
        dayInput = (Spinner) findViewById(R.id.class_day_spinner);
        repeatInput = (Switch) findViewById(R.id.class_repeat_switch);
        colourInput = findViewById(R.id.class_colour_input);

        saveButton = (Button) findViewById(R.id.class_save_button);

        final ArrayList<String> modules = new ArrayList<String>();
        final ArrayList<String> colours = new ArrayList<String>();

        Cursor res = myDB.getAllExamData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }
        res = myDB.getAllClassData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(9));
            }
        }
        res = myDB.getAllRevisionData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_singlechoice, modules);
        moduleNameInput.setThreshold(1);
        moduleNameInput.setAdapter(adapter);
        moduleNameInput.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String moduleColour = colours.get(modules.indexOf(moduleNameInput.getText().toString()));
                colourInput.getBackground().setColorFilter(Color.parseColor(moduleColour), PorterDuff.Mode.SRC_ATOP);
                tempColour = moduleColour;
                Toast.makeText(getApplicationContext(), "Colour changed to match chosen module", Toast.LENGTH_LONG).show();
            }
        });

        startTimeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(AddClassActivity.this, onStartTimeSetListener,
                        Integer.parseInt(startTimeInput.getText().subSequence(0,2).toString()),
                        Integer.parseInt(startTimeInput.getText().subSequence(3,5).toString()),
                        true).show();
            }
        });

        endTimeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(AddClassActivity.this, onEndTimeSetListener,
                        Integer.parseInt(endTimeInput.getText().subSequence(0,2).toString()),
                        Integer.parseInt(endTimeInput.getText().subSequence(3,5).toString()),
                        true).show();
            }
        });

        if (tempColour == null) {
            tempColour = "#03A9F4";
        }
        colourInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creates a dialog showing a list of all the colours available to change to
                AlertDialog.Builder builder = new AlertDialog.Builder(AddClassActivity.this);
                builder.setTitle("Choose a colour");
                builder.setItems(R.array.colours, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        //Once a color is selected, a second array with corresponding color hex's is indexed
                        String hexCode = getResources().getStringArray(R.array.colours_hex_code)[item];
                        colourInput.getBackground().setColorFilter(Color.parseColor(hexCode), PorterDuff.Mode.SRC_ATOP);
                        tempColour = hexCode;
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        edit = sharedPref.getBoolean(getString(R.string.sharedpref_edit_item), false);
        if (edit) {
            id = sharedPref.getString(getString(R.string.sharedpref_edit_id), "0");
            populateFields();
        }

        valid = false;

        addData();
    }

    /**
     * Adds data input into the various types of data fields into the Classes database
     */
    private void addData() {
        saveButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        validate();
                        if (valid) {
                            int repeat = repeatInput.isChecked() ? 1 : 0;
                            if (edit) {
                                //When existing data is to be edited
                                boolean isUpdated = myDB.updateClassData(id,
                                        moduleNameInput.getText().toString(),
                                        titleNameInput.getText().toString(),
                                        dayInput.getSelectedItem().toString(),
                                        startTimeInput.getText().toString(),
                                        endTimeInput.getText().toString(),
                                        repeat,
                                        teacherInput.getText().toString(),
                                        roomInput.getText().toString(),
                                        tempColour);

                                if (isUpdated) {
                                    Toast.makeText(AddClassActivity.this, "Class has successfully been updated", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(AddClassActivity.this, "Class update failed!", Toast.LENGTH_SHORT).show();
                                }

                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                                editor.apply();

                                setResult(RESULT_OK, null);
                                finish();

                            } else {
                                //When new data is to be added
                                boolean isInserted = myDB.insertClassData(moduleNameInput.getText().toString(),
                                        titleNameInput.getText().toString(),
                                        dayInput.getSelectedItem().toString(),
                                        startTimeInput.getText().toString(),
                                        endTimeInput.getText().toString(),
                                        repeat,
                                        teacherInput.getText().toString(),
                                        roomInput.getText().toString(),
                                        tempColour);

                                if (isInserted) {
                                    Toast.makeText(AddClassActivity.this, "Data Successfully Added", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(AddClassActivity.this, "Data Insertion Failed", Toast.LENGTH_SHORT).show();
                                }
                                setResult(RESULT_OK, null);
                                finish();
                            }
                        }
                    }
                }
        );
    }

    /**
     * Validates all the entered data is suitable before adding to the database
     */
    private void validate() {
        String failingText = "";

        //Validate module name - field required
        if (moduleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The class module name must not be empty\n\n");
        }

        //Validate title name - field required
        if (titleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The class title name must not be empty\n\n");
        }

        //Validate start and end time - end time cannot be before or the same as start time
        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        try {
            if (timeDF.parse(startTimeInput.getText().toString()).after(timeDF.parse(endTimeInput.getText().toString()))
                    || timeDF.parse(startTimeInput.getText().toString()).equals(timeDF.parse(endTimeInput.getText().toString()))) {
                failingText = failingText.concat("- End time cannot be before or the same as the start time!\n");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (failingText.isEmpty()) {
            valid = true;
        } else {
            //Show dialog
            new AlertDialog.Builder(this)
                    .setTitle("Failed Validity Check!!")
                    .setMessage(failingText)
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {}
                    })
                    .show();
        }
    }


    /**
     * When existing class data is to be edited, the fields should be populated with the current data
     */
    private void populateFields() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Edit Class");
        }
        Cursor res = myDB.getAllClassData();
        //Locate the class that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                moduleNameInput.setText(res.getString(1));
                titleNameInput.setText(res.getString(2));
                int dayID = 0;
                for (int i = 0; i < dayInput.getAdapter().getCount(); i++) {
                    if (res.getString(3).equals(dayInput.getAdapter().getItem(i))) {
                        dayID = i;
                    }
                }
                dayInput.setSelection(dayID);
                startTimeInput.setText(res.getString(4));
                endTimeInput.setText(res.getString(5));
                repeatInput.setChecked(res.getString(6).equals("1"));
                teacherInput.setText(res.getString(7));
                roomInput.setText(res.getString(8));
                colourInput.getBackground().setColorFilter(Color.parseColor(res.getString(9)), PorterDuff.Mode.SRC_ATOP);
                tempColour = res.getString(9);
            }
        }
        saveButton.setText(R.string.edit);
    }


    /**
     * Sets what happens when a start time is selected from the time picker dialog
     */
    TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            DecimalFormat df = new DecimalFormat("00");
            startTimeInput.setText(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
        }
    };

    /**
     * Sets what happens when an end time is selected from the time picker dialog
     */
    TimePickerDialog.OnTimeSetListener onEndTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            DecimalFormat df = new DecimalFormat("00");
            endTimeInput.setText(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
        }
    };
}
