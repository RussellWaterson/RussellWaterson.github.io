package com.russell.smartrevisioncalendar.mainscreens;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.cloudbackups.GoogleDriveBackup;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.imortgooglecalendar.ImportGoogleCalendarActivity;
import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.settingscreens.SettingsActivity;
import com.russell.smartrevisioncalendar.settingscreens.SmartCalendarDataActivity;
import com.russell.smartrevisioncalendar.startup.StepperActivity;
import com.russell.smartrevisioncalendar.timetablescreens.DayTimetableEvents;
import com.russell.smartrevisioncalendar.timetablescreens.MonthTimetableFragment;
import com.russell.smartrevisioncalendar.timetablescreens.WeekTimetableEvents;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * <h1>Smart Revision Calendar Main</h1>
 * Main Activity is the main activity of the application and is launched when the app is started.
 * From here the user can navigate to all parts of the application.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-12-2016
 */
public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    SharedPreferences sharedPref;
    FragmentManager fragmentManager;
    ActionBar actionBar;
    Spinner spinner;

    /**
     * Create the main activity.
     * @param savedInstanceState previously saved instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        navigationView.setNavigationItemSelectedListener(this);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        TextView userNameTextView = (TextView) headerView.findViewById(R.id.user_name_textView);
        userNameTextView.setText(sharedPref.getString(getString(R.string.sharedpref_user_name), getString(R.string.app_name)));

        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottom_navigation);


        //Determines whether the first time start up needs to be ran
        boolean firstTimeBoot = sharedPref.getBoolean(getString(R.string.sharedpref_first_boot_completed), false);
        boolean firstBootFinished = false;
        if (!firstTimeBoot) {
            System.out.println("First time boot...");
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean(getString(R.string.sharedpref_first_boot_completed), true);
            editor.commit();
            startActivity(new Intent(MainActivity.this, StepperActivity.class));
            firstBootFinished = true;
        }
        if (firstBootFinished) {
            new AlertDialog.Builder(this)
                    .setTitle("Welcome!")
                    .setIcon(R.mipmap.ic_launcher_circle)
                    .setMessage("Welcome to the main screens of the app! Towards the bottom of the screen "
                            + "you'll see how to navigate between these screens, showing sections for "
                            + "timetable, exams and deadlines, classes and lectures, and extra curricular "
                            + "activities.\n\n"
                            + "At the top of the timetable screen you can access a dropdown which will "
                            + "change the display to day, week, and month views!\n\n"
                            + "And finally in the side drawer, you have access to other features of the "
                            + "application, including access to, and creation of, smart revision data!\n\n"
                            + "Thanks for downloading Smart Revision Calendar! Enjoy!")
                    .setPositiveButton("Thanks", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {}
                    })
                    .show();
        }

        SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
        Calendar today = Calendar.getInstance();
        //If the current date does not match the stored date
        if (!dateDF.format(today.getTime()).equals(sharedPref.getString(getString(R.string.sharedpref_exam_date_check), "00-00-0000"))) {
            //Store the new date as it will now be checked
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getString(R.string.sharedpref_exam_date_check), dateDF.format(today.getTime()));
            editor.apply();
            //Go through the exam database
            DatabaseHelper myDb = DatabaseHelper.getInstance(MainActivity.this);
            Cursor res = myDb.getAllExamData();
            while (res.moveToNext()) {
                //If an exam date matches today
                if (dateDF.format(today.getTime()).equals(res.getString(3))) {
                    //Show a dialog to inform the user of the revision for an exam day
                    new AlertDialog.Builder(this)
                            .setTitle("Exam Day!!!")
                            .setMessage("Today is the day of your exam! For today you may have noticed " +
                                    "the lack of revision in the timetable, well that's deliberate! " +
                                    "Go ahead and devote all your time before your exam to some last " +
                                    "minute prep. Then for after, feel free to take a breather!\n")
                            .setPositiveButton("Good Luck", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            })
                            .show();
                }
            }
        }

        fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.content_frame, new DayTimetableEvents()).commit();

        actionBar = getSupportActionBar();

        spinner = (Spinner) findViewById(R.id.spinner_nav);

        //Custom Spinner OnItemSelectedListener inner class to define the selection event handler
        //for the spinner when an item is selected from the dropdown
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        fragmentManager.beginTransaction()
                                .replace(R.id.content_frame, new DayTimetableEvents()).commit();
                        break;
                    case 1:
                        fragmentManager.beginTransaction()
                                .replace(R.id.content_frame, new WeekTimetableEvents()).commit();
                        break;
                    case 2:
                        fragmentManager.beginTransaction()
                                .replace(R.id.content_frame, new MonthTimetableFragment()).commit();
                        break;
                }
                if (actionBar != null) {
                    actionBar.setTitle("Today is " + new SimpleDateFormat("EEEE", Locale.UK)
                            .format(Calendar.getInstance().getTime().getTime()) + ":");
                }
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_exam_timetable_displayed), false);
                editor.putBoolean(getString(R.string.sharedpref_revision_timetable_displayed), false);
                editor.putBoolean(getString(R.string.sharedpref_event_timetable_displayed), false);
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // An interface callback
            }
        });

        //Custom Bottom Nav OnNavigationItemSelectedListener inner class to define the selection
        //event handler for the bottom nav when an item is selected
        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_timetable:
                                switch (spinner.getSelectedItemPosition()) {
                                    case 0:
                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, new DayTimetableEvents()).commit();
                                        break;
                                    case 1:
                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, new WeekTimetableEvents()).commit();
                                        break;
                                    case 2:
                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, new MonthTimetableFragment()).commit();
                                        break;
                                }
                                if (actionBar != null) {
                                    actionBar.setTitle("Today is " + new SimpleDateFormat("EEEE", Locale.UK)
                                            .format(Calendar.getInstance().getTime().getTime()) + ":");
                                }
                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putBoolean(getString(R.string.sharedpref_exam_timetable_displayed), false);
                                editor.putBoolean(getString(R.string.sharedpref_revision_timetable_displayed), false);
                                editor.putBoolean(getString(R.string.sharedpref_event_timetable_displayed), false);
                                editor.commit();
                                spinner.setEnabled(true);
                                spinner.setVisibility(View.VISIBLE);
                                return true;

                            case R.id.action_exams:
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_frame, new ExamsFragment()).commit();
                                if (actionBar != null) {
                                    DatabaseHelper myDb = DatabaseHelper.getInstance(MainActivity.this);
                                    Cursor res = myDb.getAllExamData();
                                    int upcomingExams = 0;
                                    Date now = new Date();
                                    SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
                                    while (res.moveToNext()) {
                                        try {
                                            if (dateDF.parse(res.getString(3)).after(now)){
                                                upcomingExams++;
                                            }
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    actionBar.setTitle("Upcoming Exams: " + upcomingExams);
                                }
                                spinner.setEnabled(false);
                                spinner.setVisibility(View.GONE);
                                return true;

                            case R.id.action_classes:
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_frame, new ClassesFragment()).commit();
                                if (actionBar != null) {
                                    actionBar.setTitle(R.string.app_name);
                                }
                                spinner.setEnabled(false);
                                spinner.setVisibility(View.GONE);
                                return true;

                            case R.id.action_activities:
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_frame, new ActivitiesFragment()).commit();
                                if (actionBar != null) {
                                    actionBar.setTitle(R.string.app_name);
                                }
                                spinner.setEnabled(false);
                                spinner.setVisibility(View.GONE);
                                return true;
                        }
                        return false;
                    }
                });

        final TextView backupFooter = (TextView) findViewById(R.id.nav_drawer_last_backup);
        backupFooter.setText("Last Backup: " + sharedPref.getString(getString(R.string.sharedpref_last_backup), "Never"));
        backupFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Back up to cloud
                startActivity(new Intent(getApplicationContext(), GoogleDriveBackup.class));
                SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy - HH:mm", Locale.UK);
                Calendar newDate = Calendar.getInstance();
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString(getString(R.string.sharedpref_last_backup), dateFormatter.format(newDate.getTime()));
                editor.commit();
                backupFooter.setText("Last Backup: " + sharedPref.getString(getString(R.string.sharedpref_last_backup), "Never"));
            }
        });
    }

    /**
     * Take care of popping the fragment back stack or finishing the activity
     * as appropriate. Will close the side navigation draw if open.
     */
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    /**
     * Called when an item in the navigation menu is selected.
     * @param item The selected item
     * @return true to display the item as the selected item
     */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_smart_calendar_data) {
            // Handle the smart calendar data action
            startActivity(new Intent(getApplicationContext(), SmartCalendarDataActivity.class));
        } else if (id == R.id.nav_import_google_calendar) {
            // Handle the import google calendar action
            startActivity(new Intent(getApplicationContext(), ImportGoogleCalendarActivity.class));
        } else if (id == R.id.nav_settings) {
            startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
