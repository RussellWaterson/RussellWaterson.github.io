package com.russell.smartrevisioncalendar.customcomponents;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;

/**
 * <h1>Reusable Imported Google Event Component</h1>
 * Reusable custom component for displaying an individual event taken from the user's Google Calendar
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   16-03-2017
 */
public class GoogleCalendarEventComponent extends RelativeLayout {

    TextView eventName, eventDateTime;
    CheckBox checkBox;
    View colour;

    String tempColour;

    public GoogleCalendarEventComponent(Context context) {
        super(context);
        init(context);

    }

    public GoogleCalendarEventComponent(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public GoogleCalendarEventComponent(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    /**
     * Initialise the custom google event component
     * @param context The calling activity context
     */
    private void init(final Context context) {
        View.inflate(context, R.layout.custom_component_google_cal, this);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        eventName = (TextView) findViewById(R.id.gc_component_event_name);
        eventDateTime = (TextView) findViewById(R.id.gc_component_date_time);
        checkBox = (CheckBox) findViewById(R.id.gc_component_checkbox);
        colour = findViewById(R.id.gc_component_colour);

        tempColour = "#607D8B";
    }

    /**
     * Sets the event name text
     * @param text New event name
     */
    public void setEventName(String text) {
        eventName.setText(text);
    }

    /**
     * Gets the current event name
     * @return The current event name
     */
    public String getEventName() { return eventName.getText().toString(); }

    /**
     * Sets the event date and time text
     * @param text The new date and time
     */
    public void setEventDateTime(String text) {
        eventDateTime.setText(text);
    }

    /**
     * Gets the current date and time
     * @return The current date and time
     */
    public String getEventDateTime() { return eventDateTime.getText().toString(); }

    /**
     * Gets the current checkbox value, true for checked, false for unchecked
     * @return The current checkbox state
     */
    public boolean getCheckBox() { return checkBox.isChecked(); }

    /**
     * Sets the colour of the event
     * @param text New colour
     */
    public void setColour(String text) { tempColour = text; }

    /**
     * Gets the current colour of the event
     * @return The current colour
     */
    public String getColour() { return tempColour; }

    /**
     * Gets the view for which the colour is represented by
     * @return The colour changer view
     */
    public View getColourView() { return colour; }
}
