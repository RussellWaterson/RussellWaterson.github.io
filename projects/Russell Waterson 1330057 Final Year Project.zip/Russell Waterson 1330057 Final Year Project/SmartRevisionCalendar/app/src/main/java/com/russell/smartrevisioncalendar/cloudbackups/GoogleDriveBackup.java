package com.russell.smartrevisioncalendar.cloudbackups;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.MetadataChangeSet;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import org.apache.commons.io.IOUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * <h1>Google Drive API implementation in the form of cloud backups</h1>
 * The GoogleDriveBackup activity is where the Google Drive API is implemented, and from here the
 * backups are made.
 * <p>
 * This class creates a text file and gets the database file which are then backed up to the user's
 * Google Drive cloud storage using the Google Drive API.
 *
 * @see <a href="https://developers.google.com/drive/android/">https://developers.google.com/drive/android/</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   24-02-2017
 */
public class GoogleDriveBackup extends Activity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = "smart-revision-calendar";
    private static final int REQUEST_CODE_TEXT_SAVED = 1;
    private static final int REQUEST_CODE_DB_SAVED = 2;
    private static final int REQUEST_CODE_RESOLUTION = 3;

    private GoogleApiClient mGoogleApiClient;

    private String backupString = "";
    DatabaseHelper myDb;

    /**
     * Create the Google Drive backup activity.
     * @param savedInstanceState previously saved instance data.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Create the API client and bind it to an instance variable.
        //Uses this instance as the callback for connection and connection failures.
        //Since no account name is passed, the user is prompted to choose.
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Drive.API)
                .addScope(Drive.SCOPE_FILE)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_RESOLUTION:
                if (resultCode == RESULT_OK) {
                    mGoogleApiClient.connect();
                }
                break;
            case REQUEST_CODE_TEXT_SAVED:
                // Called after text file is saved to Drive.
                if (resultCode == RESULT_OK) {
                    Log.i(TAG, "File successfully saved.");
                }
                saveDbFileToDrive();
                break;
            case REQUEST_CODE_DB_SAVED:
                // Called after database file is saved to Drive.
                if (resultCode == RESULT_OK) {
                    Log.i(TAG, "File successfully saved.");
                }
                finish();
                break;
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.i(TAG, "API client connected.");
        createBackupString();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "GoogleApiClient connection suspended");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        //Called whenever the API client fails to connect.
        Log.i(TAG, "GoogleApiClient connection failed: " + connectionResult.toString());

        if (!connectionResult.hasResolution()) {
            //Shows the localised error dialog.
            GoogleApiAvailability.getInstance().getErrorDialog(this, connectionResult.getErrorCode(), 0).show();
            return;
        }

        //When the failure has a resolution, resolve it
        //Called typically when the app is not yet authorized, and an authorization
        //dialog is displayed to the user.
        try {
            connectionResult.startResolutionForResult(this, REQUEST_CODE_RESOLUTION);
        } catch (IntentSender.SendIntentException e) {
            Log.e(TAG, "Exception while starting resolution activity", e);
        }
    }

    /**
     * Save the generated text file to Google Drive
     */
    private void saveTextFileToDrive() {
        //Create contents and set a callback.
        Log.i(TAG, "Creating new contents.");
        Toast.makeText(getApplicationContext(), "1. Saving backup in text form...", Toast.LENGTH_LONG).show();
        Drive.DriveApi.newDriveContents(mGoogleApiClient)
                .setResultCallback(new ResultCallback<DriveApi.DriveContentsResult>() {

                    @Override
                    public void onResult(DriveApi.DriveContentsResult result) {
                        //If the operation was not successful, nothing can be done and must fail.
                        if (!result.getStatus().isSuccess()) {
                            Log.i(TAG, "Failed to create new contents.");
                            return;
                        }

                        //Otherwise, write data to the new contents using an output stream
                        Log.i(TAG, "New contents created.");
                        OutputStream outputStream = result.getDriveContents().getOutputStream();

                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        try {
                            byteArrayOutputStream.write(backupString.getBytes());
                            outputStream.write(byteArrayOutputStream.toByteArray());
                        } catch (IOException e) {
                            Log.i(TAG, "Unable to write file contents.");
                        }

                        //Create the initial metadata - MIME type and title
                        //The user is able to change the title later
                        MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
                                .setMimeType("text/plain").setTitle("Smart Revision Calendar Backup.txt").build();
                        //Create an intent for the file chooser, and start it.
                        IntentSender intentSender = Drive.DriveApi
                                .newCreateFileActivityBuilder()
                                .setInitialMetadata(metadataChangeSet)
                                .setInitialDriveContents(result.getDriveContents())
                                .build(mGoogleApiClient);
                        try {
                            startIntentSenderForResult(intentSender, REQUEST_CODE_TEXT_SAVED, null, 0, 0, 0);
                        } catch (IntentSender.SendIntentException e) {
                            Log.i(TAG, "Failed to launch file chooser.");
                        }
                    }
                });
    }

    /**
     * Save the actual database file to Google Drive
     */
    private void saveDbFileToDrive() {
        Toast.makeText(getApplicationContext(), "2. Saving backup in raw database form...", Toast.LENGTH_LONG).show();

        Drive.DriveApi.newDriveContents(mGoogleApiClient)
                .setResultCallback(new ResultCallback<DriveApi.DriveContentsResult>() {

                    @Override
                    public void onResult(DriveApi.DriveContentsResult result) {
                        //If the operation was not successful, nothing can be done and must fail.
                        if (!result.getStatus().isSuccess()) {
                            Log.i(TAG, "Failed to create new contents.");
                            return;
                        }

                        //Otherwise, write data to the new contents using an output stream
                        Log.i(TAG, "New contents created.");
                        OutputStream outputStream = result.getDriveContents().getOutputStream();

                        try {
                            //Getting the database file and writing it to an input stream
                            //Then writing the input stream to a byte array, then to the output stream
                            File dataEnv = Environment.getDataDirectory();
                            String currentDBPath = "/data/" + getPackageName() + "/databases/Calendar.db";
                            File currentDB = new File(dataEnv, currentDBPath);
                            InputStream is = new FileInputStream(currentDB);

                            byte[] bytes = IOUtils.toByteArray(is);

                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                            byteArrayOutputStream.write(bytes);
                            outputStream.write(byteArrayOutputStream.toByteArray());
                        } catch (IOException e) {
                            Log.i(TAG, "Unable to write file contents.");
                            e.printStackTrace();
                        }

                        //Create the initial metadata - MIME type and title
                        //The user is able to change the title later
                        MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
                                .setMimeType("application/x-sqlite3").setTitle("Database Backup.db").build();
                        //Create an intent for the file chooser, and start it.
                        IntentSender intentSender = Drive.DriveApi
                                .newCreateFileActivityBuilder()
                                .setInitialMetadata(metadataChangeSet)
                                .setInitialDriveContents(result.getDriveContents())
                                .build(mGoogleApiClient);
                        try {
                            startIntentSenderForResult(intentSender, REQUEST_CODE_DB_SAVED, null, 0, 0, 0);
                        } catch (IntentSender.SendIntentException e) {
                            Log.i(TAG, "Failed to launch file chooser.");
                        }
                    }
                });
    }

    /**
     * Creates the string containing all the information in the databases
     */
    private void createBackupString() {
        myDb = DatabaseHelper.getInstance(getApplicationContext());

        backupString = backupString.concat("******************\n");
        backupString = backupString.concat("*  CLASS TABLE   *\n");
        backupString = backupString.concat("******************\n\n");

        Cursor res = myDb.getAllClassData();

        if (res.getCount() == 0) {
            backupString = backupString.concat("There are no classes in the database\n\n");
        } else {
            while (res.moveToNext()) {
                backupString = backupString.concat("ID:                 " + res.getString(0) + "\n");
                backupString = backupString.concat("Module:             " + res.getString(1) + "\n");
                backupString = backupString.concat("Title:              " + res.getString(2) + "\n");
                backupString = backupString.concat("Day:                " + res.getString(3) + "\n");
                backupString = backupString.concat("Start Time:         " + res.getString(4) + "\n");
                backupString = backupString.concat("End Time:           " + res.getString(5) + "\n");
                backupString = backupString.concat("Repeats weekly:     " + res.getString(6) + "\n");
                backupString = backupString.concat("Teacher / Lecturer: " + res.getString(7) + "\n");
                backupString = backupString.concat("Room:               " + res.getString(8) + "\n");
                backupString = backupString.concat("Colour:             " + res.getString(9) + "\n\n");
            }
        }

        backupString = backupString.concat("******************\n");
        backupString = backupString.concat("* ACTIVITY TABLE *\n");
        backupString = backupString.concat("******************\n\n");

        res = myDb.getAllActivityData();

        if (res.getCount() == 0) {
            backupString = backupString.concat("There are no activities in the database\n\n");
        } else {
            while (res.moveToNext()) {
                backupString = backupString.concat("ID:                 " + res.getString(0) + "\n");
                backupString = backupString.concat("Activity            " + res.getString(1) + "\n");
                backupString = backupString.concat("Day:                " + res.getString(2) + "\n");
                backupString = backupString.concat("Start Time:         " + res.getString(3) + "\n");
                backupString = backupString.concat("End Time:           " + res.getString(4) + "\n");
                backupString = backupString.concat("Repeats weekly:     " + res.getString(5) + "\n");
                backupString = backupString.concat("Colour:             " + res.getString(6) + "\n\n");
            }
        }

        backupString = backupString.concat("******************\n");
        backupString = backupString.concat("*   EXAM TABLE   *\n");
        backupString = backupString.concat("******************\n\n");

        res = myDb.getAllExamData();

        if (res.getCount() == 0) {
            backupString = backupString.concat("There are no exams in the database\n\n");
        } else {
            while (res.moveToNext()) {
                backupString = backupString.concat("ID:                 " + res.getString(0) + "\n");
                backupString = backupString.concat("Module:             " + res.getString(1) + "\n");
                backupString = backupString.concat("Title:              " + res.getString(2) + "\n");
                backupString = backupString.concat("Date:               " + res.getString(3) + "\n");
                backupString = backupString.concat("Start Time:         " + res.getString(4) + "\n");
                backupString = backupString.concat("Duration:           " + res.getString(5) + "\n");
                backupString = backupString.concat("Info:               " + res.getString(6) + "\n");
                backupString = backupString.concat("Colour:             " + res.getString(7) + "\n");
                backupString = backupString.concat("Content Size:       " + res.getString(8) + "\n");
                backupString = backupString.concat("Priority:           " + res.getString(9) + "\n\n");
            }
        }

        backupString = backupString.concat("******************\n");
        backupString = backupString.concat("*  EVENTS TABLE  *\n");
        backupString = backupString.concat("******************\n\n");

        res = myDb.getAllEventData();

        if (res.getCount() == 0) {
            backupString = backupString.concat("There are no imported events in the database\n\n");
        } else {
            while (res.moveToNext()) {
                backupString = backupString.concat("ID:                 " + res.getString(0) + "\n");
                backupString = backupString.concat("Title:              " + res.getString(1) + "\n");
                backupString = backupString.concat("Date:               " + res.getString(2) + "\n");
                backupString = backupString.concat("Start Time:         " + res.getString(3) + "\n");
                backupString = backupString.concat("End Time:           " + res.getString(4) + "\n");
                backupString = backupString.concat("Colour:             " + res.getString(5) + "\n\n");
            }
        }

        backupString = backupString.concat("******************\n");
        backupString = backupString.concat("* REVISION TABLE *\n");
        backupString = backupString.concat("******************\n\n");

        res = myDb.getAllRevisionData();

        if (res.getCount() == 0) {
            backupString = backupString.concat("There is no revision in the database\n\n");
        } else {
            while (res.moveToNext()) {
                backupString = backupString.concat("ID:                 " + res.getString(0) + "\n");
                backupString = backupString.concat("Module:             " + res.getString(1) + "\n");
                backupString = backupString.concat("Title:              " + res.getString(2) + "\n");
                backupString = backupString.concat("Date:               " + res.getString(3) + "\n");
                backupString = backupString.concat("Start Time:         " + res.getString(4) + "\n");
                backupString = backupString.concat("End Time:           " + res.getString(5) + "\n");
                backupString = backupString.concat("Notes:              " + res.getString(6) + "\n");
                backupString = backupString.concat("Colour:             " + res.getString(7) + "\n\n");
            }
        }

        saveTextFileToDrive();
    }
}