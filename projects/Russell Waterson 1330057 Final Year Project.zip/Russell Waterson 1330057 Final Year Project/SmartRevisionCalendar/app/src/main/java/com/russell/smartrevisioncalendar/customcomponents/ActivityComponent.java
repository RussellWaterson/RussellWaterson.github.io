package com.russell.smartrevisioncalendar.customcomponents;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.mainscreens.IndividualItemScreen;

/**
 * <h1>Reusable Activities Component</h1>
 * Reusable custom component for displaying activities in the database on the activities fragment
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   23-01-2017
 */
public class ActivityComponent extends RelativeLayout {

    TextView activity, timeDay;
    View repeat, colouredLine;
    Rect hitRect;
    String id;

    SharedPreferences sharedPref;

    public ActivityComponent(Context context) {
        super(context);
        init(context);
    }

    public ActivityComponent(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ActivityComponent(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    /**
     * Initialise the custom activity component
     * @param context The calling activity context
     */
    private void init(Context context) {
        View.inflate(context, R.layout.custom_component_activity,this);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        activity = (TextView) findViewById(R.id.a_component_activity);
        timeDay = (TextView) findViewById(R.id.a_component_time_day);
        repeat = findViewById(R.id.a_component_repeat);
        colouredLine = findViewById(R.id.a_component_coloured_line);
        hitRect = new Rect();
        sharedPref = PreferenceManager.getDefaultSharedPreferences(getContext());
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.getHitRect(hitRect);
                if (hitRect.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
                    motionEvent.setLocation(0.0f, 0.0f);
                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_id), id);
                    editor.commit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_table), "activityTable");
                    editor.commit();
                    System.out.println(sharedPref.getString(getContext().getString(R.string.sharedpref_edit_id), "no") + "   "
                            + sharedPref.getString(getContext().getString(R.string.sharedpref_edit_table), "no"));
                    getContext().startActivity(new Intent(getContext(), IndividualItemScreen.class));
                }
                return true;
            }
        });
    }

    /**
     * Sets the activity name text
     * @param text New activity name
     */
    public void setActivity(String text) {
        activity.setText(text);
    }

    /**
     * Sets the time and day text
     * @param text New activity time and day
     */
    public void setTimeDayText(String text) {
        timeDay.setText(text);
    }

    /**
     * Sets whether the repeat icon is visible or not
     * @param set True to show icon, false to hide icon
     */
    public void setRepeat (Boolean set) {
        if(set) { repeat.setVisibility(View.VISIBLE); }
    }

    /**
     * Sets the colour of the line displayed by the activity
     * @param text New line colour
     */
    public void setColouredLine(String text) {
        colouredLine.getBackground().setColorFilter(Color.parseColor(text), PorterDuff.Mode.SRC_ATOP);
    }

    /**
     * Sets the ID of the activity
     * @param text New activity ID
     */
    public void setID(String text) { id = text; }
}
