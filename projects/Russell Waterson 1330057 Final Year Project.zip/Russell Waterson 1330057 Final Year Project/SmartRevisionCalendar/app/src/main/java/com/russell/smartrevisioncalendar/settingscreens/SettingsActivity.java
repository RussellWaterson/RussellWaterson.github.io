package com.russell.smartrevisioncalendar.settingscreens;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.BuildConfig;
import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.mutephone.EndMute;
import com.russell.smartrevisioncalendar.mutephone.StartMute;
import com.russell.smartrevisioncalendar.startup.StepperActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * <h1>Settings Activity</h1>
 * The settings screen for the app
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   18-01-2017
 */
public class SettingsActivity extends AppCompatActivity {

    private static PendingIntent startPendingIntent;
    private static AlarmManager startManager;
    private static PendingIntent endPendingIntent;
    private static AlarmManager endManager;

    private static final int NOTIFICATIONS_INTERVAL_IN_DAYS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Fragment fragment = new Settings();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if(savedInstanceState == null) {
            //created for the first time
            fragmentTransaction.add(R.id.activity_settings, fragment, "settings_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("settings_fragment");
        }

        // Retrieve a PendingIntent that will perform a broadcast
        Intent startAlarmIntent = new Intent(this, StartMute.class);
        startPendingIntent = PendingIntent.getBroadcast(this, 0, startAlarmIntent, 0);
        Intent endAlarmIntent = new Intent(this, EndMute.class);
        endPendingIntent = PendingIntent.getBroadcast(this, 0, endAlarmIntent, 0);
    }

    /**
     * Inner class to create settings preferences from xml
     * {@inheritDoc}
     */
    public static class Settings extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.settings);

            final SwitchPreference mutePhone = (SwitchPreference) findPreference("preference_mute_phone");
            Preference rerunSetup = findPreference("preference_rerun_setup");
            Preference changelog = findPreference("preference_changelog");
            Preference about = findPreference("preference_about");
            Preference contactMe = findPreference("preference_contact_me");

            mutePhone.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if ((Boolean) newValue) {
                        //Mute phone during work hours
                        Toast.makeText(getActivity(), "Setting up daily muting...", Toast.LENGTH_SHORT).show();
                        startMute(getActivity());
                        endMute(getActivity());
                    } else {
                        //Turn off muting
                        AudioManager audioManager = (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);
                        audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                        cancelStartMute(getActivity());
                        cancelEndMute(getActivity());
                    }
                    return true;
                }
            });

            rerunSetup.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    startActivity(new Intent(getActivity(), StepperActivity.class));
                    return true;
                }
            });

            changelog.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    new AlertDialog.Builder(getActivity())
                            .setTitle("Current Version: " + BuildConfig.VERSION_NAME)
                            .setMessage("1.0: Initial Release")
                            .show();
                    return true;
                }
            });

            about.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    new AlertDialog.Builder(getActivity())
                            .setTitle("About Smart Revision Calendar")
                            .setIcon(R.mipmap.ic_launcher_circle)
                            .setMessage("This application was created as a Computer Science degree final year project. \n\n" +
                                    "The proposed project is to create a smart revision timetable and calendar " +
                                    "application. This mobile application is targeted towards students and " +
                                    "allows them to create a work timetable with minimal effort. The premise is, " +
                                    "the user enters various inputs, including their class times, extracurricular " +
                                    "activities, exams and deadlines, and their preferred learning style. The " +
                                    "application will then generate a revision timetable around the classes and " +
                                    "activities with the exams as goals to work towards. At the end of each revision " +
                                    "block and/or day, the user can give feedback on how productive they have been. " +
                                    "This feedback, along with the learning style, means that the more the user uses " +
                                    "the system, the more the timetable will learn and be tailored to that " +
                                    "particular user.\n\n" + getString(R.string.startup1_disclaimer) + "\n")
                            .show();
                    return true;
                }
            });

            contactMe.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("message/rfc822");
                    i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"rwatersondev@gmail.com"});
                    i.putExtra(Intent.EXTRA_SUBJECT, "Smart Revision Calendar");
                    try {
                        startActivity(Intent.createChooser(i, "Send mail..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(getActivity(), "There are no email clients installed.", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
            });
        }
    }

    /**
     * Sets up the reoccurring muting of the phone every day at the user's preferred start time
     * @param context The previous context
     */
    public static void startMute(Context context) {
        startManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);

        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        Date currentStartTime = new Date();
        try {
            currentStartTime = timeDF.parse(sharedPref.getString(context.getString(R.string.sharedpref_preferred_start_time), "00:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        startManager.setRepeating(AlarmManager.RTC_WAKEUP,
                getTriggerAt(currentStartTime),
                NOTIFICATIONS_INTERVAL_IN_DAYS * AlarmManager.INTERVAL_DAY,
                startPendingIntent);
    }

    /**
     * Sets up the reoccurring un-muting of the phone every day at the user's preferred end time
     * @param context The previous context
     */
    public static void endMute(Context context) {
        endManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);

        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        Date currentEndTime = new Date();
        try {
            currentEndTime = timeDF.parse(sharedPref.getString(context.getString(R.string.sharedpref_preferred_end_time), "00:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        endManager.setRepeating(AlarmManager.RTC_WAKEUP,
                getTriggerAt(currentEndTime),
                NOTIFICATIONS_INTERVAL_IN_DAYS * AlarmManager.INTERVAL_DAY,
                endPendingIntent);
    }

    /**
     * Cancelled the reoccurring muting of the phone every day at the user's preferred start time
     * @param context The previous context
     */
    public static void cancelStartMute(Context context) {
        Intent alarmIntent = new Intent(context, StartMute.class);
        startPendingIntent = PendingIntent.getBroadcast(context, 0, alarmIntent, 0);
        startManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        startManager.cancel(startPendingIntent);
    }

    /**
     * Cancelled the reoccurring un-muting of the phone every day at the user's preferred end time
     * @param context The previous context
     */
    public static void cancelEndMute(Context context) {
        Intent alarmIntent = new Intent(context, EndMute.class);
        endPendingIntent = PendingIntent.getBroadcast(context, 0, alarmIntent, 0);
        endManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        endManager.cancel(endPendingIntent);
    }

    /**
     * Create the time and date in which to start the muting and un-muting daily repeats
     * @param timeToSet The date/time of when to set the intent
     * @return The date/time parameter, but for the current day
     */
    private static long getTriggerAt(Date timeToSet) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        Calendar endTime = Calendar.getInstance();
        endTime.setTime(timeToSet);
        int hour = endTime.get(Calendar.HOUR_OF_DAY);
        int minute = endTime.get(Calendar.MINUTE);

        calendar.set(year, month, day, hour, minute);
        return calendar.getTimeInMillis();
    }
}
