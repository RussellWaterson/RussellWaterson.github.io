package com.russell.smartrevisioncalendar.startup;

import android.content.Context;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;

import com.russell.smartrevisioncalendar.R;
import com.stepstone.stepper.Step;
import com.stepstone.stepper.adapter.AbstractFragmentStepAdapter;
import com.stepstone.stepper.viewmodel.StepViewModel;

/**
 * <h1>Fragment Step Adapter</h1>
 * Extending the FragmentPagerAdapter, it loads the layout fragments for each stepper screen
 * <p>
 * Guided from android-material-stepper sample:
 * <a href="https://github.com/stepstone-tech/android-material-stepper">
 *     https://github.com/stepstone-tech/android-material-stepper</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   13-02-2017
 */
public class FragmentStepAdapter extends AbstractFragmentStepAdapter {

    public FragmentStepAdapter(@NonNull FragmentManager fm, @NonNull Context context) {
        super(fm, context);
    }

    @NonNull
    @Override
    public StepViewModel getViewModel(@IntRange(from = 0) int position) {
        return new StepViewModel.Builder(context)
                .setTitle("Tab Title")
                .create();
    }

    @Override
    public Step createStep(@IntRange(from = 0L) int position) {
        switch (position) {
            case 0:
                return StepFragment.newInstance(R.layout.startup_fragment_welcome_step1);
            case 1:
                return StepFragment.newInstance(R.layout.startup_fragment_classes_step2);
            case 2:
                return StepFragment.newInstance(R.layout.startup_fragment_activities_step3);
            case 3:
                return StepFragment.newInstance(R.layout.startup_fragment_calsync_step4);
            case 4:
                return StepFragment.newInstance(R.layout.startup_fragment_backup_step5);
            case 5:
                return StepFragment.newInstance(R.layout.startup_fragment_smart_explain_step6);
            case 6:
                return StepFragment.newInstance(R.layout.startup_fragment_exams_step7);
            case 7:
                return StepFragment.newInstance(R.layout.startup_fragment_learning_style_step8);
            case 8:
                return StepFragment.newInstance(R.layout.startup_fragment_debriefs_step9);
            default:
                throw new IllegalArgumentException("Unsupported position: " + position);
        }
    }

    @Override
    public int getCount() {
        return 9;
    }
}
