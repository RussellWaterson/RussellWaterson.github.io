package com.russell.smartrevisioncalendar.newitemscreens;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * <h1>Edit Revision</h1>
 * The activity that handles the editing of a revision slot
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-02-2017
 */
public class EditRevisionActivity extends AppCompatActivity {

    DatabaseHelper myDB;

    AutoCompleteTextView moduleNameInput;
    TextInputEditText titleNameInput;
    TextView dateInput, startTimeInput, endTimeInput;
    EditText notesInput;
    View colourInput;

    Button editButton;

    String tempColour = null;

    Calendar calendar = Calendar.getInstance();

    SharedPreferences sharedPref;

    boolean valid;
    boolean edit;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_revision);

        myDB = DatabaseHelper.getInstance(this);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        moduleNameInput = (AutoCompleteTextView) findViewById(R.id.revision_module_name_input);
        titleNameInput = (TextInputEditText) findViewById(R.id.revision_title_name_input);
        dateInput = (TextView) findViewById(R.id.revision_date_input);
        startTimeInput = (TextView) findViewById(R.id.revision_start_time_input);
        endTimeInput = (TextView) findViewById(R.id.revision_end_time_input);
        notesInput = (EditText) findViewById(R.id.revision_notes_input);
        colourInput = findViewById(R.id.revision_colour_input);

        editButton = (Button) findViewById(R.id.revision_edit_button);

        final ArrayList<String> modules = new ArrayList<String>();
        final ArrayList<String> colours = new ArrayList<String>();

        Cursor res = myDB.getAllExamData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }
        res = myDB.getAllClassData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(9));
            }
        }
        res = myDB.getAllRevisionData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_singlechoice, modules);
        moduleNameInput.setThreshold(1);
        moduleNameInput.setAdapter(adapter);
        moduleNameInput.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String moduleColour = colours.get(modules.indexOf(moduleNameInput.getText().toString()));
                colourInput.getBackground().setColorFilter(Color.parseColor(moduleColour), PorterDuff.Mode.SRC_ATOP);
                tempColour = moduleColour;
                Toast.makeText(getApplicationContext(), "Colour changed to match chosen module", Toast.LENGTH_LONG).show();
            }
        });

        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(EditRevisionActivity.this, onDateSetListener,
                        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        startTimeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(EditRevisionActivity.this, onStartTimeSetListener,
                        Integer.parseInt(startTimeInput.getText().subSequence(0,2).toString()),
                        Integer.parseInt(startTimeInput.getText().subSequence(3,5).toString()),
                        true).show();
            }
        });

        endTimeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(EditRevisionActivity.this, onEndTimeSetListener,
                        Integer.parseInt(endTimeInput.getText().subSequence(0,2).toString()),
                        Integer.parseInt(endTimeInput.getText().subSequence(3,5).toString()),
                        true).show();
            }
        });

        if (tempColour == null) {
            tempColour = "#03A9F4";
        }
        colourInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creates a dialog showing a list of all the colours available to change to
                AlertDialog.Builder builder = new AlertDialog.Builder(EditRevisionActivity.this);
                builder.setTitle("Choose a colour");
                builder.setItems(R.array.colours, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        //Once a color is selected, a second array with corresponding color hex's is indexed
                        String hexCode = getResources().getStringArray(R.array.colours_hex_code)[item];
                        colourInput.getBackground().setColorFilter(Color.parseColor(hexCode), PorterDuff.Mode.SRC_ATOP);
                        tempColour = hexCode;
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        edit = sharedPref.getBoolean(getString(R.string.sharedpref_edit_item), false);
        if (edit) {
            id = sharedPref.getString(getString(R.string.sharedpref_edit_id), "0");
            populateFields();
        }

        valid = false;

        addData();
    }

    /**
     * Adds data input into the various types of data fields into the revision database
     */
    public void addData() {
        editButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        validate();
                        if (valid) {
                            //When existing data is to be edited
                            boolean isUpdated = myDB.updateRevisionData(id,
                                    moduleNameInput.getText().toString(),
                                    titleNameInput.getText().toString(),
                                    dateInput.getText().toString(),
                                    startTimeInput.getText().toString(),
                                    endTimeInput.getText().toString(),
                                    notesInput.getText().toString(),
                                    tempColour);

                            if (isUpdated) {
                                Toast.makeText(EditRevisionActivity.this, "Revision block has successfully been updated", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(EditRevisionActivity.this, "Revision update failed!", Toast.LENGTH_SHORT).show();
                            }

                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                            editor.apply();

                            setResult(RESULT_OK, null);
                            finish();
                        }
                    }
                }
        );
    }

    /**
     * Validates all the entered data is suitable before adding to the database
     */
    private void validate() {
        String failingText = "";

        //Validate module name - field required
        if (moduleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The revision module name must not be empty\n\n");
        }

        //Validate title name - field required
        if (titleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The revision title name must not be empty\n\n");
        }

        //Validate date - field required
        if (dateInput.getText().toString().equals("00-00-0000")) {
            failingText = failingText.concat("- You must select a valid revision date\n\n");
        }

        //Validate start and end time - end time cannot be before or the same as start time
        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        try {
            if (timeDF.parse(startTimeInput.getText().toString()).after(timeDF.parse(endTimeInput.getText().toString()))
                    || timeDF.parse(startTimeInput.getText().toString()).equals(timeDF.parse(endTimeInput.getText().toString()))) {
                failingText = failingText.concat("- End time cannot be before or the same as the start time!\n");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (failingText.isEmpty()) {
            valid = true;
        } else {
            //Show dialog
            new AlertDialog.Builder(this)
                    .setTitle("Failed Validity Check!!")
                    .setMessage(failingText)
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {}
                    })
                    .show();
        }
    }

    /**
     * When existing revision data is to be edited, the fields should be populated with the current data
     */
    private void populateFields() {
        Cursor res = myDB.getAllRevisionData();
        //Locate the revision block that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                moduleNameInput.setText(res.getString(1));
                titleNameInput.setText(res.getString(2));
                dateInput.setText(res.getString(3));
                startTimeInput.setText(res.getString(4));
                endTimeInput.setText(res.getString(5));
                notesInput.setText(res.getString(6));
                if (res.getString(7) != null) {
                    colourInput.getBackground().setColorFilter(Color.parseColor(res.getString(7)), PorterDuff.Mode.SRC_ATOP);
                }
                tempColour = res.getString(7);
            }
        }
    }

    /**
     * Sets what happens when a date is selected from the date picker dialog
     */
    DatePickerDialog.OnDateSetListener onDateSetListener  = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
            Calendar newDate = Calendar.getInstance();
            newDate.set(year, monthOfYear, dayOfMonth);
            dateInput.setText(dateFormatter.format(newDate.getTime()));
        }
    };

    /**
     * Sets what happens when a start time is selected from the time picker dialog
     */
    TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            DecimalFormat df = new DecimalFormat("00");
            startTimeInput.setText(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
        }
    };

    /**
     * Sets what happens when an end time is selected from the time picker dialog
     */
    TimePickerDialog.OnTimeSetListener onEndTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            DecimalFormat df = new DecimalFormat("00");
            endTimeInput.setText(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
        }
    };
}
