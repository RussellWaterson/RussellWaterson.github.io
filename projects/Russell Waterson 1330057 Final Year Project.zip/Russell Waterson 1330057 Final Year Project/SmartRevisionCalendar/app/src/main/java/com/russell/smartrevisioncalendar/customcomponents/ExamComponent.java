package com.russell.smartrevisioncalendar.customcomponents;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.mainscreens.IndividualItemScreen;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * <h1>Reusable Exams Component</h1>
 * Reusable custom component for displaying exams in the database on the exams fragment
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   23-01-2017
 */
public class ExamComponent extends RelativeLayout {

    TextView moduleTitle, dateTimeDuration, daysToGo;
    View priority1, priority2, priority3, priority4, priority5;
    View colouredLine;
    Rect hitRect;
    String id;

    SharedPreferences sharedPref;

    public ExamComponent(Context context) {
        super(context);
        init(context);
    }

    public ExamComponent(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ExamComponent(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    /**
     * Initialise the custom exam component
     * @param context The calling activity context
     */
    private void init(Context context) {
        View.inflate(context, R.layout.custom_component_exam,this);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        moduleTitle = (TextView) findViewById(R.id.e_component_module_title);
        dateTimeDuration = (TextView) findViewById(R.id.e_component_date_time);
        daysToGo = (TextView) findViewById(R.id.e_component_days_to_go);
        priority1 = findViewById(R.id.e_component_priority_square_1);
        priority2 = findViewById(R.id.e_component_priority_square_2);
        priority3 = findViewById(R.id.e_component_priority_square_3);
        priority4 = findViewById(R.id.e_component_priority_square_4);
        priority5 = findViewById(R.id.e_component_priority_square_5);
        colouredLine = findViewById(R.id.e_component_coloured_line);
        hitRect = new Rect();
        sharedPref = PreferenceManager.getDefaultSharedPreferences(getContext());
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.getHitRect(hitRect);
                if (hitRect.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
                    motionEvent.setLocation(0.0f, 0.0f);
                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_id), id);
                    editor.commit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_table), "examTable");
                    editor.commit();
                    System.out.println(sharedPref.getString(getContext().getString(R.string.sharedpref_edit_id), "no") + "   "
                            + sharedPref.getString(getContext().getString(R.string.sharedpref_edit_table), "no"));
                    getContext().startActivity(new Intent(getContext(), IndividualItemScreen.class));
                }
                return true;
            }
        });
    }

    /**
     * Sets the exam module and title text
     * @param text New exam module and title
     */
    public void setModuleTitleText(String text) {
        moduleTitle.setText(text);
    }

    /**
     * Sets the exam date and time text
     * @param text New exam date and time
     */
    public void setDateTimeDuration(String text) {
        dateTimeDuration.setText(text);
    }

    /**
     * Sets the exam number of days to go
     * @param text Date of the exam
     */
    public void setDaysToGo(String text) {
        if (text == null || text.equals("date")) {
            daysToGo.setText("Unknown days to go");
        } else {
            Date currentDate = new Date();
            Date enteredDate = null;
            DateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
            try {
                enteredDate = format.parse(text);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long diffInMillies = enteredDate.getTime() - currentDate.getTime();
            long dtg;
            if (diffInMillies > 0) {
                dtg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;
            } else{
                dtg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
            }

            daysToGo.setText(dtg + " days to go");
        }
    }

    /**
     * Sets the number of priority markers to fill
     * @param text The priority out of 5
     * @param colour The colour in which to set the priority markers
     */
    public void setPriority(String text, String colour) {
        if (Integer.valueOf(text) >= 1) {
            priority1.getBackground().setColorFilter(Color.parseColor(colour), PorterDuff.Mode.SRC_ATOP);
        }
        if (Integer.valueOf(text) >= 2) {
            priority2.getBackground().setColorFilter(Color.parseColor(colour), PorterDuff.Mode.SRC_ATOP);
        }
        if (Integer.valueOf(text) >= 3) {
            priority3.getBackground().setColorFilter(Color.parseColor(colour), PorterDuff.Mode.SRC_ATOP);
        }
        if (Integer.valueOf(text) >= 4) {
            priority4.getBackground().setColorFilter(Color.parseColor(colour), PorterDuff.Mode.SRC_ATOP);
        }
        if (Integer.valueOf(text) >= 5) {
            priority5.getBackground().setColorFilter(Color.parseColor(colour), PorterDuff.Mode.SRC_ATOP);
        }

        GradientDrawable drawable1 = (GradientDrawable)priority1.getBackground();
        drawable1.setStroke(3, Color.parseColor(colour));
        GradientDrawable drawable2 = (GradientDrawable)priority2.getBackground();
        drawable2.setStroke(3, Color.parseColor(colour));
        GradientDrawable drawable3 = (GradientDrawable)priority3.getBackground();
        drawable3.setStroke(3, Color.parseColor(colour));
        GradientDrawable drawable4 = (GradientDrawable)priority4.getBackground();
        drawable4.setStroke(3, Color.parseColor(colour));
        GradientDrawable drawable5 = (GradientDrawable)priority5.getBackground();
        drawable5.setStroke(3, Color.parseColor(colour));
    }

    /**
     * Sets the colour of the line displayed by the exam
     * @param text New line colour
     */
    public void setColouredLine(String text) {
        colouredLine.getBackground().setColorFilter(Color.parseColor(text), PorterDuff.Mode.SRC_ATOP);
    }

    /**
     * Sets the ID of the exam
     * @param text New exam ID
     */
    public void setID(String text) { id = text; }
}
