package com.russell.smartrevisioncalendar.mainscreens;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.newitemscreens.AddActivityActivity;
import com.russell.smartrevisioncalendar.newitemscreens.AddClassActivity;
import com.russell.smartrevisioncalendar.newitemscreens.AddExamActivity;
import com.russell.smartrevisioncalendar.newitemscreens.EditRevisionActivity;

/**
 * <h1>Individual Item Screen</h1>
 * A class to show all the details of individual items in each of the five databases
 * From this screen, the user can also delete or edit the item
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   15-02-2017
 */
public class IndividualItemScreen extends AppCompatActivity {

    Toolbar toolbar;
    CollapsingToolbarLayout collapsingToolbarLayout;
    AppBarLayout appBarLayout;

    SharedPreferences sharedPref;
    DatabaseHelper myDb;

    TextView dateTime, repeat, room, teacher, contentSize, priority, notes;
    View dateTimeIcon, repeatIcon, roomIcon, teacherIcon, contentSizeIcon, priorityIcon;

    String id;
    String table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_item_screen);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        appBarLayout = (AppBarLayout) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        id = sharedPref.getString(getString(R.string.sharedpref_edit_id), "0");
        table = sharedPref.getString(getString(R.string.sharedpref_edit_table), "");

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), true);
                editor.commit();
                switch (table) {
                    case "classTable":
                        startActivityForResult(new Intent(getApplicationContext(), AddClassActivity.class), 1);
                        break;
                    case "activityTable":
                        startActivityForResult(new Intent(getApplicationContext(), AddActivityActivity.class), 1);
                        break;
                    case "examTable":
                        startActivityForResult(new Intent(getApplicationContext(), AddExamActivity.class), 1);
                        break;
                    case "revisionTable":
                        startActivityForResult(new Intent(getApplicationContext(), EditRevisionActivity.class), 1);
                        break;
                    case "eventTable":
                        Toast.makeText(IndividualItemScreen.this, "You can not edit a Google Calendar Imported Event",
                                Toast.LENGTH_LONG).show();
                        break;
                    default:
                        break;
                }
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dateTime = (TextView) findViewById(R.id.item_date_time);
        repeat = (TextView) findViewById(R.id.item_repeat);
        room = (TextView) findViewById(R.id.item_room);
        teacher = (TextView) findViewById(R.id.item_teacher);
        contentSize = (TextView) findViewById(R.id.item_content);
        priority = (TextView) findViewById(R.id.item_priority);
        notes = (TextView) findViewById(R.id.item_notes);

        dateTimeIcon = findViewById(R.id.item_date_time_icon);
        repeatIcon = findViewById(R.id.item_repeat_icon);
        roomIcon = findViewById(R.id.item_room_icon);
        teacherIcon = findViewById(R.id.item_teacher_icon);
        contentSizeIcon = findViewById(R.id.item_content_icon);
        priorityIcon = findViewById(R.id.item_priority_icon);

        myDb = DatabaseHelper.getInstance(getApplicationContext());

        System.out.println(id + "    " + table);

        switch (table) {
            case "classTable":
                populateClass();
                break;
            case "activityTable":
                populateActivity();
                break;
            case "examTable":
                populateExam();
                break;
            case "revisionTable":
                populateRevision();
                break;
            case "eventTable":
                populateEvent();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            Intent refresh = new Intent(this, IndividualItemScreen.class);
            startActivity(refresh);
            this.finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_individual_item_screen, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here.
        int itemId = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (itemId == R.id.action_delete) {
            new AlertDialog.Builder(this)
                    .setTitle("Delete entry")
                    .setMessage("Are you sure you want to delete this entry?")
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //Continue with delete
                            switch (table) {
                                case "classTable":
                                    myDb.deleteClassData(id);
                                    Toast.makeText(getApplicationContext(), "Class Deleted!", Toast.LENGTH_LONG).show();
                                    finish();
                                    break;
                                case "activityTable":
                                    myDb.deleteActivityData(id);
                                    Toast.makeText(getApplicationContext(), "Activity Deleted!", Toast.LENGTH_LONG).show();
                                    finish();
                                    break;
                                case "examTable":
                                    myDb.deleteExamData(id);
                                    Toast.makeText(getApplicationContext(), "Exam Deleted!", Toast.LENGTH_LONG).show();
                                    finish();
                                    break;
                                case "revisionTable":
                                    myDb.deleteRevisionData(id);
                                    Toast.makeText(getApplicationContext(), "Revision Deleted!", Toast.LENGTH_LONG).show();
                                    finish();
                                    break;
                                case "eventTable":
                                    myDb.deleteEventData(id);
                                    Toast.makeText(getApplicationContext(), "Event Deleted!", Toast.LENGTH_LONG).show();
                                    finish();
                                    break;
                                default:
                                    break;
                            }
                        }
                    })
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //Do not delete
                        }
                    })
                    .setIcon(R.drawable.ic_alert)
                    .show();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    /**
     * Changing the item screen to show a class with the additional fields of repeat, teacher and room
     */
    private void populateClass() {
        Cursor res = myDb.getAllClassData();

        //Remove text and icon views that aren't a part of classes
        contentSize.setVisibility(View.GONE);
        contentSizeIcon.setVisibility(View.GONE);
        priority.setVisibility(View.GONE);
        priorityIcon.setVisibility(View.GONE);
        notes.setVisibility(View.GONE);

        //Locate the class that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                //Add the title to the action bar
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle(res.getString(1) + " - "+ res.getString(2));
                }

                //Change the colour of the title bar and navigation bar to item's colour
                toolbar.setBackgroundColor(Color.parseColor(res.getString(9)));
                collapsingToolbarLayout.setBackgroundColor(Color.parseColor(res.getString(9)));
                collapsingToolbarLayout.setContentScrimColor(Color.parseColor(res.getString(9)));
                collapsingToolbarLayout.setStatusBarScrimColor(Color.parseColor(res.getString(9)));
                appBarLayout.setBackgroundColor(Color.parseColor(res.getString(9)));
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                }

                //Set the various text fields associated with the class
                if (Integer.valueOf(res.getString(6)) == 1) {
                    repeat.setText("Repeats:       Yes");
                } else {
                    repeat.setText("Repeats:       No");
                }
                dateTime.setText(res.getString(3) + "       " + res.getString(4) + " - " + res.getString(5));
                room.setText(res.getString(8));
                teacher.setText(res.getString(7));
            }
        }
    }

    /**
     * Changing the item screen to show an activity with the additional fields of repeat
     */
    private void populateActivity() {
        Cursor res = myDb.getAllActivityData();

        //Remove text and icon views that aren't a part of activities
        room.setVisibility(View.GONE);
        roomIcon.setVisibility(View.GONE);
        teacher.setVisibility(View.GONE);
        teacherIcon.setVisibility(View.GONE);
        contentSize.setVisibility(View.GONE);
        contentSizeIcon.setVisibility(View.GONE);
        priority.setVisibility(View.GONE);
        priorityIcon.setVisibility(View.GONE);
        notes.setVisibility(View.GONE);

        //Locate the activity that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                //Add the title to the action bar
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle(res.getString(1));
                }

                //Change the colour of the title bar and navigation bar to item's colour
                toolbar.setBackgroundColor(Color.parseColor(res.getString(6)));
                collapsingToolbarLayout.setBackgroundColor(Color.parseColor(res.getString(6)));
                collapsingToolbarLayout.setContentScrimColor(Color.parseColor(res.getString(6)));
                collapsingToolbarLayout.setStatusBarScrimColor(Color.parseColor(res.getString(6)));
                appBarLayout.setBackgroundColor(Color.parseColor(res.getString(6)));
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                }

                //Set the various text fields associated with the class
                if (Integer.valueOf(res.getString(5)) == 1) {
                    repeat.setText("Repeats:       Yes");
                } else {
                    repeat.setText("Repeats:       No");
                }
                dateTime.setText(res.getString(2) + "       " + res.getString(3) + " - " + res.getString(4));
            }
        }
    }

    /**
     * Changing the item screen to show an exam with the additional fields of content size, priority,
     * and info
     */
    private void populateExam() {
        Cursor res = myDb.getAllExamData();

        //Remove text and icon views that aren't a part of exam
        repeat.setVisibility(View.GONE);
        repeatIcon.setVisibility(View.GONE);
        room.setVisibility(View.GONE);
        roomIcon.setVisibility(View.GONE);
        teacher.setVisibility(View.GONE);
        teacherIcon.setVisibility(View.GONE);

        //Locate the exam that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                //Add the title to the action bar
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle(res.getString(1) + " - "+ res.getString(2));
                }

                //Change the colour of the title bar and navigation bar to item's colour
                toolbar.setBackgroundColor(Color.parseColor(res.getString(7)));
                collapsingToolbarLayout.setBackgroundColor(Color.parseColor(res.getString(7)));
                collapsingToolbarLayout.setContentScrimColor(Color.parseColor(res.getString(7)));
                collapsingToolbarLayout.setStatusBarScrimColor(Color.parseColor(res.getString(7)));
                appBarLayout.setBackgroundColor(Color.parseColor(res.getString(7)));
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                }

                //Set the various text fields associated with the class
                dateTime.setText(res.getString(3) + " - " + res.getString(4) + "       " + res.getString(5) + " Minutes");
                contentSize.setText("Content Size:       " + res.getString(8) + "/10");
                priority.setText("Priority:       " + res.getString(9) + "/5");
                notes.setText("Notes:       " + res.getString(6));
            }
        }
    }

    /**
     * Changing the item screen to show revision with the additional fields of notes
     */
    private void populateRevision() {
        Cursor res = myDb.getAllRevisionData();

        //Remove text and icon views that aren't a part of revision
        repeat.setVisibility(View.GONE);
        repeatIcon.setVisibility(View.GONE);
        room.setVisibility(View.GONE);
        roomIcon.setVisibility(View.GONE);
        teacher.setVisibility(View.GONE);
        teacherIcon.setVisibility(View.GONE);
        contentSize.setVisibility(View.GONE);
        contentSizeIcon.setVisibility(View.GONE);
        priority.setVisibility(View.GONE);
        priorityIcon.setVisibility(View.GONE);

        //Locate the revision that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                if (res.getString(1) == null) {
                    //When the system generates a free revision slot
                    if (getSupportActionBar() != null) {
                        getSupportActionBar().setTitle("Custom Revision Slot!");
                    }

                    //Change the colour of the title bar and navigation bar to black
                    int black = Color.parseColor("#000000");
                    toolbar.setBackgroundColor(black);
                    collapsingToolbarLayout.setBackgroundColor(black);
                    collapsingToolbarLayout.setContentScrimColor(black);
                    collapsingToolbarLayout.setStatusBarScrimColor(black);
                    appBarLayout.setBackgroundColor(black);
                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                    }

                    //Set the date and time field, but the notes field to empty
                    dateTime.setText(res.getString(3) + "       " + res.getString(4) + " - " + res.getString(5));
                    notes.setText("Notes:");
                    new android.app.AlertDialog.Builder(this)
                            .setTitle("This is a free revision slot!")
                            .setMessage("This is a free revision slot! This means that the super " +
                                    "algorithm is giving you the choice of what you want to revise for! " +
                                    "So please either delete or edit this revision block with your chosen module.")
                            .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {}
                            })
                            .show();
                } else {
                    //Add the title to the action bar
                    if (getSupportActionBar() != null) {
                        getSupportActionBar().setTitle(res.getString(1) + " - " + res.getString(2));
                    }

                    //Change the colour of the title bar and navigation bar to item's colour
                    int colour = Color.parseColor(res.getString(7));
                    toolbar.setBackgroundColor(colour);
                    collapsingToolbarLayout.setBackgroundColor(colour);
                    collapsingToolbarLayout.setContentScrimColor(colour);
                    collapsingToolbarLayout.setStatusBarScrimColor(colour);
                    appBarLayout.setBackgroundColor(colour);
                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                    }

                    //Set the various text fields associated with the revision
                    dateTime.setText(res.getString(3) + "       " + res.getString(4) + " - " + res.getString(5));
                    if (res.getString(6) == null) {
                        notes.setText("Notes:");
                    } else {
                        notes.setText("Notes:       " + res.getString(6));
                    }
                }
            }
        }
    }

    /**
     * Changing the item screen to show a Google Calendar imported event
     */
    private void populateEvent() {
        Cursor res = myDb.getAllEventData();

        //Remove text and icon views that aren't a part of exam
        room.setVisibility(View.GONE);
        roomIcon.setVisibility(View.GONE);
        teacher.setVisibility(View.GONE);
        teacherIcon.setVisibility(View.GONE);
        repeat.setVisibility(View.GONE);
        repeatIcon.setVisibility(View.GONE);
        contentSize.setVisibility(View.GONE);
        contentSizeIcon.setVisibility(View.GONE);
        priority.setVisibility(View.GONE);
        priorityIcon.setVisibility(View.GONE);
        notes.setVisibility(View.GONE);

        //Locate the event that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                //Add the title to the action bar
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle(res.getString(1));
                }

                //Change the colour of the title bar and navigation bar to item's colour
                int colour = Color.parseColor(res.getString(5));
                toolbar.setBackgroundColor(colour);
                collapsingToolbarLayout.setBackgroundColor(colour);
                collapsingToolbarLayout.setContentScrimColor(colour);
                collapsingToolbarLayout.setStatusBarScrimColor(colour);
                appBarLayout.setBackgroundColor(colour);
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setNavigationBarColor(Color.parseColor("#000000"));
                }

                //Set the various text fields associated with the event
                dateTime.setText(res.getString(2) + "       " + res.getString(3) + " - " + res.getString(4));
            }
        }
    }
}
