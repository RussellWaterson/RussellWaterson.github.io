package com.russell.smartrevisioncalendar.debriefs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.settingscreens.SettingsActivity;

/**
 * <h1>Notification Service Start Receiver</h1>
 * Broadcast receiver for: BOOT_COMPLETED, TIMEZONE_CHANGED, and TIME_SET events.
 * <p>
 * Sets Alarm Manager for notification.
 * Sets muting.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   27-02-2017
 */
public final class NotificationServiceStarterReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        if (sharedPref.getBoolean(context.getString(R.string.sharedpref_end_day_debrief), false)) {
            NotificationEventReceiver.setupAlarm(context);
        }
        if (sharedPref.getBoolean("preference_mute_phone", false)) {
            SettingsActivity.startMute(context);
            SettingsActivity.endMute(context);
        }
    }
}
