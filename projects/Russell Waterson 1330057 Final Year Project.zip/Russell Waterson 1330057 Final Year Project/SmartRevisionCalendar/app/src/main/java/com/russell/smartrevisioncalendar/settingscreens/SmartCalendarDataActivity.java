package com.russell.smartrevisioncalendar.settingscreens;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.TimePicker;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.debriefs.NotificationEventReceiver;
import com.russell.smartrevisioncalendar.smartdata.CreateRevisionBlocks;
import com.russell.smartrevisioncalendar.smartdata.NewRevisionDiff;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * <h1>Smart Calendar Data Activity</h1>
 * The settings screen for the app where the smart calendar date can be edited and revision can
 * be generated.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   18-01-2017
 */
public class SmartCalendarDataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_calendar_data);

        Fragment fragment = new SmartSettings();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        if(savedInstanceState == null) {
            //created for the first time
            fragmentTransaction.add(R.id.activity_smart_calendar_data, fragment, "smart_settings_fragment");
            fragmentTransaction.commit();
        } else {
            fragment = getFragmentManager().findFragmentByTag("smart_settings_fragment");
        }
    }

    /**
     * Inner class to create settings preferences from xml
     * {@inheritDoc}
     */
    public static class SmartSettings extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.smart_calendar_data);

            final PreferenceManager preferenceManager = getPreferenceManager();

            SwitchPreference smartCalendarActivePref = (SwitchPreference) findPreference(getString(R.string.sharedpref_smart_calendar_active));
            Preference calculateRevisionPref = findPreference("calculate_revision_preference");
            Preference smartDataUpdatePref = findPreference("smart_data_update_preference");
            final Preference startTimePref = findPreference(getString(R.string.sharedpref_preferred_start_time));
            final Preference endTimePref = findPreference(getString(R.string.sharedpref_preferred_end_time));
            final CheckBoxPreference endBlockPref = (CheckBoxPreference) findPreference(getString(R.string.sharedpref_end_block_debrief));
            final CheckBoxPreference endDayPref = (CheckBoxPreference) findPreference(getString(R.string.sharedpref_end_day_debrief));
            final EditTextPreference revisionBlockPref = (EditTextPreference) findPreference(getString(R.string.sharedpref_revision_block_size));
            final EditTextPreference breakBlockPref = (EditTextPreference) findPreference(getString(R.string.sharedpref_break_block_size));
            final Preference varietyPreference = findPreference(getString(R.string.sharedpref_variety));

            startTimePref.setSummary("Set your preferred earliest time to start working\nTime: "
                    + preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_preferred_start_time), "00:00"));
            endTimePref.setSummary("Set your preferred latest time to finish working\nTime: "
                    + preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_preferred_end_time), "00:00"));
            revisionBlockPref.setSummary("Size: "
                    + preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_revision_block_size), "0"));
            breakBlockPref.setSummary("Size: "
                    + preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_break_block_size), "0"));
            varietyPreference.setSummary("Set your preferred variety in terms of how much the generated revision differs per block\nCurrent Variety: "
                    + preferenceManager.getSharedPreferences().getInt(getString(R.string.sharedpref_variety), 0));

            smartCalendarActivePref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object isActiveOnObject) {
                    boolean isActiveOn = (Boolean) isActiveOnObject;
                    if (!isActiveOn) {
                        //Delete all revision when deactivated
                        Toast.makeText(getActivity(), "Removing all generated revision...", Toast.LENGTH_LONG).show();
                        List<String> revisionIDs = new ArrayList<String>();
                        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity());
                        Cursor resRevision = myDb.getAllRevisionData();
                        while (resRevision.moveToNext()) {
                            revisionIDs.add(resRevision.getString(0));
                        }
                        for (int i = 0; i < revisionIDs.size(); i++) {
                            Integer deletedRows = myDb.deleteRevisionData(revisionIDs.get(i));
                            if (deletedRows > 0 ) {
                                System.out.println(revisionIDs.get(i) + " deleted");
                            } else {
                                System.out.println(revisionIDs.get(i) + " NOT deleted!");
                            }
                        }
                    }
                    return true;
                }
            });

            startTimePref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    String currentStartTime = preferenceManager.getSharedPreferences()
                            .getString(getString(R.string.sharedpref_preferred_start_time), "00:00");
                    //Sets what happens when a start time is selected from the time picker dialog
                    TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            try {
                                DecimalFormat df = new DecimalFormat("00");
                                SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                                Date currentEndTime = timeDF.parse(preferenceManager.getSharedPreferences()
                                        .getString(getString(R.string.sharedpref_preferred_end_time), "00:00"));
                                Date newStartTime = timeDF.parse(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
                                if (newStartTime.after(currentEndTime)) {
                                    new AlertDialog.Builder(getActivity())
                                            .setTitle("Start Time Error")
                                            .setMessage("WARNING: You have set your start time to be after your end time!! Please try again!\n")
                                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {}
                                            })
                                            .show();
                                } else {
                                    SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getActivity());
                                    SharedPreferences.Editor editor = settings.edit();
                                    editor.putString(getString(R.string.sharedpref_preferred_start_time),
                                            (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                    editor.commit();
                                    startTimePref.setSummary("Set your preferred earliest time to start working\nTime: "
                                            + (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    new TimePickerDialog(getActivity(), onStartTimeSetListener,
                            Integer.parseInt(currentStartTime.substring(0,2)),
                            Integer.parseInt(currentStartTime.substring(3,5)),
                            true).show();
                    return true;
                }
            });

            endTimePref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    String currentEndTime = preferenceManager.getSharedPreferences()
                            .getString(getString(R.string.sharedpref_preferred_end_time), "00:00");
                    //Sets what happens when a end time is selected from the time picker dialog
                    TimePickerDialog.OnTimeSetListener onEndTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            try {
                                DecimalFormat df = new DecimalFormat("00");
                                SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                                Date currentStartTime = timeDF.parse(preferenceManager.getSharedPreferences()
                                        .getString(getString(R.string.sharedpref_preferred_start_time), "00:00"));
                                Date newEndTime = timeDF.parse(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
                                if (newEndTime.before(currentStartTime)) {
                                    new AlertDialog.Builder(getActivity())
                                            .setTitle("End Time Error")
                                            .setMessage("WARNING: You have set your end time to before your start time!! Please try again!\n")
                                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {}
                                            })
                                            .show();
                                } else {
                                    SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getActivity());
                                    SharedPreferences.Editor editor = settings.edit();
                                    editor.putString(getString(R.string.sharedpref_preferred_end_time),
                                            (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                    editor.commit();
                                    endTimePref.setSummary("Set your preferred latest time to finish working\nTime: "
                                            + (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    new TimePickerDialog(getActivity(), onEndTimeSetListener,
                            Integer.parseInt(currentEndTime.substring(0,2)),
                            Integer.parseInt(currentEndTime.substring(3,5)),
                            true).show();
                    return true;
                }
            });

            endBlockPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if ((Boolean) newValue) {
                        //Clicked true
                        Toast.makeText(getActivity(), "Coming soon...", Toast.LENGTH_SHORT).show();
                    } else {
                        //Clicked false
                    }
                    return true;
                }
            });

            endDayPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if ((Boolean) newValue) {
                        NotificationEventReceiver.setupAlarm(getActivity());
                    } else {
                        NotificationEventReceiver.cancelAlarm(getActivity());
                    }
                    return true;
                }
            });

            calculateRevisionPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity());
                    Cursor resExam = myDb.getAllExamData();
                    if (!preferenceManager.getSharedPreferences().getBoolean(getString(R.string.sharedpref_smart_calendar_active), true)) {
                        Toast.makeText(getActivity(), "Smart Calendar Features are not active", Toast.LENGTH_LONG).show();
                    } else if (resExam.getCount() == 0) {
                        Toast.makeText(getActivity(), "You have not entered any exams so revision cannot be made", Toast.LENGTH_LONG).show();
                    } else if (Integer.valueOf(preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_revision_block_size), "0")) == 0) {
                        Toast.makeText(getActivity(), "Revision Block Size is 0, cannot generate revision", Toast.LENGTH_LONG).show();
                    } else {
                        Intent intent = new Intent(getActivity(), CreateRevisionBlocks.class);
                        getActivity().startService(intent);

                        if (preferenceManager.getSharedPreferences().getBoolean(getString(R.string.sharedpref_smart_regeneration), false)) {
                            //When the smart revision has already been generated in the past
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Revision Generated")
                                    .setMessage("Your new revision schedule has been generated! You have three options:\n\n" +
                                            "  - View the new revision along side the old revision to see the difference\n\n" +
                                            "  - Keep the old revision and discard the new without seeing the difference\n\n" +
                                            "  - Keep the newly generated revision and discard the old without seeing the difference\n")
                                    .setCancelable(false)
                                    .setNegativeButton("Keep Old", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            NewRevisionDiff.clearNewBlocks(getActivity().getApplicationContext());
                                        }
                                    })
                                    .setNeutralButton("View Diff", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            startActivity(new Intent(getActivity().getApplicationContext(), NewRevisionDiff.class));
                                        }
                                    })
                                    .setPositiveButton("Keep New", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            NewRevisionDiff.clearOldBlocks(getActivity().getApplicationContext());
                                        }
                                    })
                                    .show();
                        } else {
                            //When the smart revision is generated for the first time
                            SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getActivity());
                            SharedPreferences.Editor editor = settings.edit();
                            editor.putBoolean(getString(R.string.sharedpref_smart_regeneration), true);
                            editor.apply();
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Revision Generated")
                                    .setMessage("Congratulations, you have generated smart revision slots for the first time!\n\n" +
                                            "In the future, when regenerating smart revision, you will have the opportunity to " +
                                            "compare your existing slots with the newly generated slots, and pick between the two " +
                                            "which one you would like to keep!\n")
                                    .setPositiveButton("Thanks", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {}
                                    })
                                    .show();
                        }

                        final ProgressDialog progress = new ProgressDialog(getActivity());
                        progress.setMessage("Generating your bespoke revision");
                        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                        progress.setCancelable(false);
                        progress.show();

                        final int totalProgressTime = 100;
                        final Thread t = new Thread() {
                            @Override
                            public void run() {
                                int jumpTime = 0;
                                while(jumpTime < totalProgressTime) {
                                    try {
                                        sleep(100);
                                        jumpTime += 5;
                                        progress.setProgress(jumpTime);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                                progress.dismiss();
                            }
                        };
                        t.start();
                    }
                    return true;
                }
            });

            smartDataUpdatePref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity());
                    Cursor res = myDb.getAllDebriefData();
                    if (res.getCount() == 0) {
                        Toast.makeText(getActivity(), "You have no had any daily debriefs yet!", Toast.LENGTH_LONG).show();
                    } else {
                        final SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                        String message = "We have some updates to your learning style "
                                + preferenceManager.getSharedPreferences().getString(getString(R.string.sharedpref_user_name), "")
                                + " that you may find beneficial!\n\nThis generated data is based on all the "
                                + "end of the day debriefs that you have been filling out.\n\n\n";

                        double productivity;
                        int revisionLength = 0;
                        int breakLength = 0;
                        long startTime = 0L;
                        long endTime = 0L;
                        int variety = 0;

                        while (res.moveToNext()) {
                            //The productivity of each day effects the impact of the rest of the debrief
                            //5 out of 5 productivity means changes have full impact, 0 out of 5 means none
                            productivity = 1 - (Double.valueOf(res.getString(1)) / 5);

                            //Creating the sum of the revision length after adjustments
                            //Up to 30 minute changes in either direction can be made
                            switch (res.getString(3)) {
                                case "0":
                                    revisionLength += Integer.valueOf(res.getString(2)) + (30 * productivity);
                                    break;
                                case "1":
                                    revisionLength += Integer.valueOf(res.getString(2)) + (15 * productivity);
                                    break;
                                case "2":
                                    revisionLength += Integer.valueOf(res.getString(2));
                                    break;
                                case "3":
                                    revisionLength += Integer.valueOf(res.getString(2)) - (15 * productivity);
                                    break;
                                case "4":
                                    revisionLength += Integer.valueOf(res.getString(2)) - (30 * productivity);
                                    break;
                                default:
                                    revisionLength += Integer.valueOf(res.getString(2));
                                    break;
                            }

                            //Creating the sum of the break length after adjustments
                            //Up to 20 minute changes in either direction can be made
                            switch (res.getString(5)) {
                                case "0":
                                    breakLength += Integer.valueOf(res.getString(4)) + (20 * productivity);
                                    break;
                                case "1":
                                    breakLength += Integer.valueOf(res.getString(4)) + (10 * productivity);
                                    break;
                                case "2":
                                    breakLength += Integer.valueOf(res.getString(4));
                                    break;
                                case "3":
                                    breakLength += Integer.valueOf(res.getString(4)) - (10 * productivity);
                                    break;
                                case "4":
                                    breakLength += Integer.valueOf(res.getString(4)) - (20 * productivity);
                                    break;
                                default:
                                    breakLength += Integer.valueOf(res.getString(4));
                                    break;
                            }

                            //Creating the sum of the start time after adjustments
                            //Up to 30 minute changes in either direction can be made
                            double startAdjust;
                            try {
                                switch (res.getString(7)) {
                                    case "0":
                                        startAdjust = 30 * 60000 * productivity;
                                        startTime += timeDF.parse(res.getString(6)).getTime() + startAdjust;
                                        break;
                                    case "1":
                                        startAdjust = 15 * 60000 * productivity;
                                        startTime += timeDF.parse(res.getString(6)).getTime() + startAdjust;
                                        break;
                                    case "2":
                                        startTime += timeDF.parse(res.getString(6)).getTime();
                                        break;
                                    case "3":
                                        startAdjust = 15 * 60000 * productivity;
                                        startTime += timeDF.parse(res.getString(6)).getTime() - startAdjust;
                                        break;
                                    case "4":
                                        startAdjust = 30 * 60000 * productivity;
                                        startTime += timeDF.parse(res.getString(6)).getTime() - startAdjust;
                                        break;
                                    default:
                                        startTime += timeDF.parse(res.getString(6)).getTime();
                                        break;
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            //Creating the sum of the end time after adjustments
                            //Up to 30 minute changes in either direction can be made
                            double endAdjust;
                            try {
                                switch (res.getString(9)) {
                                    case "0":
                                        endAdjust = 30 * 60000 * productivity;
                                        endTime += timeDF.parse(res.getString(8)).getTime() + endAdjust;
                                        break;
                                    case "1":
                                        endAdjust = 15 * 60000 * productivity;
                                        endTime += timeDF.parse(res.getString(8)).getTime() + endAdjust;
                                        break;
                                    case "2":
                                        endTime += timeDF.parse(res.getString(8)).getTime();
                                        break;
                                    case "3":
                                        endAdjust = 15 * 60000 * productivity;
                                        endTime += timeDF.parse(res.getString(8)).getTime() - endAdjust;
                                        break;
                                    case "4":
                                        endAdjust = 30 * 60000 * productivity;
                                        endTime += timeDF.parse(res.getString(8)).getTime() - endAdjust;
                                        break;
                                    default:
                                        endTime += timeDF.parse(res.getString(8)).getTime();
                                        break;
                                }
                                System.out.println(timeDF.format(new Date(endTime)));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }


                            //Creating the sum of the variety after adjustments
                            //Up to 4 incremental changes in either direction can be made
                            switch (res.getString(11)) {
                                case "0":
                                    variety += Integer.valueOf(res.getString(10)) + (4 * productivity);
                                    break;
                                case "1":
                                    variety += Integer.valueOf(res.getString(10)) + (2 * productivity);
                                    break;
                                case "2":
                                    variety += Integer.valueOf(res.getString(10));
                                    break;
                                case "3":
                                    variety += Integer.valueOf(res.getString(10)) - (2 * productivity);
                                    break;
                                case "4":
                                    variety += Integer.valueOf(res.getString(10)) - (4 * productivity);
                                    break;
                                default:
                                    variety += Integer.valueOf(res.getString(10));
                                    break;
                            }
                        }
                        final int newRevisionLength = revisionLength / res.getCount();
                        message = message.concat("     New Revision Length: " + newRevisionLength + "\n\n");
                        final int newBreakLength = breakLength / res.getCount();
                        message = message.concat("     New Break Length: " + newBreakLength + "\n\n");
                        final int newVariety = variety / res.getCount();
                        message = message.concat("     New Variety: " + newVariety + "\n\n");
                        final Date newStartTime = new Date((startTime / res.getCount()));
                        message = message.concat("     New Start Time: " + timeDF.format(newStartTime) + "\n\n");
                        final Date newEndTime = new Date((endTime / res.getCount()));
                        message = message.concat("     New End Time: " + timeDF.format(newEndTime) + "\n\n\n");

                        message = message.concat("Would you like to change all your smart data to the recommendations above?");
                        //Show dialog
                        new android.app.AlertDialog.Builder(getActivity())
                                .setTitle("Recommended Smart Data Updates")
                                .setMessage(message)
                                .setPositiveButton("Yes Please", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Update all the data if it passes validation
                                        if ((newStartTime.after(newEndTime))
                                                || (newRevisionLength < newBreakLength)
                                                || (newRevisionLength > 360)
                                                || (newBreakLength < 0)
                                                || (newVariety < 0)
                                                || (newVariety > 10)) {
                                            Toast.makeText(getActivity(), "One or more of the suggested values are invalid", Toast.LENGTH_LONG).show();
                                        } else {
                                            SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getActivity());
                                            SharedPreferences.Editor editor = settings.edit();
                                            editor.putString(getString(R.string.sharedpref_preferred_start_time), timeDF.format(newStartTime));
                                            editor.apply();
                                            startTimePref.setSummary("Set your preferred earliest time to start working\nTime: "
                                                    + timeDF.format(newStartTime));

                                            editor = settings.edit();
                                            editor.putString(getString(R.string.sharedpref_preferred_end_time), timeDF.format(newEndTime));
                                            editor.apply();
                                            endTimePref.setSummary("Set your preferred latest time to finish working\nTime: "
                                                    + timeDF.format(newEndTime));

                                            editor = settings.edit();
                                            editor.putString(getString(R.string.sharedpref_revision_block_size), String.valueOf(newRevisionLength));
                                            editor.apply();
                                            revisionBlockPref.setSummary("Size: " + newRevisionLength);

                                            editor = settings.edit();
                                            editor.putString(getString(R.string.sharedpref_break_block_size), String.valueOf(newBreakLength));
                                            editor.apply();
                                            breakBlockPref.setSummary("Size: " + newBreakLength);

                                            editor = settings.edit();
                                            editor.putInt(getString(R.string.sharedpref_variety), newVariety);
                                            editor.apply();
                                            varietyPreference.setSummary("Set your preferred variety in terms of how "
                                                    + "much the generated revision differs per block\nCurrent Variety: "
                                                    + newVariety);

                                            Toast.makeText(getActivity(), "Updated", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                                .setNegativeButton("No Thanks", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {}
                                })
                                .show();
                    }
                    return true;
                }
            });

            revisionBlockPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object revisionSizeObject) {
                    int revisionSize = Integer.valueOf((String) revisionSizeObject);
                    if (revisionSize >= 360) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle("Revision Block Size Error")
                                .setMessage("WARNING: You have opted to be revising for more than 6 hours straight, " +
                                        "either you've got incredible concentration or you made a mistake? Please try again!\n")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {}
                                })
                                .show();
                        return false;
                    }
                    if (revisionSize < 15) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle("Revision Block Size Error")
                                .setMessage("WARNING: You have opted to be revising for less than 15 minutes, " +
                                        "that is below the minute revision time? Please try again!\n")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {}
                                })
                                .show();
                        return false;
                    }
                    revisionBlockPref.setSummary("Size: " + revisionSize);
                    return true;
                }
            });

            breakBlockPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object breakSizeObject) {
                    int breakSize = Integer.valueOf((String) breakSizeObject);
                    if (breakSize >= 240) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle("Break Block Size Error")
                                .setMessage("WARNING: You have opted to be breaking for more than 4 hours straight, " +
                                        "either you've got incredible chill or you made a mistake? Please try again!\n")
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {}
                                })
                                .show();
                        return false;
                    }
                    int revisionSize = Integer.valueOf(preferenceManager.getSharedPreferences()
                            .getString(getString(R.string.sharedpref_revision_block_size), "0"));
                    if (breakSize > revisionSize) {
                        Toast.makeText(getActivity(), "ADVICE: Your breaks are longer than your revision, " +
                                "doesn't sound too productive to me...?", Toast.LENGTH_LONG).show();
                    }
                    breakBlockPref.setSummary("Size: " + breakSize);
                    return true;
                }
            });

            varietyPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    AlertDialog.Builder builderSingle = new AlertDialog.Builder(getActivity());
                    builderSingle.setTitle("Select variety out of 10:");

                    final ArrayAdapter<Integer> arrayAdapter
                            = new ArrayAdapter<Integer>(getActivity(), android.R.layout.select_dialog_item);
                    arrayAdapter.add(0);
                    arrayAdapter.add(1);
                    arrayAdapter.add(2);
                    arrayAdapter.add(3);
                    arrayAdapter.add(4);
                    arrayAdapter.add(5);
                    arrayAdapter.add(6);
                    arrayAdapter.add(7);
                    arrayAdapter.add(8);
                    arrayAdapter.add(9);
                    arrayAdapter.add(10);

                    builderSingle.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    builderSingle.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            int variety = arrayAdapter.getItem(which);
                            SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getActivity());
                            SharedPreferences.Editor editor = settings.edit();
                            editor.putInt(getString(R.string.sharedpref_variety), variety);
                            editor.apply();
                            varietyPreference.setSummary("Set your preferred variety in terms of how "
                                    + "much the generated revision differs per block\nCurrent Variety: "
                                    + variety);
                        }
                    });
                    builderSingle.show();
                    return true;
                }
            });
        }
    }
}
