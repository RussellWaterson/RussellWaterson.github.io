package com.russell.smartrevisioncalendar.timetablescreens;

import android.app.Fragment;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * <h1>Month Timetable Fragment</h1>
 * The timetable month fragment to show events occurring in a single month
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-12-2016
 */
public class MonthTimetableFragment extends Fragment{

    CalendarView calendarView;
    TextView nextExamTextView;
    View myView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.timetable_month_layout, container, false);

        calendarView = (CalendarView) myView.findViewById(R.id.month_view_calendar);
        nextExamTextView = (TextView) myView.findViewById(R.id.month_view_next_exam);

        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity());
        Cursor res = myDb.getAllExamData();
        if (res.getCount() == 0) {
            nextExamTextView.setVisibility(View.GONE);
        } else {
            nextExamTextView.setVisibility(View.VISIBLE);
            Date now = new Date();
            Date soonestExam = new Date(Long.MAX_VALUE);
            SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
            boolean upcomingExams = false;
            while (res.moveToNext()) {
                try {
                    if (dateDF.parse(res.getString(3)).after(now)
                            && dateDF.parse(res.getString(3)).before(soonestExam)) {
                        soonestExam = dateDF.parse(res.getString(3));
                        upcomingExams = true;
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            long diffInMillies = soonestExam.getTime() - now.getTime();
            long dtg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;

            if (!upcomingExams) {
                nextExamTextView.setText("No Upcoming Exams");
            } else {
                if (dtg == 1) {
                    nextExamTextView.setText("Next Exam is in " + dtg + " Day!");
                } else {
                    nextExamTextView.setText("Next Exam is in " + dtg + " Days!");
                }
            }
        }

        return myView;
    }
}
