package com.russell.smartrevisioncalendar.customcomponents;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;

/**
 * <h1>Reusable Revision Difference Component</h1>
 * Reusable custom component for comparing old revision in the database with new revision. Each day
 * is a new component
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   11-03-2017
 */
public class RevisionDiffComponent extends RelativeLayout {

    TextView date, oldRevision, newRevision;

    public RevisionDiffComponent(Context context) {
        super(context);
        init(context);
    }

    public RevisionDiffComponent(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public RevisionDiffComponent(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    /**
     * Initialise the custom revision diff component
     * @param context The calling activity context
     */
    private void init(Context context) {
        View.inflate(context, R.layout.custom_component_diff, this);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        date = (TextView) findViewById(R.id.revision_diff_date);
        oldRevision = (TextView) findViewById(R.id.revision_diff_old_rev);
        newRevision = (TextView) findViewById(R.id.revision_diff_new_rev);
    }

    /**
     * Sets the revision date text
     * @param text New date
     */
    public void setRevisionDate(String text) {
        date.setText(text);
    }

    /**
     * Sets the old revision text
     * @param text All the old revision for the date
     */
    public void setOldRevision(String text) {
        oldRevision.setText(text);
    }

    /**
     * Sets the new revision text
     * @param text All the new revision for the date
     */
    public void setNewRevision(String text) {
        newRevision.setText(text);
    }
}
