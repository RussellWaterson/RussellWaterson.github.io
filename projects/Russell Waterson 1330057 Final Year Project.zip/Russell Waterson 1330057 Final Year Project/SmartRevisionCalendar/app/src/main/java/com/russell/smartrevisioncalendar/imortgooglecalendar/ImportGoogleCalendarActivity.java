package com.russell.smartrevisioncalendar.imortgooglecalendar;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.googleapis.extensions.android.gms.auth.GooglePlayServicesAvailabilityIOException;
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.ExponentialBackOff;

import com.google.api.services.calendar.CalendarScopes;
import com.google.api.client.util.DateTime;

import com.google.api.services.calendar.model.*;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.customcomponents.GoogleCalendarEventComponent;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

/**
 * <h1>Import Google Calendar Activity</h1>
 * Uses the Google Calendar API to connect a Google Calendar account to the app allowing the user
 * to import existing events into their timetable.
 *
 * @see <a href="https://developers.google.com/google-apps/calendar/">https://developers.google.com/google-apps/calendar/</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   16-03-2017
 */
public class ImportGoogleCalendarActivity extends AppCompatActivity
        implements EasyPermissions.PermissionCallbacks {

    GoogleAccountCredential mCredential;
    private TextView mOutputText;
    ProgressDialog mProgress;

    static final int REQUEST_ACCOUNT_PICKER = 1000;
    static final int REQUEST_AUTHORIZATION = 1001;
    static final int REQUEST_GOOGLE_PLAY_SERVICES = 1002;
    static final int REQUEST_PERMISSION_GET_ACCOUNTS = 1003;

    private static final String PREF_ACCOUNT_NAME = "accountName";
    private static final String[] SCOPES = { CalendarScopes.CALENDAR_READONLY };

    List<GoogleCalendarEventComponent> componentList = new ArrayList<GoogleCalendarEventComponent>();

    RelativeLayout relativeLayout;
    LinearLayout linearLayout;
    TextInputEditText eventsNumberInput;
    Button searchButton;

    int numberOfEvents = 0;

    /**
     * Create the import google calendar activity.
     * @param savedInstanceState previously saved instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import_google_calendar);

        linearLayout = (LinearLayout) findViewById(R.id.google_calendar_linear_layout);
        relativeLayout = (RelativeLayout) findViewById(R.id.google_calendar_relative_layout);
        eventsNumberInput = (TextInputEditText) findViewById(R.id.import_cal_number_input);
        searchButton = (Button) findViewById(R.id.import_cal_search_button);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (eventsNumberInput.getText().toString().equals("")) {
                    Toast.makeText(ImportGoogleCalendarActivity.this, "Please enter a number of events to view", Toast.LENGTH_LONG).show();
                } else {
                    numberOfEvents = Integer.parseInt(eventsNumberInput.getText().toString());
                    if (numberOfEvents < 1 || numberOfEvents > 30) {
                        Toast.makeText(ImportGoogleCalendarActivity.this, "Number of events must be between 1 and 30", Toast.LENGTH_LONG).show();
                    } else {
                        relativeLayout.setVisibility(View.GONE);
                        //Hides the soft keyboard
                        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                        searchButton.setEnabled(false);
                        mOutputText.setText("");
                        getResultsFromApi();
                    }
                }
            }
        });

        mOutputText = (TextView) findViewById(R.id.import_cal_output_text);
        mProgress = new ProgressDialog(this);
        mProgress.setMessage("Calling Google Calendar API ...");

        // Initialize credentials and service object.
        mCredential = GoogleAccountCredential.usingOAuth2(
                getApplicationContext(), Arrays.asList(SCOPES))
                .setBackOff(new ExponentialBackOff());

    }

    /**
     * Attempt to call the API, after verifying that all the preconditions are
     * satisfied. The preconditions are: Google Play Services installed, an
     * account was selected and the device currently has online access. If any
     * of the preconditions are not satisfied, the app will prompt the user as
     * appropriate.
     */
    private void getResultsFromApi() {
        if (! isGooglePlayServicesAvailable()) {
            acquireGooglePlayServices();
        } else if (mCredential.getSelectedAccountName() == null) {
            chooseAccount();
        } else if (! isDeviceOnline()) {
            mOutputText.setText("No network connection available.");
        } else {
            new MakeRequestTask(mCredential).execute();
        }
    }

    /**
     * Attempts to set the account used with the API credentials. If an account
     * name was previously saved it will use that one; otherwise an account
     * picker dialog will be shown to the user. Note that the setting the
     * account to use with the credentials object requires the app to have the
     * GET_ACCOUNTS permission, which is requested here if it is not already
     * present. The AfterPermissionGranted annotation indicates that this
     * function will be rerun automatically whenever the GET_ACCOUNTS permission
     * is granted.
     */
    @AfterPermissionGranted(REQUEST_PERMISSION_GET_ACCOUNTS)
    private void chooseAccount() {
        if (EasyPermissions.hasPermissions(
                this, Manifest.permission.GET_ACCOUNTS)) {
            String accountName = getPreferences(Context.MODE_PRIVATE)
                    .getString(PREF_ACCOUNT_NAME, null);
            if (accountName != null) {
                mCredential.setSelectedAccountName(accountName);
                getResultsFromApi();
            } else {
                // Start a dialog from which the user can choose an account
                startActivityForResult(
                        mCredential.newChooseAccountIntent(),
                        REQUEST_ACCOUNT_PICKER);
            }
        } else {
            // Request the GET_ACCOUNTS permission via a user dialog
            EasyPermissions.requestPermissions(
                    this,
                    "This app needs to access your Google account (via Contacts).",
                    REQUEST_PERMISSION_GET_ACCOUNTS,
                    Manifest.permission.GET_ACCOUNTS);
        }
    }

    /**
     * Called when an activity launched here (specifically, AccountPicker
     * and authorization) exits, giving you the requestCode you started it with,
     * the resultCode it returned, and any additional data from it.
     * @param requestCode code indicating which activity result is incoming.
     * @param resultCode code indicating the result of the incoming
     *     activity result.
     * @param data Intent (containing result data) returned by incoming
     *     activity result.
     */
    @Override
    protected void onActivityResult(
            int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case REQUEST_GOOGLE_PLAY_SERVICES:
                if (resultCode != RESULT_OK) {
                    mOutputText.setText(
                            "This app requires Google Play Services. Please install " +
                                    "Google Play Services on your device and relaunch this app.");
                } else {
                    getResultsFromApi();
                }
                break;
            case REQUEST_ACCOUNT_PICKER:
                if (resultCode == RESULT_OK && data != null &&
                        data.getExtras() != null) {
                    String accountName =
                            data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                    if (accountName != null) {
                        SharedPreferences settings =
                                getPreferences(Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString(PREF_ACCOUNT_NAME, accountName);
                        editor.apply();
                        mCredential.setSelectedAccountName(accountName);
                        getResultsFromApi();
                    }
                }
                break;
            case REQUEST_AUTHORIZATION:
                if (resultCode == RESULT_OK) {
                    getResultsFromApi();
                }
                break;
        }
    }

    /**
     * Respond to requests for permissions at runtime for API 23 and above.
     * @param requestCode The request code passed in
     *     requestPermissions(android.app.Activity, String, int, String[])
     * @param permissions The requested permissions. Never null.
     * @param grantResults The grant results for the corresponding permissions
     *     which is either PERMISSION_GRANTED or PERMISSION_DENIED. Never null.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(
                requestCode, permissions, grantResults, this);
    }

    /**
     * Callback for when a permission is granted using the EasyPermissions
     * library.
     * @param requestCode The request code associated with the requested
     *         permission
     * @param list The requested permission list. Never null.
     */
    @Override
    public void onPermissionsGranted(int requestCode, List<String> list) {
        // Do nothing.
    }

    /**
     * Callback for when a permission is denied using the EasyPermissions
     * library.
     * @param requestCode The request code associated with the requested
     *         permission
     * @param list The requested permission list. Never null.
     */
    @Override
    public void onPermissionsDenied(int requestCode, List<String> list) {
        // Do nothing.
    }

    /**
     * Checks whether the device currently has a network connection.
     * @return true if the device has a network connection, false otherwise.
     */
    private boolean isDeviceOnline() {
        ConnectivityManager connMgr =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    /**
     * Check that Google Play services APK is installed and up to date.
     * @return true if Google Play Services is available and up to
     *     date on this device; false otherwise.
     */
    private boolean isGooglePlayServicesAvailable() {
        GoogleApiAvailability apiAvailability =
                GoogleApiAvailability.getInstance();
        final int connectionStatusCode =
                apiAvailability.isGooglePlayServicesAvailable(this);
        return connectionStatusCode == ConnectionResult.SUCCESS;
    }

    /**
     * Attempt to resolve a missing, out-of-date, invalid or disabled Google
     * Play Services installation via a user dialog, if possible.
     */
    private void acquireGooglePlayServices() {
        GoogleApiAvailability apiAvailability =
                GoogleApiAvailability.getInstance();
        final int connectionStatusCode =
                apiAvailability.isGooglePlayServicesAvailable(this);
        if (apiAvailability.isUserResolvableError(connectionStatusCode)) {
            showGooglePlayServicesAvailabilityErrorDialog(connectionStatusCode);
        }
    }


    /**
     * Display an error dialog showing that Google Play Services is missing
     * or out of date.
     * @param connectionStatusCode code describing the presence (or lack of)
     *     Google Play Services on this device.
     */
    void showGooglePlayServicesAvailabilityErrorDialog(
            final int connectionStatusCode) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        Dialog dialog = apiAvailability.getErrorDialog(
                ImportGoogleCalendarActivity.this,
                connectionStatusCode,
                REQUEST_GOOGLE_PLAY_SERVICES);
        dialog.show();
    }

    /**
     * An asynchronous task that handles the Google Calendar API call.
     * Placing the API calls in their own task ensures the UI stays responsive.
     */
    private class MakeRequestTask extends AsyncTask<Void, Void, List<String>> {
        private com.google.api.services.calendar.Calendar mService = null;
        private Exception mLastError = null;

        MakeRequestTask(GoogleAccountCredential credential) {
            HttpTransport transport = AndroidHttp.newCompatibleTransport();
            JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
            mService = new com.google.api.services.calendar.Calendar.Builder(
                    transport, jsonFactory, credential)
                    .setApplicationName("Google Calendar API Android Quickstart")
                    .build();
        }

        /**
         * Background task to call Google Calendar API.
         * @param params no parameters needed for this task.
         */
        @Override
        protected List<String> doInBackground(Void... params) {
            try {
                return getDataFromApi();
            } catch (Exception e) {
                mLastError = e;
                cancel(true);
                return null;
            }
        }

        /**
         * Fetch a list of the next 10 events from the primary calendar.
         * @return List of Strings describing returned events.
         * @throws IOException
         */
        private List<String> getDataFromApi() throws IOException {
            // List the next events from the primary calendar
            DateTime now = new DateTime(System.currentTimeMillis());
            List<String> eventStrings = new ArrayList<String>();
            Events events = mService.events().list("primary")
                    .setMaxResults(numberOfEvents)
                    .setTimeMin(now)
                    .setOrderBy("startTime")
                    .setSingleEvents(true)
                    .execute();
            List<Event> items = events.getItems();

            for (Event event : items) {
                DateTime start = event.getStart().getDateTime();
                DateTime end = event.getEnd().getDateTime();
                if (start != null) {
                    // All-day events don't have start times, so this will omit them.
                    eventStrings.add(
                            String.format("%s (%s) - (%s)", event.getSummary(), start, end));
                }
            }
            return eventStrings;
        }


        @Override
        protected void onPreExecute() {
            mOutputText.setText("");
            mProgress.show();
        }

        @Override
        protected void onPostExecute(List<String> output) {
            mProgress.dismiss();
            if (output == null || output.size() == 0) {
                mOutputText.setText("No results returned.");
            } else {
                for (int i = 0; i < output.size(); i++) {
                    //Use Regular Expressions to find date and time
                    try {
                        List<String> times = new ArrayList<String>();
                        //Get the time using regex
                        Pattern timePattern = Pattern.compile("T\\d{2}:\\d{2}");
                        Matcher timeMatcher = timePattern.matcher(output.get(i));
                        while(timeMatcher.find()) {
                            System.out.println(timeMatcher.group());
                            times.add(timeMatcher.group());
                        }
                        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                        //When the times are valid in that the start time is before the end time
                        if (timeDF.parse(times.get(0).substring(1)).before(timeDF.parse(times.get(1).substring(1)))) {
                            //Get the date using regex
                            Pattern datePattern = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
                            Matcher dateMatcher = datePattern.matcher(output.get(i));
                            String date = "";
                            if(dateMatcher.find()) {
                                date = dateMatcher.group();
                                System.out.println(date);
                            }

                            final GoogleCalendarEventComponent tempComponent = new GoogleCalendarEventComponent(getApplicationContext());

                            //Edit the component values from the records in the database
                            tempComponent.setEventName(output.get(i).substring(0, output.get(i).indexOf(date) - 2));
                            tempComponent.setEventDateTime(date + "   /   " + times.get(0).substring(1) + " - " + times.get(1).substring(1));

                            tempComponent.getColourView().setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Creates a dialog showing a list of all the colours available to change to
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ImportGoogleCalendarActivity.this);
                                    builder.setTitle("Choose a colour");
                                    builder.setItems(R.array.colours, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int item) {
                                            //Once a color is selected, a second array with corresponding color hex's is indexed
                                            String hexCode = getResources().getStringArray(R.array.colours_hex_code)[item];
                                            tempComponent.getColourView().getBackground().setColorFilter(Color.parseColor(hexCode), PorterDuff.Mode.SRC_ATOP);
                                            tempComponent.setColour(hexCode);
                                        }
                                    });
                                    AlertDialog alert = builder.create();
                                    alert.show();
                                }
                            });

                            //Add the event component to the local array list
                            componentList.add(tempComponent);

                            //Add the event component to the linear layout
                            linearLayout.addView(tempComponent);
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }

                Button saveButton = new Button(ImportGoogleCalendarActivity.this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                params.gravity = Gravity.CENTER_HORIZONTAL;
                saveButton.setLayoutParams(params);
                saveButton.setText("Save");

                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 0; i < componentList.size(); i++) {
                            if (componentList.get(i).getCheckBox()) {
                                //When the checkbox is ticked, add the event to the database
                                String title = componentList.get(i).getEventName();
                                String eventDateTime = componentList.get(i).getEventDateTime();
                                String date = eventDateTime.substring(0, 10);
                                String startTime = eventDateTime.substring(17, 23);
                                String endTime = eventDateTime.substring(25, 30);
                                String colour = componentList.get(i).getColour();

                                DatabaseHelper myDB = DatabaseHelper.getInstance(getApplicationContext());
                                boolean isInserted = myDB.insertEventData(title, date, startTime, endTime, colour);

                                if (isInserted) {
                                    System.out.println("Event Data Successfully Added " + title);
                                } else {
                                    System.out.println("Data Insertion Failed");
                                }
                            }
                        }
                        Toast.makeText(ImportGoogleCalendarActivity.this, "Importing Events...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

                linearLayout.addView(saveButton);
            }
        }

        @Override
        protected void onCancelled() {
            mProgress.dismiss();
            if (mLastError != null) {
                if (mLastError instanceof GooglePlayServicesAvailabilityIOException) {
                    showGooglePlayServicesAvailabilityErrorDialog(
                            ((GooglePlayServicesAvailabilityIOException) mLastError)
                                    .getConnectionStatusCode());
                } else if (mLastError instanceof UserRecoverableAuthIOException) {
                    startActivityForResult(
                            ((UserRecoverableAuthIOException) mLastError).getIntent(),
                            ImportGoogleCalendarActivity.REQUEST_AUTHORIZATION);
                } else {
                    mOutputText.setText("The following error occurred:\n"
                            + mLastError.getMessage());
                }
            } else {
                mOutputText.setText("Request cancelled.");
            }
        }
    }
}
