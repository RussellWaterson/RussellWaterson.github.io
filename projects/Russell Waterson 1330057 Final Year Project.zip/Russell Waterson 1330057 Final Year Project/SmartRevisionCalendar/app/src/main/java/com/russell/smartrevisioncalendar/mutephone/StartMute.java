package com.russell.smartrevisioncalendar.mutephone;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

/**
 * <h1>Start Mute</h1>
 * Broadcast receiver to mute the phone at the start of the day
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   14-03-2017
 */
public class StartMute extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
    }
}
