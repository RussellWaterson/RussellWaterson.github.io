package com.russell.smartrevisioncalendar.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * <h1>Database Helper Class</h1>
 * Helper class for managing all the operations related to the database.
 * It automatically manages the creation and update of the database.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-01-2017
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static DatabaseHelper mInstance = null;

    public static final String DATABASE_NAME = "Calendar.db";

    //Class database credentials
    public static final String CLASS_TABLE_NAME = "class_table";
    public static final String CLASS_COLUMN_ID = "id";
    public static final String CLASS_COLUMN_MODULE = "module";
    public static final String CLASS_COLUMN_TITLE = "title";
    public static final String CLASS_COLUMN_DAY = "day";
    public static final String CLASS_COLUMN_START_TIME = "start_time";
    public static final String CLASS_COLUMN_END_TIME = "end_time";
    public static final String CLASS_COLUMN_REPEAT = "repeat";
    public static final String CLASS_COLUMN_TEACHER = "teacher";
    public static final String CLASS_COLUMN_ROOM = "room";
    public static final String CLASS_COLUMN_COLOUR = "colour";

    //Activity database credentials
    public static final String ACTIVITY_TABLE_NAME = "activity_table";
    public static final String ACTIVITY_COLUMN_ID = "id";
    public static final String ACTIVITY_COLUMN_ACTIVITY = "activity";
    public static final String ACTIVITY_COLUMN_DAY = "day";
    public static final String ACTIVITY_COLUMN_START_TIME = "start_time";
    public static final String ACTIVITY_COLUMN_END_TIME = "end_time";
    public static final String ACTIVITY_COLUMN_REPEAT = "repeat";
    public static final String ACTIVITY_COLUMN_COLOUR = "colour";

    //Exam database credentials
    public static final String EXAM_TABLE_NAME = "exam_table";
    public static final String EXAM_COLUMN_ID = "id";
    public static final String EXAM_COLUMN_MODULE = "module";
    public static final String EXAM_COLUMN_TITLE = "title";
    public static final String EXAM_COLUMN_DATE = "date";
    public static final String EXAM_COLUMN_START_TIME = "start_time";
    public static final String EXAM_COLUMN_DURATION = "duration";
    public static final String EXAM_COLUMN_MORE_INFO = "more_info";
    public static final String EXAM_COLUMN_COLOUR = "colour";
    public static final String EXAM_COLUMN_CONTENT_SIZE = "content_size";
    public static final String EXAM_COLUMN_PRIORITY = "priority";

    //Revision database credentials
    public static final String REVISION_TABLE_NAME = "revision_table";
    public static final String REVISION_COLUMN_ID = "id";
    public static final String REVISION_COLUMN_MODULE = "module";
    public static final String REVISION_COLUMN_TITLE = "title";
    public static final String REVISION_COLUMN_DATE = "date";
    public static final String REVISION_COLUMN_START_TIME = "start_time";
    public static final String REVISION_COLUMN_END_TIME = "end_time";
    public static final String REVISION_COLUMN_NOTES = "notes";
    public static final String REVISION_COLUMN_COLOUR = "colour";

    //Google Event database credentials
    public static final String EVENT_TABLE_NAME = "event_table";
    public static final String EVENT_COLUMN_ID = "id";
    public static final String EVENT_COLUMN_TITLE = "title";
    public static final String EVENT_COLUMN_DATE = "date";
    public static final String EVENT_COLUMN_START_TIME = "start_time";
    public static final String EVENT_COLUMN_END_TIME = "end_time";
    public static final String EVENT_COLUMN_COLOUR = "colour";

    //Debrief database credentials
    public static final String DEBRIEF_TABLE_NAME = "debrief_table";
    public static final String DEBRIEF_COLUMN_ID = "id";
    public static final String DEBRIEF_COLUMN_PRODUCTIVITY = "productivity";
    public static final String DEBRIEF_COLUMN_REVISION_LENGTH = "revision_length";
    public static final String DEBRIEF_COLUMN_REVISION_RATING = "revision_rating";
    public static final String DEBRIEF_COLUMN_BREAK_LENGTH = "break_length";
    public static final String DEBRIEF_COLUMN_BREAK_RATING = "break_rating";
    public static final String DEBRIEF_COLUMN_START_TIME = "start_time";
    public static final String DEBRIEF_COLUMN_START_RATING = "start_rating";
    public static final String DEBRIEF_COLUMN_END_TIME = "end_time";
    public static final String DEBRIEF_COLUMN_END_RATING = "end_rating";
    public static final String DEBRIEF_COLUMN_VARIETY = "variety";
    public static final String DEBRIEF_COLUMN_VARIETY_RATING = "variety_rating";

    /**
     * Gets a Database Helper Instance
     * @param context Use the application context, which will ensure that you don't accidentally
     *                leak an Activity's context.
     * @return Database Helper instance
     */
    public static DatabaseHelper getInstance(Context context) {
        // Use the application context, which will ensure that you don't accidentally leak an Activity's context.
        if (mInstance == null) {
            mInstance = new DatabaseHelper(context.getApplicationContext());
        }
        return mInstance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + CLASS_TABLE_NAME +
                " (" + CLASS_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CLASS_COLUMN_MODULE + " TEXT, " +
                CLASS_COLUMN_TITLE + " TEXT, " +
                CLASS_COLUMN_DAY + " TEXT, " +
                CLASS_COLUMN_START_TIME + " TEXT, " +
                CLASS_COLUMN_END_TIME + " TEXT, " +
                CLASS_COLUMN_REPEAT + " INTEGER, " +
                CLASS_COLUMN_TEACHER + " TEXT, " +
                CLASS_COLUMN_ROOM + " TEXT, " +
                CLASS_COLUMN_COLOUR + " TEXT)"
        );
        db.execSQL("create table " + ACTIVITY_TABLE_NAME +
                " (" + ACTIVITY_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ACTIVITY_COLUMN_ACTIVITY + " TEXT, " +
                ACTIVITY_COLUMN_DAY + " TEXT, " +
                ACTIVITY_COLUMN_START_TIME + " TEXT, " +
                ACTIVITY_COLUMN_END_TIME + " TEXT, " +
                ACTIVITY_COLUMN_REPEAT + " INTEGER, " +
                ACTIVITY_COLUMN_COLOUR + " TEXT)"
        );
        db.execSQL("create table " + EXAM_TABLE_NAME +
                " (" + EXAM_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EXAM_COLUMN_MODULE + " TEXT, " +
                EXAM_COLUMN_TITLE + " TEXT, " +
                EXAM_COLUMN_DATE + " TEXT, " +
                EXAM_COLUMN_START_TIME + " TEXT, " +
                EXAM_COLUMN_DURATION + " INTEGER, " +
                EXAM_COLUMN_MORE_INFO + " TEXT, " +
                EXAM_COLUMN_COLOUR + " TEXT, " +
                EXAM_COLUMN_CONTENT_SIZE + " INTEGER, " +
                EXAM_COLUMN_PRIORITY + " INTEGER)"
        );
        db.execSQL("create table " + REVISION_TABLE_NAME +
                " (" + REVISION_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                REVISION_COLUMN_MODULE + " TEXT, " +
                REVISION_COLUMN_TITLE + " TEXT, " +
                REVISION_COLUMN_DATE + " TEXT, " +
                REVISION_COLUMN_START_TIME + " TEXT, " +
                REVISION_COLUMN_END_TIME + " TEXT, " +
                REVISION_COLUMN_NOTES + " TEXT, " +
                REVISION_COLUMN_COLOUR + " TEXT)"
        );
        db.execSQL("create table " + EVENT_TABLE_NAME +
                " (" + EVENT_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_COLUMN_TITLE + " TEXT, " +
                EVENT_COLUMN_DATE + " TEXT, " +
                EVENT_COLUMN_START_TIME + " TEXT, " +
                EVENT_COLUMN_END_TIME + " TEXT, " +
                EVENT_COLUMN_COLOUR + " TEXT)"
        );
        db.execSQL("create table " + DEBRIEF_TABLE_NAME +
                " (" + DEBRIEF_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                DEBRIEF_COLUMN_PRODUCTIVITY + " INTEGER, " +
                DEBRIEF_COLUMN_REVISION_LENGTH + " INTEGER, " +
                DEBRIEF_COLUMN_REVISION_RATING + " INTEGER, " +
                DEBRIEF_COLUMN_BREAK_LENGTH  + " INTEGER, " +
                DEBRIEF_COLUMN_BREAK_RATING + " INTEGER, " +
                DEBRIEF_COLUMN_START_TIME + " TEXT, " +
                DEBRIEF_COLUMN_START_RATING + " INTEGER, " +
                DEBRIEF_COLUMN_END_TIME + " TEXT, " +
                DEBRIEF_COLUMN_END_RATING + " INTEGER, " +
                DEBRIEF_COLUMN_VARIETY  + " INTEGER, " +
                DEBRIEF_COLUMN_VARIETY_RATING + " INTEGER)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST " + CLASS_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + ACTIVITY_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + EXAM_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + REVISION_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + EVENT_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + DEBRIEF_TABLE_NAME);
        onCreate(db);
    }

    /**
     * Inserts a class record into the class table in the database
     * @param module Class module name
     * @param title Class title name
     * @param day Day of class
     * @param startTime Class start time
     * @param endTime Class end time
     * @param repeat Whether the class repeats weekly, 1 for true, 0 for false
     * @param teacher Teacher of the class
     * @param room Room the class is in
     * @param colour Colour of the class for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean insertClassData(String module, String title, String day, String startTime,
                              String endTime, int repeat, String teacher, String room, String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(CLASS_COLUMN_MODULE, module);
        contentValues.put(CLASS_COLUMN_TITLE, title);
        contentValues.put(CLASS_COLUMN_DAY, day);
        contentValues.put(CLASS_COLUMN_START_TIME, startTime);
        contentValues.put(CLASS_COLUMN_END_TIME, endTime);
        contentValues.put(CLASS_COLUMN_REPEAT, repeat);
        contentValues.put(CLASS_COLUMN_TEACHER, teacher);
        contentValues.put(CLASS_COLUMN_ROOM, room);
        contentValues.put(CLASS_COLUMN_COLOUR, colour);

        //Returns -1 if there were any errors
        long result = db.insert(CLASS_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the class database
     * @return All records in class DB
     */
    public Cursor getAllClassData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + CLASS_TABLE_NAME, null);
    }

    /**
     * Updates an existing class record in the class table
     * @param id The ID of the class to be edited
     * @param module New class module name
     * @param title New class title name
     * @param day New day of class
     * @param startTime New class start time
     * @param endTime New class end time
     * @param repeat New weekly repeat value, 1 for true, 0 for false
     * @param teacher New teacher of the class
     * @param room New room the class is in
     * @param colour New colour of the class for it to appear in the system
     * @return True when update completes
     */
    public boolean updateClassData(String id, String module, String title, String day,
                                   String startTime, String endTime, int repeat, String teacher,
                                   String room, String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(CLASS_COLUMN_ID, id);
        contentValues.put(CLASS_COLUMN_MODULE, module);
        contentValues.put(CLASS_COLUMN_TITLE, title);
        contentValues.put(CLASS_COLUMN_DAY, day);
        contentValues.put(CLASS_COLUMN_START_TIME, startTime);
        contentValues.put(CLASS_COLUMN_END_TIME, endTime);
        contentValues.put(CLASS_COLUMN_REPEAT, repeat);
        contentValues.put(CLASS_COLUMN_TEACHER, teacher);
        contentValues.put(CLASS_COLUMN_ROOM, room);
        contentValues.put(CLASS_COLUMN_COLOUR, colour);

        db.update(CLASS_TABLE_NAME, contentValues, CLASS_COLUMN_ID + " = ?", new String[] {id});
        return true;
    }

    /**
     * Deletes a class record from the class table
     * @param id The ID of the class to be deleted
     * @return the number of rows affected if a whereClause is passed in, 0
     *         otherwise. To remove all rows and get a count pass "1" as the
     *         whereClause.
     */
    public Integer deleteClassData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(CLASS_TABLE_NAME, CLASS_COLUMN_ID + " = ?", new String[] {id});
    }

    /**
     * Inserts an activity record into the activity table in the database
     * @param activity Name of activity
     * @param day Day of activity
     * @param startTime Activity start time
     * @param endTime Activity end time
     * @param repeat Whether the activity repeats weekly, 1 for true, 0 for false
     * @param colour Colour of the activity for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean insertActivityData(String activity, String day, String startTime, String endTime,
                                      int repeat, String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(ACTIVITY_COLUMN_ACTIVITY, activity);
        contentValues.put(ACTIVITY_COLUMN_DAY, day);
        contentValues.put(ACTIVITY_COLUMN_START_TIME, startTime);
        contentValues.put(ACTIVITY_COLUMN_END_TIME, endTime);
        contentValues.put(ACTIVITY_COLUMN_REPEAT, repeat);
        contentValues.put(ACTIVITY_COLUMN_COLOUR, colour);

        //Returns -1 if there were any errors
        long result = db.insert(ACTIVITY_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the activity database
     * @return All records in activity DB
     */
    public Cursor getAllActivityData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + ACTIVITY_TABLE_NAME, null);
    }

    /**
     * Updates an existing activity record in the activity table
     * @param id The ID of the activity to edit
     * @param activity New name of activity
     * @param day New day of activity
     * @param startTime New activity start time
     * @param endTime New activity end time
     * @param repeat New weekly repeat value, 1 for true, 0 for false
     * @param colour New colour of the activity for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean updateActivityData(String id, String activity, String day, String startTime,
                                      String endTime, int repeat, String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(ACTIVITY_COLUMN_ID, id);
        contentValues.put(ACTIVITY_COLUMN_ACTIVITY, activity);
        contentValues.put(ACTIVITY_COLUMN_DAY, day);
        contentValues.put(ACTIVITY_COLUMN_START_TIME, startTime);
        contentValues.put(ACTIVITY_COLUMN_END_TIME, endTime);
        contentValues.put(ACTIVITY_COLUMN_REPEAT, repeat);
        contentValues.put(ACTIVITY_COLUMN_COLOUR, colour);

        db.update(ACTIVITY_TABLE_NAME, contentValues, ACTIVITY_COLUMN_ID + " = ?", new String[] {id});
        return true;
    }

    /**
     * Deletes an activity record from the activity table
     * @param id The ID of the activity to be deleted
     * @return the number of rows affected if a whereClause is passed in, 0
     *         otherwise. To remove all rows and get a count pass "1" as the
     *         whereClause.
     */
    public Integer deleteActivityData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(ACTIVITY_TABLE_NAME, ACTIVITY_COLUMN_ID + " = ?", new String[] {id});
    }

    /**
     * Inserts an exam record into the exam table in the database
     * @param module Exam module name
     * @param title Exam title name
     * @param date Date of exam
     * @param startTime Exam start time
     * @param duration Exam duration
     * @param moreInfo Exam additional info the user wishes to add
     * @param colour Colour of the exam for it to appear in the system
     * @param contentSize The amount of course content estimated to cover
     * @param priority The priority of the exam against others
     * @return True when successfully added to DB, false otherwise
     */
    public boolean insertExamData(String module, String title, String date, String startTime,
                                   int duration, String moreInfo, String colour, int contentSize,
                                  int priority) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(EXAM_COLUMN_MODULE, module);
        contentValues.put(EXAM_COLUMN_TITLE, title);
        contentValues.put(EXAM_COLUMN_DATE, date);
        contentValues.put(EXAM_COLUMN_START_TIME, startTime);
        contentValues.put(EXAM_COLUMN_DURATION, duration);
        contentValues.put(EXAM_COLUMN_MORE_INFO, moreInfo);
        contentValues.put(EXAM_COLUMN_COLOUR, colour);
        contentValues.put(EXAM_COLUMN_CONTENT_SIZE, contentSize);
        contentValues.put(EXAM_COLUMN_PRIORITY, priority);

        //Returns -1 if there were any errors
        long result = db.insert(EXAM_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the exam database
     * @return All records in exam DB
     */
    public Cursor getAllExamData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + EXAM_TABLE_NAME, null);
    }

    /**
     * Updates an existing exam record in the exam table
     * @param id The ID of the exam to be edited
     * @param module New exam module name
     * @param title New exam title name
     * @param date New date of exam
     * @param startTime New exam start time
     * @param duration New exam duration
     * @param moreInfo New exam additional info the user wishes to add
     * @param colour New colour of the exam for it to appear in the system
     * @param contentSize The new amount of course content estimated to cover
     * @param priority The new priority of the exam against others
     * @return True when successfully added to DB, false otherwise
     */
    public boolean updateExamData(String id, String module, String title, String date,
                                      String startTime, int duration, String moreInfo,
                                      String colour, int contentSize, int priority) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(EXAM_COLUMN_ID, id);
        contentValues.put(EXAM_COLUMN_MODULE, module);
        contentValues.put(EXAM_COLUMN_TITLE, title);
        contentValues.put(EXAM_COLUMN_DATE, date);
        contentValues.put(EXAM_COLUMN_START_TIME, startTime);
        contentValues.put(EXAM_COLUMN_DURATION, duration);
        contentValues.put(EXAM_COLUMN_MORE_INFO, moreInfo);
        contentValues.put(EXAM_COLUMN_COLOUR, colour);
        contentValues.put(EXAM_COLUMN_CONTENT_SIZE, contentSize);
        contentValues.put(EXAM_COLUMN_PRIORITY, priority);

        db.update(EXAM_TABLE_NAME, contentValues, EXAM_COLUMN_ID + " = ?", new String[] {id});
        return true;
    }

    /**
     * Deletes an exam record from the exam table
     * @param id The ID of the exam to be deleted
     * @return the number of rows affected if a whereClause is passed in, 0
     *         otherwise. To remove all rows and get a count pass "1" as the
     *         whereClause.
     */
    public Integer deleteExamData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(EXAM_TABLE_NAME, EXAM_COLUMN_ID + " = ?", new String[] {id});
    }

    /**
     * Inserts a revision record into the revision table in the database
     * @param module Revision module name
     * @param title Revision title name
     * @param date Date of revision
     * @param startTime Revision start time
     * @param endTime Revision end time
     * @param notes Revision notes
     * @param colour Colour of the revision for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean insertRevisionData(String module, String title, String date, String startTime,
                                  String endTime, String notes, String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(REVISION_COLUMN_MODULE, module);
        contentValues.put(REVISION_COLUMN_TITLE, title);
        contentValues.put(REVISION_COLUMN_DATE, date);
        contentValues.put(REVISION_COLUMN_START_TIME, startTime);
        contentValues.put(REVISION_COLUMN_END_TIME, endTime);
        contentValues.put(REVISION_COLUMN_NOTES, notes);
        contentValues.put(REVISION_COLUMN_COLOUR, colour);

        //Returns -1 if there were any errors
        long result = db.insert(REVISION_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the revision database
     * @return All records in revision DB
     */
    public Cursor getAllRevisionData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + REVISION_TABLE_NAME, null);
    }

    /**
     * Updates an existing revision record in the revision table
     * @param id The ID of the revision to be edited
     * @param module New revision module name
     * @param title New revision title name
     * @param date New date of revision
     * @param startTime New revision start time
     * @param endTime New revision end time
     * @param notes New revision notes
     * @param colour New colour of the revision for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean updateRevisionData(String id, String module, String title, String date,
                                      String startTime, String endTime, String notes,
                                      String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(REVISION_COLUMN_ID, id);
        contentValues.put(REVISION_COLUMN_MODULE, module);
        contentValues.put(REVISION_COLUMN_TITLE, title);
        contentValues.put(REVISION_COLUMN_DATE, date);
        contentValues.put(REVISION_COLUMN_START_TIME, startTime);
        contentValues.put(REVISION_COLUMN_END_TIME, endTime);
        contentValues.put(REVISION_COLUMN_NOTES, notes);
        contentValues.put(REVISION_COLUMN_COLOUR, colour);

        db.update(REVISION_TABLE_NAME, contentValues, REVISION_COLUMN_ID + " = ?", new String[] {id});
        return true;
    }

    /**
     * Deletes a revision record from the revision table
     * @param id The ID of the revision to be deleted
     * @return the number of rows affected if a whereClause is passed in, 0
     *         otherwise. To remove all rows and get a count pass "1" as the
     *         whereClause.
     */
    public Integer deleteRevisionData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(REVISION_TABLE_NAME, REVISION_COLUMN_ID + " = ?", new String[] {id});
    }

    /**
     * Inserts an event record into the event table in the database
     * @param title Event title name
     * @param date Date of event
     * @param startTime Event start time
     * @param endTime Event end time
     * @param colour Colour of the event for it to appear in the system
     * @return True when successfully added to DB, false otherwise
     */
    public boolean insertEventData(String title, String date, String startTime, String endTime,
                                   String colour) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(EVENT_COLUMN_TITLE, title);
        contentValues.put(EVENT_COLUMN_DATE, date);
        contentValues.put(EVENT_COLUMN_START_TIME, startTime);
        contentValues.put(EVENT_COLUMN_END_TIME, endTime);
        contentValues.put(EVENT_COLUMN_COLOUR, colour);

        //Returns -1 if there were any errors
        long result = db.insert(EVENT_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the events database
     * @return All records in events DB
     */
    public Cursor getAllEventData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + EVENT_TABLE_NAME, null);
    }

    /**
     * Deletes an event record from the events table
     * @param id The ID of the event to be deleted
     * @return the number of rows affected if a whereClause is passed in, 0
     *         otherwise. To remove all rows and get a count pass "1" as the
     *         whereClause.
     */
    public Integer deleteEventData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(EVENT_TABLE_NAME, EVENT_COLUMN_ID + " = ?", new String[] {id});
    }

    /**
     * Inserts a debrief record into the debrief table in the database
     * @param productivity The user's productivity out of 5
     * @param revision_length The current revision block length
     * @param revision_rating The user's rating of the revision block length
     * @param break_length The current break block length
     * @param break_rating The user's rating of the break block length
     * @param start_time The current start time for revision
     * @param start_rating The user's rating of the revision start time
     * @param end_time The current end time for revision
     * @param end_rating The user's rating of the revision end time
     * @param variety The current variety of the revision
     * @param variety_rating The user's rating for the variety
     * @return Returns true if the record was inserted successfully, otherwise returns false
     */
    public boolean insertDebriefData(int productivity, int revision_length, int revision_rating,
                                     int break_length, int break_rating, String start_time,
                                     int start_rating, String end_time, int end_rating, int variety,
                                     int variety_rating) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Allocating inputs to their columns
        contentValues.put(DEBRIEF_COLUMN_PRODUCTIVITY, productivity);
        contentValues.put(DEBRIEF_COLUMN_REVISION_LENGTH, revision_length);
        contentValues.put(DEBRIEF_COLUMN_REVISION_RATING, revision_rating);
        contentValues.put(DEBRIEF_COLUMN_BREAK_LENGTH, break_length);
        contentValues.put(DEBRIEF_COLUMN_BREAK_RATING, break_rating);
        contentValues.put(DEBRIEF_COLUMN_START_TIME, start_time);
        contentValues.put(DEBRIEF_COLUMN_START_RATING, start_rating);
        contentValues.put(DEBRIEF_COLUMN_END_TIME, end_time);
        contentValues.put(DEBRIEF_COLUMN_END_RATING, end_rating);
        contentValues.put(DEBRIEF_COLUMN_VARIETY, variety);
        contentValues.put(DEBRIEF_COLUMN_VARIETY_RATING, variety_rating);

        //Returns -1 if there were any errors
        long result = db.insert(DEBRIEF_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns all the records in the debrief database
     * @return All records in debrief DB
     */
    public Cursor getAllDebriefData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + DEBRIEF_TABLE_NAME, null);
    }
}
