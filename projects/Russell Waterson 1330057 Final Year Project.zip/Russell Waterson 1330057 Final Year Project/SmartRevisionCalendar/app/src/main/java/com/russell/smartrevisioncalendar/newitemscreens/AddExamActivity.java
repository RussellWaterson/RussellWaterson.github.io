package com.russell.smartrevisioncalendar.newitemscreens;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * <h1>Add New Exam</h1>
 * The activity that handles the adding of a new exam
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   18-01-2017
 */
public class AddExamActivity extends AppCompatActivity {

    DatabaseHelper myDB;

    AutoCompleteTextView moduleNameInput;
    TextInputEditText titleNameInput;
    TextView dateInput, startTimeInput;
    EditText durationInput, moreInfoInput, contentSizeInput, priorityInput;
    View colourInput;

    Button saveButton;

    String tempColour = null;

    Calendar calendar = Calendar.getInstance();

    SharedPreferences sharedPref;

    boolean valid;
    boolean edit;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exam);

        myDB = DatabaseHelper.getInstance(this);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        moduleNameInput = (AutoCompleteTextView) findViewById(R.id.exam_module_name_input);
        titleNameInput = (TextInputEditText) findViewById(R.id.exam_title_name_input);
        dateInput = (TextView) findViewById(R.id.exam_date_input);
        startTimeInput = (TextView) findViewById(R.id.exam_start_time_input);
        durationInput = (EditText) findViewById(R.id.exam_duration_input);
        moreInfoInput = (EditText) findViewById(R.id.exam_more_info_input);
        colourInput = findViewById(R.id.exam_colour_input);
        contentSizeInput = (EditText) findViewById(R.id.exam_content_size_input);
        priorityInput = (EditText) findViewById(R.id.exam_priority_input);

        saveButton = (Button) findViewById(R.id.exam_save_button);

        final ArrayList<String> modules = new ArrayList<String>();
        final ArrayList<String> colours = new ArrayList<String>();

        Cursor res = myDB.getAllExamData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }
        res = myDB.getAllClassData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(9));
            }
        }
        res = myDB.getAllRevisionData();
        while (res.moveToNext()) {
            if (!modules.contains(res.getString(1))) {
                modules.add(res.getString(1));
                colours.add(res.getString(7));
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_singlechoice, modules);
        moduleNameInput.setThreshold(1);
        moduleNameInput.setAdapter(adapter);
        moduleNameInput.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String moduleColour = colours.get(modules.indexOf(moduleNameInput.getText().toString()));
                colourInput.getBackground().setColorFilter(Color.parseColor(moduleColour), PorterDuff.Mode.SRC_ATOP);
                tempColour = moduleColour;
                Toast.makeText(getApplicationContext(), "Colour changed to match chosen module", Toast.LENGTH_LONG).show();
            }
        });

        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddExamActivity.this, onDateSetListener,
                        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        startTimeInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(AddExamActivity.this, onStartTimeSetListener,
                        Integer.parseInt(startTimeInput.getText().subSequence(0,2).toString()),
                        Integer.parseInt(startTimeInput.getText().subSequence(3,5).toString()),
                        true).show();
            }
        });

        if (tempColour == null) {
            tempColour = "#03A9F4";
        }
        colourInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creates a dialog showing a list of all the colours available to change to
                AlertDialog.Builder builder = new AlertDialog.Builder(AddExamActivity.this);
                builder.setTitle("Choose a colour");
                builder.setItems(R.array.colours, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        //Once a color is selected, a second array with corresponding color hex's is indexed
                        String hexCode = getResources().getStringArray(R.array.colours_hex_code)[item];
                        colourInput.getBackground().setColorFilter(Color.parseColor(hexCode), PorterDuff.Mode.SRC_ATOP);
                        tempColour = hexCode;
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        edit = sharedPref.getBoolean(getString(R.string.sharedpref_edit_item), false);
        if (edit) {
            id = sharedPref.getString(getString(R.string.sharedpref_edit_id), "0");
            populateFields();
        }

        valid = false;

        addData();
    }

    /**
     * Adds data input into the various types of data fields into the Exams database
     */
    public void addData() {
        saveButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        validate();
                        if (valid) {
                            if (edit) {
                                //When existing data is to be edited
                                boolean isUpdated = myDB.updateExamData(id,
                                        moduleNameInput.getText().toString(),
                                        titleNameInput.getText().toString(),
                                        dateInput.getText().toString(),
                                        startTimeInput.getText().toString(),
                                        Integer.parseInt(durationInput.getText().toString()),
                                        moreInfoInput.getText().toString(),
                                        tempColour,
                                        Integer.parseInt(contentSizeInput.getText().toString()),
                                        Integer.parseInt(priorityInput.getText().toString()));

                                if (isUpdated) {
                                    Toast.makeText(AddExamActivity.this, "Exam has successfully been updated", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(AddExamActivity.this, "Exam update failed!", Toast.LENGTH_SHORT).show();
                                }

                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                                editor.apply();

                                setResult(RESULT_OK, null);
                                finish();

                            } else {
                                //When new data is to be added
                                boolean isInserted = myDB.insertExamData(moduleNameInput.getText().toString(),
                                        titleNameInput.getText().toString(),
                                        dateInput.getText().toString(),
                                        startTimeInput.getText().toString(),
                                        Integer.parseInt(durationInput.getText().toString()),
                                        moreInfoInput.getText().toString(),
                                        tempColour,
                                        Integer.parseInt(contentSizeInput.getText().toString()),
                                        Integer.parseInt(priorityInput.getText().toString()));

                                if (isInserted) {
                                    Toast.makeText(AddExamActivity.this, "Data Successfully Added", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(AddExamActivity.this, "Data Insertion Failed", Toast.LENGTH_SHORT).show();
                                }
                                setResult(RESULT_OK, null);
                                finish();
                            }
                        }
                    }
                }
        );
    }

    /**
     * Validates all the entered data is suitable before adding to the database
     */
    private void validate() {
        String failingText = "";

        //Validate module name - field required
        if (moduleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The exam module name must not be empty\n\n");
        }

        //Validate title name - field required
        if (titleNameInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- The exam title name must not be empty\n\n");
        }

        //Validate date - field required
        if (dateInput.getText().toString().equals("00-00-0000")) {
            failingText = failingText.concat("- You must select a valid exam date\n\n");
        }

        //Validate duration - can't be too large
        if (durationInput.getText().toString().isEmpty()) {
            failingText = failingText.concat("- You must enter a duration for the exam\n\n");
        } else if (Double.parseDouble(durationInput.getText().toString()) > 600) {
            failingText = failingText.concat("- An exam can't be more than 10 hours! (600 minutes)\n\n");
        }

        //Validate content size - must be out of 10, if empty set to 0
        if (contentSizeInput.getText().toString().isEmpty()) {
            contentSizeInput.setText("0");
            Toast.makeText(AddExamActivity.this, "Content size set to a default of 0", Toast.LENGTH_LONG).show();
        } else if (Double.parseDouble(contentSizeInput.getText().toString()) > 10) {
            failingText = failingText.concat("- The content size must be between 0 and 10\n\n");
        }

        //Validate priority - must be out of 5, if empty set to 0
        if (priorityInput.getText().toString().isEmpty()) {
            priorityInput.setText("0");
            Toast.makeText(AddExamActivity.this, "Priority set to a default of 0", Toast.LENGTH_LONG).show();
        } else if (Double.parseDouble(priorityInput.getText().toString()) > 5) {
            failingText = failingText.concat("- The priority must be between 0 and 5\n\n");
        }

        if (failingText.isEmpty()) {
            valid = true;
        } else {
            //Show dialog
            new AlertDialog.Builder(this)
                    .setTitle("Failed Validity Check!!")
                    .setMessage(failingText)
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {}
                    })
                    .show();
        }
    }

    /**
     * When existing exam data is to be edited, the fields should be populated with the current data
     */
    private void populateFields() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Edit Exam");
        }
        Cursor res = myDB.getAllExamData();
        //Locate the exam that has been selected
        while (res.moveToNext()) {
            if (res.getString(0).equals(id)) {
                moduleNameInput.setText(res.getString(1));
                titleNameInput.setText(res.getString(2));
                dateInput.setText(res.getString(3));
                startTimeInput.setText(res.getString(4));
                durationInput.setText(res.getString(5));
                moreInfoInput.setText(res.getString(6));
                colourInput.getBackground().setColorFilter(Color.parseColor(res.getString(7)), PorterDuff.Mode.SRC_ATOP);
                tempColour = res.getString(7);
                contentSizeInput.setText(res.getString(8));
                priorityInput.setText(res.getString(9));
            }
        }
        saveButton.setText(R.string.edit);
    }

    /**
     * Sets what happens when a date is selected from the date picker dialog
     */
    DatePickerDialog.OnDateSetListener onDateSetListener  = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
            Calendar newDate = Calendar.getInstance();
            newDate.set(year, monthOfYear, dayOfMonth);
            dateInput.setText(dateFormatter.format(newDate.getTime()));
        }
    };

    /**
     * Sets what happens when a start time is selected from the time picker dialog
     */
    TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            DecimalFormat df = new DecimalFormat("00");
            startTimeInput.setText(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
        }
    };
}
