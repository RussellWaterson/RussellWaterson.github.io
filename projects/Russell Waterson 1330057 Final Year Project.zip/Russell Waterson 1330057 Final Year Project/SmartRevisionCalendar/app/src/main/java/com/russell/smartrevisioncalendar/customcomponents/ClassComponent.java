package com.russell.smartrevisioncalendar.customcomponents;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.mainscreens.IndividualItemScreen;

/**
 * <h1>Reusable Classes Component</h1>
 * Reusable custom component for displaying classes in the database on the classes fragment
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   23-01-2017
 */
public class ClassComponent extends RelativeLayout {

    TextView moduleTitle, teacherRoom, timeDay;
    View repeat, colouredLine;
    Rect hitRect;
    String id;

    SharedPreferences sharedPref;

    public ClassComponent(Context context) {
        super(context);
        init(context);
    }

    public ClassComponent(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ClassComponent(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    /**
     * Initialise the custom class component
     * @param context The calling activity context
     */
    private void init(Context context) {
        View.inflate(context, R.layout.custom_component_class,this);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        moduleTitle = (TextView) findViewById(R.id.c_component_module_title);
        teacherRoom = (TextView) findViewById(R.id.c_component_teacher_room);
        timeDay = (TextView) findViewById(R.id.c_component_time_day);
        repeat = findViewById(R.id.c_component_repeat);
        colouredLine = findViewById(R.id.c_component_coloured_line);
        hitRect = new Rect();
        sharedPref = PreferenceManager.getDefaultSharedPreferences(getContext());
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.getHitRect(hitRect);
                if (hitRect.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
                    motionEvent.setLocation(0.0f, 0.0f);
                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_id), id);
                    editor.commit();
                    editor.putString(getContext().getString(R.string.sharedpref_edit_table), "classTable");
                    editor.commit();
                    System.out.println(sharedPref.getString(getContext().getString(R.string.sharedpref_edit_id), "no") + "   "
                            + sharedPref.getString(getContext().getString(R.string.sharedpref_edit_table), "no"));
                    getContext().startActivity(new Intent(getContext(), IndividualItemScreen.class));
                }
                return true;
            }
        });
    }

    /**
     * Sets the class module and title text
     * @param text New class module and title
     */
    public void setModuleTitleText(String text) {
        moduleTitle.setText(text);
    }

    /**
     * Sets the class teacher and room text
     * @param text Mew class teacher and room
     */
    public void setTeacherRoomText(String text) {
        teacherRoom.setText(text);
    }

    /**
     * Sets the class time and day text
     * @param text New class time and day
     */
    public void setTimeDayText(String text) {
        timeDay.setText(text);
    }

    /**
     * Sets whether the repeat icon is visible or not
     * @param set True to show icon, false to hide icon
     */
    public void setRepeat (Boolean set) {
        if(set) { repeat.setVisibility(View.VISIBLE); }
    }

    /**
     * Sets the colour of the line displayed by the activity
     * @param text New line colour
     */
    public void setColouredLine(String text) {
        colouredLine.getBackground().setColorFilter(Color.parseColor(text), PorterDuff.Mode.SRC_ATOP);
    }

    /**
     * Sets the ID of the class
     * @param text New class ID
     */
    public void setID(String text) { id = text; }
}
