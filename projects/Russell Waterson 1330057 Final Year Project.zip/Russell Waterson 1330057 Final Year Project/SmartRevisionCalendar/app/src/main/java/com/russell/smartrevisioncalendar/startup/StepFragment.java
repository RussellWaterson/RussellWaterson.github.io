package com.russell.smartrevisioncalendar.startup;

import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;
import com.russell.smartrevisioncalendar.debriefs.NotificationEventReceiver;
import com.russell.smartrevisioncalendar.imortgooglecalendar.ImportGoogleCalendarActivity;
import com.russell.smartrevisioncalendar.newitemscreens.AddActivityActivity;
import com.russell.smartrevisioncalendar.newitemscreens.AddClassActivity;
import com.russell.smartrevisioncalendar.newitemscreens.AddExamActivity;
import com.stepstone.stepper.Step;
import com.stepstone.stepper.VerificationError;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * <h1>Step Fragment</h1>
 * Creates the fragment for the steppers
 * <p>
 * Guided from android-material-stepper sample:
 * <a href="https://github.com/stepstone-tech/android-material-stepper">
 *     https://github.com/stepstone-tech/android-material-stepper</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   13-02-2017
 */
public class StepFragment extends Fragment implements Step {

    SharedPreferences sharedPref;

    int classCount;
    int activityCount;
    int examCount;

    public static StepFragment newInstance(@LayoutRes int layoutResId) {
        Bundle args = new Bundle();
        args.putInt("messageResourceId", layoutResId);
        StepFragment fragment = new StepFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(getArguments().getInt("messageResourceId"), container, false);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        return v;
    }

    @Override
    public VerificationError verifyStep() {
        return null;
    }

    @Override
    public void onSelected() {
        switch(getArguments().getInt("messageResourceId")) {
            case R.layout.startup_fragment_welcome_step1:
                welcomeStartUp();
                break;
            case R.layout.startup_fragment_classes_step2:
                classesStartUp();
                break;
            case R.layout.startup_fragment_activities_step3:
                activitiesStartUp();
                break;
            case R.layout.startup_fragment_calsync_step4:
                calendarSync();
                break;
            case R.layout.startup_fragment_exams_step7:
                examsStartUp();
                break;
            case R.layout.startup_fragment_learning_style_step8:
                learningStyle();
                break;
            case R.layout.startup_fragment_debriefs_step9:
                debriefs();
                break;
            default:
                break;
        }
    }

    @Override
    public void onError(@NonNull VerificationError error) {}

    @Override
    public void onResume() {
        super.onResume();
        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
        switch(getArguments().getInt("messageResourceId")) {
            case R.layout.startup_fragment_classes_step2:
                Cursor resClass = myDb.getAllClassData();
                if (classCount != resClass.getCount()) {
                    classesStartUp();
                }
                break;
            case R.layout.startup_fragment_activities_step3:
                Cursor resActivity = myDb.getAllActivityData();
                if (activityCount != resActivity.getCount()) {
                    activitiesStartUp();
                }
                break;
            case R.layout.startup_fragment_exams_step7:
                Cursor resExam = myDb.getAllExamData();
                if (examCount != resExam.getCount()) {
                    examsStartUp();
                }
                break;
            default:
                break;
        }
    }

    /**
     * Sets up all the components for the welcome screen
     */
    private void welcomeStartUp() {
        final TextInputEditText nameInput = (TextInputEditText) getActivity().findViewById(R.id.welcome_name_input);
        nameInput.setText(sharedPref.getString(getString(R.string.sharedpref_user_name), ""));
        nameInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString(getString(R.string.sharedpref_user_name), nameInput.getText().toString());
                    editor.commit();
                }
            }
        });
    }

    /**
     * Sets up all the components for the classes screen
     */
    private void classesStartUp() {
        Button classButton = (Button) getActivity().findViewById(R.id.add_class_button);
        TextView classesList = (TextView) getActivity().findViewById(R.id.class_list);
        classButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                editor.commit();
                startActivity(new Intent(getActivity().getApplicationContext(), AddClassActivity.class));
            }
        });
        classesList.setText("Classes:\n\n");
        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
        Cursor res = myDb.getAllClassData();
        classCount = res.getCount();
        while (res.moveToNext()) {
            classesList.append(res.getString(1) + " - " + res.getString(2) + "\n");
        }
    }

    /**
     * Sets up all the components for the activities screen
     */
    private void activitiesStartUp() {
        Button activityButton = (Button) getActivity().findViewById(R.id.add_activity_button);
        TextView activityList = (TextView) getActivity().findViewById(R.id.activity_list);
        activityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                editor.commit();
                startActivity(new Intent(getActivity().getApplicationContext(), AddActivityActivity.class));
            }
        });
        activityList.setText("Activities:\n\n");
        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
        Cursor res = myDb.getAllActivityData();
        activityCount = res.getCount();
        while (res.moveToNext()) {
            activityList.append(res.getString(1) + "\n");
        }
    }

    /**
     * Sets up all the components for the Google Calendar sync screen
     */
    private void calendarSync() {
        Button calsyncButton = (Button) getActivity().findViewById(R.id.calsync_button);
        calsyncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity().getApplicationContext(), ImportGoogleCalendarActivity.class));
            }
        });
    }

    /**
     * Sets up all the components for the exams screen
     */
    private void examsStartUp() {
        Button examButton = (Button) getActivity().findViewById(R.id.add_exam_button);
        TextView examList = (TextView) getActivity().findViewById(R.id.exam_list);
        examButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.sharedpref_edit_item), false);
                editor.commit();
                startActivity(new Intent(getActivity().getApplicationContext(), AddExamActivity.class));
            }
        });
        examList.setText("Exams:\n\n");
        DatabaseHelper myDb = DatabaseHelper.getInstance(getActivity().getApplicationContext());
        Cursor res = myDb.getAllExamData();
        examCount = res.getCount();
        while (res.moveToNext()) {
            examList.append(res.getString(1) + " - " + res.getString(2) + "\n");
        }
    }

    /**
     * Sets up all the components for the learning style screen
     */
    private void learningStyle() {
        final String startTime = sharedPref.getString(getString(R.string.sharedpref_preferred_start_time), "00:00");
        final String endTime = sharedPref.getString(getString(R.string.sharedpref_preferred_end_time), "23:59");
        final String revisionBlock = sharedPref.getString(getString(R.string.sharedpref_revision_block_size), "0");
        String breakBlock = sharedPref.getString(getString(R.string.sharedpref_break_block_size), "0");
        int variety = sharedPref.getInt(getString(R.string.sharedpref_variety), 0);

        final TextView startTimeText = (TextView) getActivity().findViewById(R.id.learn_start_time_value);
        final TextView endTimeText = (TextView) getActivity().findViewById(R.id.learn_end_time_value);
        final TextView revisionBlockText = (TextView) getActivity().findViewById(R.id.learn_revision_block_value);
        final TextView breakBlockText = (TextView) getActivity().findViewById(R.id.learn_break_block_value);
        final TextView varietyValueText = (TextView) getActivity().findViewById(R.id.learn_variety_number);
        SeekBar varietySeekBar = (SeekBar) getActivity().findViewById(R.id.learn_variety_seekbar);

        startTimeText.setText(startTime);
        startTimeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        try {
                            DecimalFormat df = new DecimalFormat("00");
                            SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                            Date currentEndTime = timeDF.parse(sharedPref.getString(getString(R.string.sharedpref_preferred_end_time), "23:59"));
                            Date newStartTime = timeDF.parse(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
                            if (newStartTime.after(currentEndTime)) {
                                new AlertDialog.Builder(getActivity())
                                        .setTitle("Start Time Error")
                                        .setMessage("WARNING: You have set your start time to be after your end time!! Please try again!\n")
                                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {}
                                        })
                                        .show();
                            } else {
                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putString(getString(R.string.sharedpref_preferred_start_time), (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                editor.commit();
                                startTimeText.setText((String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                };
                new TimePickerDialog(getActivity(), onStartTimeSetListener,
                        Integer.parseInt(startTimeText.getText().toString().substring(0,2)),
                        Integer.parseInt(startTimeText.getText().toString().substring(3,5)),
                        true).show();
            }
        });

        endTimeText.setText(endTime);
        endTimeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener onStartTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        try {
                            DecimalFormat df = new DecimalFormat("00");
                            SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
                            Date currentStartTime = timeDF.parse(sharedPref.getString(getString(R.string.sharedpref_preferred_start_time), "00:00"));
                            Date newEndTime = timeDF.parse(String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute)));
                            if (newEndTime.before(currentStartTime)) {
                                new AlertDialog.Builder(getActivity())
                                        .setTitle("End Time Error")
                                        .setMessage("WARNING: You have set your end time to before your start time!! Please try again!\n")
                                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {}
                                        })
                                        .show();
                            } else {
                                SharedPreferences.Editor editor = sharedPref.edit();
                                editor.putString(getString(R.string.sharedpref_preferred_end_time), (String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                                editor.commit();
                                endTimeText.setText((String.valueOf(df.format(hourOfDay)) + ":" + String.valueOf(df.format(minute))));
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                };
                new TimePickerDialog(getActivity(), onStartTimeSetListener,
                        Integer.parseInt(endTimeText.getText().toString().substring(0,2)),
                        Integer.parseInt(endTimeText.getText().toString().substring(3,5)),
                        true).show();
            }
        });

        revisionBlockText.setText(revisionBlock);
        revisionBlockText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());

                final EditText edittext = new EditText(getContext());
                edittext.setText(revisionBlockText.getText());
                edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
                FrameLayout container = new FrameLayout(getContext());
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.leftMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.rightMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.topMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.bottomMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                edittext.setLayoutParams(params);
                container.addView(edittext);

                alert.setTitle("Revision Block Size");
                alert.setView(container);

                alert.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (Integer.parseInt(edittext.getText().toString()) >= 360) {
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Revision Block Size Error")
                                    .setMessage("WARNING: You have opted to be revising for more than 6 hours straight, " +
                                            "either you've got incredible concentration or you made a mistake? Please try again!\n")
                                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {}
                                    })
                                    .show();
                        } else if (Integer.parseInt(edittext.getText().toString()) < 15) {
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Revision Block Size Error")
                                    .setMessage("WARNING: You have opted to be revising for less than 15 minutes, " +
                                            "that is below the minute revision time? Please try again!\n")
                                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {}
                                    })
                                    .show();
                        } else {
                            revisionBlockText.setText(edittext.getText());
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString(getString(R.string.sharedpref_revision_block_size),
                                    edittext.getText().toString());
                            editor.apply();
                        }
                    }
                });

                alert.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {}
                });

                alert.show();
            }
        });

        breakBlockText.setText(breakBlock);
        breakBlockText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());

                final EditText edittext = new EditText(getContext());
                edittext.setText(breakBlockText.getText());
                edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
                FrameLayout container = new FrameLayout(getContext());
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.leftMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.rightMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.topMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                params.bottomMargin = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
                edittext.setLayoutParams(params);
                container.addView(edittext);

                alert.setTitle("Break Block Size");
                alert.setView(container);

                alert.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (Integer.parseInt(edittext.getText().toString()) >= 240) {
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Break Block Size Error")
                                    .setMessage("WARNING: You have opted to be breaking for more than 4 hours straight, " +
                                            "either you've got incredible chill or you made a mistake? Please try again!\n")
                                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                        }
                                    })
                                    .show();
                        } else {
                            breakBlockText.setText(edittext.getText());
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString(getString(R.string.sharedpref_break_block_size),
                                    edittext.getText().toString());
                            editor.apply();
                            int revisionSize = Integer.valueOf(sharedPref.getString(getString(R.string.sharedpref_revision_block_size), "0"));
                            if (Integer.valueOf(edittext.getText().toString()) > revisionSize) {
                                Toast.makeText(getActivity(), "ADVICE: Your breaks are longer than your revision, " +
                                        "doesn't sound too productive to me...?", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                });

                alert.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {}
                });

                alert.show();
            }
        });

        varietyValueText.setText(String.valueOf(variety) + "/" + varietySeekBar.getMax());
        varietySeekBar.setProgress(variety);
        varietySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progress = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
                progress = progressValue;
                varietyValueText.setText(progress + "/" + seekBar.getMax());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt(getString(R.string.sharedpref_variety), progress);
                editor.apply();
            }
        });

    }

    /**
     * Sets up all the components for the debriefs screen
     */
    private void debriefs() {
        Boolean endBlockDebrief = sharedPref.getBoolean(getString(R.string.sharedpref_end_block_debrief), false);
        Boolean endDayDebrief = sharedPref.getBoolean(getString(R.string.sharedpref_end_day_debrief), false);
        CheckBox blockDebriefCheckBox = (CheckBox) getActivity().findViewById(R.id.block_debrief_checkBox);
        blockDebriefCheckBox.setChecked(endBlockDebrief);
        blockDebriefCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.sharedpref_end_block_debrief), true);
                    editor.apply();
                    Toast.makeText(getActivity(), "Coming soon...", Toast.LENGTH_SHORT).show();
                } else {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.sharedpref_end_block_debrief), false);
                    editor.apply();
                }
            }
        });

        CheckBox dayDebriefCheckBox = (CheckBox) getActivity().findViewById(R.id.day_debrief_checkBox);
        dayDebriefCheckBox.setChecked(endDayDebrief);
        dayDebriefCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.sharedpref_end_day_debrief), true);
                    editor.apply();
                    NotificationEventReceiver.setupAlarm(getActivity());
                } else {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.sharedpref_end_day_debrief), false);
                    editor.apply();
                    NotificationEventReceiver.cancelAlarm(getActivity());
                }
            }
        });
    }
}
