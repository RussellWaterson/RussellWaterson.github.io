package com.russell.smartrevisioncalendar.smartdata;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.customcomponents.RevisionDiffComponent;
import com.russell.smartrevisioncalendar.database.DatabaseHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * <h1>Newly Generated Revision Difference</h1>
 * Activity showing the difference in the newly generated revision and the old existing revision
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   10-03-2017
 */
public class NewRevisionDiff extends AppCompatActivity {

    DatabaseHelper myDb;
    LinearLayout revisionDiffLinearLayout;
    TextView oldModuleCount, newModuleCount, noRevisionTextView;
    Button discardButton, saveButton;

    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revision_diff);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        oldModuleCount = (TextView) findViewById(R.id.revision_diff_old_modules);
        newModuleCount = (TextView) findViewById(R.id.revision_diff_new_modules);

        noRevisionTextView = (TextView) findViewById(R.id.revision_diff_no_revision_text);
        revisionDiffLinearLayout = (LinearLayout) findViewById(R.id.revision_diff_linear_layout);

        discardButton = (Button) findViewById(R.id.revision_diff_discard_button);
        saveButton = (Button) findViewById(R.id.revision_diff_save_button);

        discardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearNewBlocks(getApplicationContext());
                finish();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearOldBlocks(getApplicationContext());
                finish();
            }
        });

        viewModuleCount();

        viewRevision();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "The new revision will be deleted and old persevered as default", Toast.LENGTH_LONG).show();
        clearNewBlocks(getApplicationContext());
    }

    /**
     * Counts the number of revision slots for each module, and compares it with the old existing
     * revision, and the newly generated revision.
     */
    private void viewModuleCount() {
        myDb = DatabaseHelper.getInstance(getApplicationContext());

        Cursor res = myDb.getAllRevisionData();
        if(res.getCount() == 0) {
            //When there is no revision in the database
            oldModuleCount.setText("No revision in DB");
            newModuleCount.setText("No revision in DB");
            return;
        }

        //Loop through all the revision and add all unique module and titles to an array list
        List<String> allModuleTitles = new ArrayList<String>();
        while (res.moveToNext()) {
            String moduleTitle = res.getString(1) + " - " + res.getString(2);
            if (moduleTitle.equals("null - null")) {
                moduleTitle = "Custom Revision Slot";
            }
            if (!allModuleTitles.contains(moduleTitle)) {
                allModuleTitles.add(moduleTitle);
            }
        }

        //Create arrays with the size of the unique revision names array list
        int[] oldModuleCountArray = new int[allModuleTitles.size()];
        int[] newModuleCountArray = new int[allModuleTitles.size()];

        res = myDb.getAllRevisionData();
        //Loop through the DB and if revision equals an array list entry, get the location and add
        //it to the same location in either the old or new array depending on which it is
        while (res.moveToNext()) {

            String moduleTitle = res.getString(1) + " - " + res.getString(2);
            if (moduleTitle.equals("null - null")) {
                moduleTitle = "Custom Revision Slot";
            }
            int moduleTitleIndex = allModuleTitles.indexOf(moduleTitle);

            if (res.getPosition() < sharedPref.getInt(getString(R.string.sharedpref_number_of_old_revision_slots), 0)) {
                //When a revision record is of the OLD revision data
                oldModuleCountArray[moduleTitleIndex]++;
            } else {
                //When a revision record is of the NEW revision data
                newModuleCountArray[moduleTitleIndex]++;
            }
        }

        //Initialise strings to be set for the text view
        String oldModuleText = "";
        String newModuleText = "";

        //Loop through all arrays and array lists to display the modules and their amounts
        for (int i = 0; i < allModuleTitles.size(); i++) {
            oldModuleText = oldModuleText.concat(allModuleTitles.get(i) + ":   " + oldModuleCountArray[i] + "\n");
            newModuleText = newModuleText.concat(newModuleCountArray[i] + "   :" + allModuleTitles.get(i) + "\n");
        }

        oldModuleCount.setText(oldModuleText);
        newModuleCount.setText(newModuleText);

    }

    /**
     * Creates new custom components for each day there exists revision. Each component showing a
     * comparison between the previously existing old data, and the newly generated data.
     */
    private void viewRevision() {
        myDb = DatabaseHelper.getInstance(getApplicationContext());

        Cursor res = myDb.getAllRevisionData();
        if(res.getCount() == 0) {
            //When there is no revision in the DB
            return;
        }

        //Otherwise remove text view
        noRevisionTextView.setVisibility(View.GONE);

        //And proceed to display the old and new revision slots
        boolean beforeLastRevision = true;

        //Get the day of the last revision slot
        Date latestRevision = new Date();
        SimpleDateFormat dateDF = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);
        while (res.moveToNext()) {
            try {
                if (dateDF.parse(res.getString(3)).after(latestRevision)) {
                    latestRevision = dateDF.parse(res.getString(3));
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        //Add one day to the latest revision so that it too can be compared
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(latestRevision);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        latestRevision = calendar.getTime();

        //Start the comparison from the current date
        Calendar dateComparison = Calendar.getInstance();

        while (beforeLastRevision) {
            //Create temp revision difference component and add it to the parent
            RevisionDiffComponent tempComponent = new RevisionDiffComponent(getApplicationContext());

            //Reset the old and new revision text fields
            String oldRevision = "";
            String newRevision = "";

            //Set the date of the component to the
            tempComponent.setRevisionDate(dateDF.format(dateComparison.getTime()));

            //Each day go through all of the revision records
            res = myDb.getAllRevisionData();
            while (res.moveToNext()) {

                if (res.getString(3).equals(dateDF.format(dateComparison.getTime()))) {
                    //When a revision has the same date as the current comparison day

                    if (res.getPosition() < sharedPref.getInt(getString(R.string.sharedpref_number_of_old_revision_slots), 0)) {
                        //When a revision record is of the OLD revision data
                        if (res.getString(1) == null && res.getString(2) == null) {
                            oldRevision = oldRevision.concat("\n" + "Custom Revision Slot" + "\n" +
                                    res.getString(4) + " - " + res.getString(5) + "\n");
                        } else {
                            oldRevision = oldRevision.concat("\n" + res.getString(1) + "\n" +
                                    res.getString(2) + "\n" +
                                    res.getString(4) + " - " + res.getString(5) + "\n");
                        }
                    } else {
                        //When a revision record is of the NEW revision data
                        if (res.getString(1) == null && res.getString(2) == null) {
                            newRevision = newRevision.concat("\n" + "Custom Revision Slot" + "\n" +
                                    res.getString(4) + " - " + res.getString(5) + "\n");
                        } else {
                            newRevision = newRevision.concat("\n" + res.getString(1) + "\n" +
                                    res.getString(2) + "\n" +
                                    res.getString(4) + " - " + res.getString(5) + "\n");
                        }
                    }
                }
            }

            //Set the old revision for the component on this day
            if (oldRevision.equals("")) {
                tempComponent.setOldRevision("There is no old revision for this day");
            } else {
                tempComponent.setOldRevision(oldRevision);
            }

            //Set the new revision for the component on this day
            if (newRevision.equals("")) {
                tempComponent.setNewRevision("There is no new revision for this day");
            } else {
                tempComponent.setNewRevision(newRevision);
            }

            //Proceed to the next day and check whether it is after the last revision in the database
            dateComparison.add(Calendar.DAY_OF_MONTH, 1);

            if (dateComparison.getTime().after(latestRevision)) {
                //If it is after the last day, all the data has been displayed
                beforeLastRevision = false;
            }

            //Add the revision diff component to the linear layout
            revisionDiffLinearLayout.addView(tempComponent);

        }
    }

    /**
     * Removes all the old revision blocks in the revision database present before the regeneration
     * @param context The previous context
     */
    public static void clearOldBlocks(Context context) {
        DatabaseHelper localDB = DatabaseHelper.getInstance(context);
        SharedPreferences localSharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        System.out.println("Clearing revision database of previously existing revision slots");
        Toast.makeText(context, "Deleting the old revision and keeping the new", Toast.LENGTH_LONG).show();
        List<String> revisionIDs = new ArrayList<String>();
        Cursor resRevision = localDB.getAllRevisionData();
        while (resRevision.moveToNext()) {
            if (resRevision.getPosition() < localSharedPref.getInt(context.getString(R.string.sharedpref_number_of_old_revision_slots), 0)) {
                revisionIDs.add(resRevision.getString(0));
            } else {
                break;
            }
        }
        for (int i = 0; i < revisionIDs.size(); i++) {
            Integer deletedRows = localDB.deleteRevisionData(revisionIDs.get(i));
            if (deletedRows > 0 ) {
                System.out.println(revisionIDs.get(i) + " deleted");
            } else {
                System.out.println(revisionIDs.get(i) + " NOT deleted!");
            }
        }
    }

    /**
     * Removes all the new revision blocks in the revision database created when generating new revision
     * @param context The previous context
     */
    public static void clearNewBlocks(Context context) {
        DatabaseHelper localDB = DatabaseHelper.getInstance(context);
        SharedPreferences localSharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        System.out.println("Clearing revision database of newly created revision slots");
        Toast.makeText(context, "Deleting the new revision and keeping the old", Toast.LENGTH_LONG).show();
        List<String> revisionIDs = new ArrayList<String>();
        Cursor resRevision = localDB.getAllRevisionData();
        while (resRevision.moveToNext()) {
            if (resRevision.getPosition() >= localSharedPref.getInt(context.getString(R.string.sharedpref_number_of_old_revision_slots), 0)) {
                revisionIDs.add(resRevision.getString(0));
            }
        }
        for (int i = 0; i < revisionIDs.size(); i++) {
            Integer deletedRows = localDB.deleteRevisionData(revisionIDs.get(i));
            if (deletedRows > 0 ) {
                System.out.println(revisionIDs.get(i) + " deleted");
            } else {
                System.out.println(revisionIDs.get(i) + " NOT deleted!");
            }
        }
    }
}
