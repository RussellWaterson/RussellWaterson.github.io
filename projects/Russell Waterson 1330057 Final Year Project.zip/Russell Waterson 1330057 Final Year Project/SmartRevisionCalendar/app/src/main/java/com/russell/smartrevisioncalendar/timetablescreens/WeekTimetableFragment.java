package com.russell.smartrevisioncalendar.timetablescreens;

import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.RectF;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.alamkanak.weekview.DateTimeInterpreter;
import com.alamkanak.weekview.MonthLoader;
import com.alamkanak.weekview.WeekView;
import com.alamkanak.weekview.WeekViewEvent;
import com.russell.smartrevisioncalendar.R;
import com.russell.smartrevisioncalendar.mainscreens.IndividualItemScreen;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * <h1>Week Timetable Fragment</h1>
 * The timetable week fragment to show events occurring in a single week
 * <p>
 * Uses the third party WeekView and this is and all the code necessary to initialize it
 * Guided by sample app: <a href="https://github.com/alamkanak/Android-Week-View/tree/master/sample">
 *     https://github.com/alamkanak/Android-Week-View/tree/master/sample</a>
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   20-12-2016
 */
public abstract class WeekTimetableFragment extends Fragment
        implements WeekView.EventClickListener, MonthLoader.MonthChangeListener,
        WeekView.EventLongPressListener, WeekView.EmptyViewLongPressListener {

    private WeekView mWeekView;

    SharedPreferences sharedPref;

    View myView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.timetable_week_layout, container, false);

        // Get a reference for the week view in the layout.
        mWeekView = (WeekView) myView.findViewById(R.id.week_view_calendar);

        // Show a toast message about the touched event.
        mWeekView.setOnEventClickListener(this);

        // The week view has infinite scrolling horizontally. We have to provide the events of a
        // month every time the month changes on the week view.
        mWeekView.setMonthChangeListener(this);

        // Set long press listener for events.
        mWeekView.setEventLongPressListener(this);

        // Set long press listener for empty view
        mWeekView.setEmptyViewLongPressListener(this);

        // Set up a date time interpreter to interpret how the date and time will be formatted in the week view.
        setupDateTimeInterpreter();

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        Calendar calendar = Calendar.getInstance();
        if (!(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)
                && !(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
            calendar.add(Calendar.DAY_OF_MONTH, 7);
            mWeekView.goToDate(calendar);
        }

        String startTime = sharedPref.getString(getActivity().getString(R.string.sharedpref_preferred_start_time), "00:00");
        mWeekView.goToHour(Integer.parseInt(startTime.substring(0, startTime.indexOf(":"))) - 1);

        return myView;
    }

    /**
     * Set up a date time interpreter which will show short date values when in week view and long
     * date values otherwise.
     */
    private void setupDateTimeInterpreter() {
        mWeekView.setDateTimeInterpreter(new DateTimeInterpreter() {
            @Override
            public String interpretDate(Calendar date) {
                SimpleDateFormat weekdayNameFormat = new SimpleDateFormat("EEE", Locale.getDefault());
                String weekday = weekdayNameFormat.format(date.getTime());
                SimpleDateFormat format = new SimpleDateFormat(" d/M", Locale.getDefault());

                weekday = String.valueOf(weekday.charAt(0));
                return weekday.toUpperCase() + format.format(date.getTime());
            }

            @Override
            public String interpretTime(int hour) {
                return hour > 11 ? (hour - 12) + " PM" : (hour == 0 ? "12 AM" : hour + " AM");
            }
        });
    }

    /**
     * Creates a custom title for an event
     * @param time The time to add to the title
     * @return The new custom title
     */
    protected String getEventTitle(Calendar time) {
        return String.format(Locale.UK, "Event of %02d:%02d %s/%d", time.get(Calendar.HOUR_OF_DAY),
                time.get(Calendar.MINUTE), time.get(Calendar.MONTH)+1, time.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    public void onEventClick(WeekViewEvent event, RectF eventRect) {
        int eventID = (int) event.getId();
        if (eventID >= 100 && eventID < 200) {
            //Activity
            eventID -= 100;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_id), String.valueOf(eventID));
            editor.commit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_table), "activityTable");
            editor.commit();
            System.out.println(sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_id), "no") + "   "
                    + sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_table), "no"));
            getActivity().startActivity(new Intent(getActivity(), IndividualItemScreen.class));

        } else if (eventID >= 200 && eventID < 300) {
            //Class
            eventID -= 200;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_id), String.valueOf(eventID));
            editor.commit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_table), "classTable");
            editor.commit();
            System.out.println(sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_id), "no") + "   "
                    + sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_table), "no"));
            getActivity().startActivity(new Intent(getActivity(), IndividualItemScreen.class));

        } else if (eventID >= 300 && eventID < 400) {
            //Exam
            eventID -= 300;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_id), String.valueOf(eventID));
            editor.commit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_table), "examTable");
            editor.commit();
            System.out.println(sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_id), "no") + "   "
                    + sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_table), "no"));
            getActivity().startActivity(new Intent(getActivity(), IndividualItemScreen.class));

        } else if (eventID >= 400 && eventID < 100000) {
            //Revision
            eventID -= 400;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_id), String.valueOf(eventID));
            editor.commit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_table), "revisionTable");
            editor.commit();
            System.out.println(sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_id), "no") + "   "
                    + sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_table), "no"));
            getActivity().startActivity(new Intent(getActivity(), IndividualItemScreen.class));

        } else if (eventID >= 100000) {
            //Google Event
            eventID -= 100000;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_id), String.valueOf(eventID));
            editor.commit();
            editor.putString(getActivity().getString(R.string.sharedpref_edit_table), "eventTable");
            editor.commit();
            System.out.println(sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_id), "no") + "   "
                    + sharedPref.getString(getActivity().getString(R.string.sharedpref_edit_table), "no"));
            getActivity().startActivity(new Intent(getActivity(), IndividualItemScreen.class));

        } else {
            Toast.makeText(getActivity(), "Clicked " + event.getId() + " - " + event.getName(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEventLongPress(WeekViewEvent event, RectF eventRect) {
        Toast.makeText(getActivity(), "Long pressed event: " + event.getName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEmptyViewLongPress(Calendar time) {
        Toast.makeText(getActivity(), "Empty view long pressed: " + getEventTitle(time), Toast.LENGTH_SHORT).show();
    }

    public WeekView getWeekView() {
        return mWeekView;
    }
}
