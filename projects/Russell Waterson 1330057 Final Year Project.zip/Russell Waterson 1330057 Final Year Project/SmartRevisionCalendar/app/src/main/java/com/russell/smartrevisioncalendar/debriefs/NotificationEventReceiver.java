package com.russell.smartrevisioncalendar.debriefs;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import com.russell.smartrevisioncalendar.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * <h1>Notification Event Receiver</h1>
 * WakefulBroadcastReceiver broadcast receiver
 * <p>
 * AlarmManager is set up to fire PendingIntent every 24 hours, and specifies the handled actions
 * for this intent in onReceive() method. Starts IntentService, which will generate notifications.
 *
 * @author  Russell Waterson
 * @version 1.0, 22-03-2017
 * @since   27-02-2017
 */
public class NotificationEventReceiver extends WakefulBroadcastReceiver {

    private static final String ACTION_START_NOTIFICATION_SERVICE = "ACTION_START_NOTIFICATION_SERVICE";
    private static final String ACTION_DELETE_NOTIFICATION = "ACTION_DELETE_NOTIFICATION";
    private static final int NOTIFICATIONS_INTERVAL_IN_DAYS = 1;

    private static Date currentEndTime;

    /**
     * Sets up the reoccurring alarm to trigger the notifications
     * @param context The previous context
     */
    public static void setupAlarm(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent alarmIntent = getStartPendingIntent(context);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);

        SimpleDateFormat timeDF = new SimpleDateFormat("HH:mm", Locale.UK);
        try {
            currentEndTime = timeDF.parse(sharedPref.getString(context.getString(R.string.sharedpref_preferred_end_time), "00:00"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                getTriggerAt(new Date()),
                NOTIFICATIONS_INTERVAL_IN_DAYS * AlarmManager.INTERVAL_DAY,
                alarmIntent);
    }

    /**
     * Cancels the previously set up alarm
     * @param context The previous context
     */
    public static void cancelAlarm(Context context) {
        Intent intent = new Intent(context, NotificationEventReceiver.class);
        intent.setAction(ACTION_START_NOTIFICATION_SERVICE);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(alarmIntent);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Intent serviceIntent = null;
        if (ACTION_START_NOTIFICATION_SERVICE.equals(action)) {
            Log.i(getClass().getSimpleName(), "onReceive from alarm, starting notification service");
            serviceIntent = NotificationIntentService.createIntentStartNotificationService(context);
        } else if (ACTION_DELETE_NOTIFICATION.equals(action)) {
            Log.i(getClass().getSimpleName(), "onReceive delete notification action, starting notification service to handle delete");
            serviceIntent = NotificationIntentService.createIntentDeleteNotification(context);
        }

        if (serviceIntent != null) {
            startWakefulService(context, serviceIntent);
        }
    }

    /**
     * Gets the current preferred end time of the current day, in milliseconds
     * @param now The current date
     * @return The current preferred end time of the current day, in milliseconds
     */
    private static long getTriggerAt(Date now) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        Calendar endTime = Calendar.getInstance();
        endTime.setTime(currentEndTime);
        int hour = endTime.get(Calendar.HOUR_OF_DAY);
        int minute = endTime.get(Calendar.MINUTE);

        calendar.set(year, month, day, hour, minute);
        return calendar.getTimeInMillis();
    }

    /**
     * Gets the start notification service as the pending intent
     * @param context The previous context
     * @return Returns the new PendingIntent matching the given parameters
     */
    private static PendingIntent getStartPendingIntent(Context context) {
        Intent intent = new Intent(context, NotificationEventReceiver.class);
        intent.setAction(ACTION_START_NOTIFICATION_SERVICE);
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /**
     * Gets the delete notification service as the pending intent
     * @param context The previous context
     * @return Returns the new PendingIntent matching the given parameters
     */
    public static PendingIntent getDeleteIntent(Context context) {
        Intent intent = new Intent(context, NotificationEventReceiver.class);
        intent.setAction(ACTION_DELETE_NOTIFICATION);
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
