## Smart Revision Calendar

The proposed project will be to create a smart revision timetable and calendar 
application. This mobile application is targeted towards students and will 
allow them to create a work timetable with minimal effort. The premise is, 
the user enters various inputs, including their class times, extracurricular 
activities, exams and deadlines, and their preferred learning style. The 
application will then generate a revision timetable around the classes and 
activities with the exams as goals to work towards. At the end of each revision 
block and/or day, the user can give feedback on how productive they have been. 
This feedback, along with the learning style, means that the more the user uses 
the system, the more the timetable will learn and be tailored to that 
particular user. 

The project will be a mobile application on the android mobile operating system. 
It will be developed using Java in Android Studio and will be tested 
predominately on a Nexus 6P running the stock Android operating system version 
7.1 Nougat without root.